"""Category 4 — Bad Phase Connectivity.

Checks: ph_01 through ph_05.
"""
from __future__ import annotations

from typing import Any

import pandas as pd

from ._common import (
    get_table,
    elem_id,
    is_in_service,
    safe_float,
    dedup_iter,
    issue,
)


def check_phase_connectivity(net: Any) -> list[dict[str, Any]]:
    """Run all phase connectivity checks."""
    issues: list[dict[str, Any]] = []
    issues.extend(_ph_01_load_on_unreachable_phase(net))
    issues.extend(_ph_02_invalid_transformer_terminals(net))
    issues.extend(_ph_03_neutral_without_ground_return(net))
    issues.extend(_ph_04_load_phase_not_on_bus(net))
    issues.extend(_ph_05_phase_ordering_anomalies(net))
    return issues


# ---------------------------------------------------------------------------
# ph_01 — Load on phase not served by upstream line (per-phase BFS)
# ---------------------------------------------------------------------------

def _ph_01_load_on_unreachable_phase(net: Any) -> list[dict[str, Any]]:
    from ._connectivity import conductive_graph, supplied_terminals
    from ._windings import phase_number
    graph = conductive_graph(net)
    reachable = supplied_terminals(net, graph)
    bus = get_table(net, "bus")
    issues = []
    # Each row is a load circuit; both terminals matter for 120-V and 240-V loads.
    for idx, row in get_table(net, "asymmetric_load").iterrows():
        if not is_in_service(row):
            continue
        for column in ("from_phase", "to_phase"):
            phase = phase_number(row.get(column))
            terminal = (row.get("bus"), phase)
            if phase is None or terminal not in bus.index or terminal in reachable:
                continue  # ph_04 handles missing/invalid terminals.
            issues.append(issue(
                "critical", "phase_connectivity", "asymmetric_load", elem_id(idx), column,
                f"Load {elem_id(idx)} circuit {idx}: terminal {terminal} is not supplied "
                "through active lines, switches, and transformer windings from any source.",
                "Verify both load terminals, upstream winding connections, and conductor/switch service state.",
                phase=phase, evidence={"load_index": idx, "bus": terminal[0], "terminal": phase,
                                      "field": column},
            ))
    return issues


# ---------------------------------------------------------------------------
# ph_02 — Invalid transformer winding terminals (not phase renumbering)
# ---------------------------------------------------------------------------

def _ph_02_invalid_transformer_terminals(net: Any) -> list[dict[str, Any]]:
    from ._windings import transformer_circuits, phase_number
    bus = get_table(net, "bus")
    if not isinstance(bus.index, pd.MultiIndex):
        return []
    issues = []
    for windings in transformer_circuits(net).values():
        for winding in windings:
            for column in ("from_phase", "to_phase"):
                phase = phase_number(winding.row.get(column))
                if phase is not None and (winding.bus, phase) in bus.index and winding.terminals is not None:
                    continue
                issues.append(issue(
                    "high", "phase_connectivity", "trafo1ph", winding.transformer, column,
                    f"Transformer {winding.transformer} circuit {winding.circuit} winding at bus "
                    f"{winding.bus} has invalid {column}={winding.row.get(column)} or identical terminals.",
                    "Connect each winding between two distinct terminals present at its own bus. "
                    "Different phase numbers across windings and phase-to-phase connections are allowed.",
                    phase=phase, evidence=winding.evidence,
                ))
    return issues


# ---------------------------------------------------------------------------
# ph_03 — Neutral conductor present without ground return
# ---------------------------------------------------------------------------

def _ph_03_neutral_without_ground_return(net: Any) -> list[dict[str, Any]]:
    from ._connectivity import conductive_graph, grounded_terminals
    graph = conductive_graph(net)
    grounded = grounded_terminals(net, graph)
    issues = []
    for left, right, data in graph.edges(data=True):
        if data.get("element") != "line" or (left[1] != 0 and right[1] != 0):
            continue
        if left in grounded or right in grounded:
            continue
        issues.append(issue(
            "high", "phase_connectivity", "line", data["index"], "neutral",
            f"Line {data['index']} neutral connection {left} → {right} has no conductive path to ground.",
            "Verify neutral continuity through lines and closed switches to a grounded terminal.",
            phase=0, evidence={"from_terminal": left, "to_terminal": right},
        ))
    return issues


# ---------------------------------------------------------------------------
# ph_04 — Single-phase load on bus but phase not available
# ---------------------------------------------------------------------------

def _ph_04_load_phase_not_on_bus(net: Any) -> list[dict[str, Any]]:
    from ._windings import phase_number
    bus = get_table(net, "bus")
    if not isinstance(bus.index, pd.MultiIndex):
        return []
    issues = []
    for idx, row in get_table(net, "asymmetric_load").iterrows():
        if not is_in_service(row):
            continue
        for column in ("from_phase", "to_phase"):
            if column not in row:
                continue
            phase = phase_number(row[column])
            if phase is not None and (row.get("bus"), phase) in bus.index:
                continue
            issues.append(issue(
                "medium", "phase_connectivity", "asymmetric_load", elem_id(idx), column,
                f"Load {elem_id(idx)} circuit {idx} has {column}={row[column]}, "
                f"which is not a terminal on bus {row.get('bus')}.",
                "Correct both load terminal assignments to match available bus terminals.",
                phase=phase, evidence={"load_index": idx, "bus": row.get("bus"), "field": column},
            ))
    return issues


# ---------------------------------------------------------------------------
# ph_05 — Phase ordering anomalies
# ---------------------------------------------------------------------------

def _ph_05_phase_ordering_anomalies(net: Any) -> list[dict[str, Any]]:
    issues: list[dict[str, Any]] = []
    line = get_table(net, "line")
    if line.empty or "from_phase" not in line.columns or "to_phase" not in line.columns:
        return issues

    for eid, row in dedup_iter(line):
        if not is_in_service(row):
            continue
        fp = safe_float(row.get("from_phase"))
        tp = safe_float(row.get("to_phase"))
        if fp is None or tp is None:
            continue
        # Phase swap: from_phase and to_phase should match for direct connections
        if int(fp) != 0 and int(tp) != 0 and int(fp) != int(tp):
            issues.append(issue(
                "low", "phase_connectivity", "line", eid, "from_phase/to_phase",
                f"Line {eid} has phase swap: from_phase={int(fp)} → to_phase={int(tp)}.",
                "Verify this is intentional or correct the phase mapping.",
            ))
    return issues
