"""Category 7 — Load Model Problems.

Checks: ld_01 through ld_05.
Phase 1 implements ld_02, ld_05 (power-factor, imbalance).
Phase 3 adds ld_01, ld_03, ld_04 (cross-table aggregation).
"""
from __future__ import annotations

import math
from typing import Any

import pandas as pd

from ._common import (
    get_table,
    get_bus_vn_kv,
    is_in_service,
    safe_float,
    dedup_iter,
    issue,
)


def check_load_model(net: Any, *, include_capacity_checks: bool = True) -> list[dict[str, Any]]:
    """Run all load model checks."""
    issues: list[dict[str, Any]] = []
    if include_capacity_checks:
        issues.extend(_ld_01_load_exceeds_transformer_capacity(net))
    issues.extend(_ld_02_power_factor_out_of_range(net))
    if include_capacity_checks:
        issues.extend(_ld_03_load_on_wrong_voltage_level(net))
    issues.extend(_ld_05_unbalanced_loading(net))
    return issues


# ---------------------------------------------------------------------------
# ld_01 — Load kVA exceeds transformer capacity (Phase 3)
# ---------------------------------------------------------------------------

def _ld_01_load_exceeds_transformer_capacity(net: Any) -> list[dict[str, Any]]:
    from ._windings import transformer_circuits
    from collections import defaultdict
    # This is a connected-load screen at winding buses, not a solved loading
    # estimate. Sum input-port ratings across magnetic circuits. The first
    # table row can be a half-rated secondary leg and is not a device rating.
    by_transformer = defaultdict(list)
    for windings in transformer_circuits(net).values():
        for winding in windings:
            by_transformer[winding.transformer].append(winding)
    load_per_bus = defaultdict(float)
    for _, row in get_table(net, "asymmetric_load").iterrows():
        if not is_in_service(row):
            continue
        p, q = safe_float(row.get("p_mw")), safe_float(row.get("q_mvar")) or 0.0
        scaling = safe_float(row.get("scaling"))
        if p is not None:
            load_per_bus[row.get("bus")] += math.hypot(p, q) * abs(scaling if scaling is not None else 1.0)
    issues = []
    for tid, windings in by_transformer.items():
        rated = [(safe_float(w.row.get("vn_kv")) or 0, w.bus) for w in windings]
        if len({w.bus for w in windings}) < 2:
            continue
        hv_bus = max(rated, key=lambda item: item[0])[1]
        input_windings = [w for w in windings if w.bus == hv_bus]
        ratings = [safe_float(w.row.get("sn_mva")) for w in input_windings]
        if any(sn is None or not math.isfinite(sn) or sn <= 0 for sn in ratings):
            continue
        capacity = sum(ratings)
        secondary_buses = {w.bus for w in windings if w.bus != hv_bus}
        demand = sum(load_per_bus[b] for b in secondary_buses)
        if demand > capacity * 1.5:
            issues.append(issue(
                "high", "load_model", "trafo1ph", tid, "sn_mva",
                f"Transformer {tid} has {capacity:.4f} MVA of input-winding capacity and "
                f"{demand:.4f} MVA of connected load at its secondary buses ({demand/capacity*100:.0f}%).",
                "Verify connected-load allocation and winding ratings, then run power flow for actual loading.",
                evidence={"input_bus": hv_bus, "secondary_buses": sorted(secondary_buses),
                          "input_winding_rows": [w.position for w in input_windings],
                          "capacity_mva": capacity, "connected_load_mva": demand},
            ))
    return issues


# ---------------------------------------------------------------------------
# ld_02 — Power factor out of range
# ---------------------------------------------------------------------------

def _ld_02_power_factor_out_of_range(net: Any) -> list[dict[str, Any]]:
    issues: list[dict[str, Any]] = []
    load = get_table(net, "asymmetric_load")
    if load.empty or "p_mw" not in load.columns or "q_mvar" not in load.columns:
        return issues

    for eid, row in dedup_iter(load):
        if not is_in_service(row):
            continue
        p = safe_float(row.get("p_mw"))
        q = safe_float(row.get("q_mvar"))
        if p is None or q is None:
            continue
        s = math.sqrt(p**2 + q**2)
        if s < 1e-12:
            continue
        pf = abs(p) / s
        if pf < 0.70:
            issues.append(issue(
                "high", "load_model", "asymmetric_load", eid, "p_mw/q_mvar",
                f"Load {eid} power factor = {pf:.3f} is below 0.70.",
                "Verify reactive power or add power factor correction.",
            ))
    return issues


# ---------------------------------------------------------------------------
# ld_03 — Load on wrong voltage level (Phase 3)
# ---------------------------------------------------------------------------

def _ld_03_load_on_wrong_voltage_level(net: Any) -> list[dict[str, Any]]:
    issues: list[dict[str, Any]] = []
    load = get_table(net, "asymmetric_load")
    bus = get_table(net, "bus")
    if load.empty or bus.empty or "bus" not in load.columns or "p_mw" not in load.columns:
        return issues

    for eid, row in dedup_iter(load):
        if not is_in_service(row):
            continue
        p = safe_float(row.get("p_mw"))
        bus_val = row.get("bus")
        if p is None or bus_val is None:
            continue
        vn = get_bus_vn_kv(bus, bus_val)
        if vn is None:
            continue
        # Small residential load (< 0.001 MW = 1 kW) on a primary bus (> 4 kV)
        if abs(p) < 0.001 and vn > 4.0:
            issues.append(issue(
                "medium", "load_model", "asymmetric_load", eid, "bus/p_mw",
                f"Load {eid} has p_mw={p:.6f} (< 1 kW) on {vn:.2f} kV bus — "
                f"possible secondary load on primary bus.",
                "Verify load is on the correct bus and voltage level.",
            ))
    return issues


# ---------------------------------------------------------------------------
# ld_05 — Unbalanced loading exceeds threshold
# ---------------------------------------------------------------------------

def _ld_05_unbalanced_loading(net: Any) -> list[dict[str, Any]]:
    issues: list[dict[str, Any]] = []
    load = get_table(net, "asymmetric_load")
    if load.empty or "bus" not in load.columns or "p_mw" not in load.columns:
        return issues
    if "from_phase" not in load.columns:
        return issues

    from ._connectivity import split_bus_legs
    split = split_bus_legs(net)
    # Allocate a hot-to-hot load equally to the two center-tap legs. Its
    # from_phase is a connection orientation, not a one-leg power allocation.
    bus_phase_p: dict[Any, dict[int, float]] = {}
    for _, row in load.iterrows():
        if not is_in_service(row):
            continue
        bus_val = row.get("bus")
        phase = safe_float(row.get("from_phase"))
        p = safe_float(row.get("p_mw"))
        if bus_val is None or phase is None or p is None:
            continue
        ph = int(phase)
        tp = safe_float(row.get("to_phase"))
        tp = int(tp) if tp is not None else 0
        scaling = safe_float(row.get("scaling"))
        p *= scaling if scaling is not None else 1.0
        targets = {ph, tp} - {0}
        if bus_val not in split:
            targets = {ph} - {0}
        if not targets:
            continue
        totals = bus_phase_p.setdefault(bus_val, {})
        if bus_val in split:
            for leg in split[bus_val]:
                totals.setdefault(leg, 0.0)
        for leg in targets:
            totals[leg] = totals.get(leg, 0.0) + p / len(targets)

    for bus_val, phase_dict in bus_phase_p.items():
        if len(phase_dict) < 2:
            continue
        values = list(phase_dict.values())
        avg = sum(values) / len(values)
        if avg < 1e-12:
            continue
        max_v, min_v = max(values), min(values)
        imbalance = (max_v - min_v) / avg
        if imbalance > 0.20:
            issues.append(issue(
                "low", "load_model", "bus", bus_val, "p_mw",
                f"Bus {bus_val} phase loading imbalance = {imbalance*100:.1f}% "
                f"(phases: {phase_dict}).",
                "Redistribute loads across phases to reduce imbalance.",
            ))
    return issues
