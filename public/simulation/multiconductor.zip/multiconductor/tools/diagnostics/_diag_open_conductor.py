"""Category 6 — Open Conductor Issues.

Checks: oc_01 through oc_04.
"""
from __future__ import annotations

from typing import Any

import pandas as pd

from ._common import (
    get_table,
    elem_id,
    is_in_service,
    safe_float,
    dedup_iter,
    get_element_circuits,
    issue,
    build_network_graph,
)


def check_open_conductor(net: Any) -> list[dict[str, Any]]:
    """Run all open conductor checks."""
    issues: list[dict[str, Any]] = []
    issues.extend(_oc_01_phase_mismatch_between_ends(net))
    issues.extend(_oc_02_single_phasing(net))
    issues.extend(_oc_03_series_element_with_oos_bus(net))
    issues.extend(_oc_04_open_switch_isolates_loads(net))
    return issues


# ---------------------------------------------------------------------------
# oc_01 — Phase present at from_bus but missing at to_bus
# ---------------------------------------------------------------------------

def _oc_01_phase_mismatch_between_ends(net: Any) -> list[dict[str, Any]]:
    issues: list[dict[str, Any]] = []
    line = get_table(net, "line")
    if line.empty or "from_phase" not in line.columns or "to_phase" not in line.columns:
        return issues

    seen: set = set()
    for idx, row in line.iterrows():
        eid = elem_id(idx)
        if eid in seen:
            continue
        if not is_in_service(row):
            continue
        seen.add(eid)

        circuits = get_element_circuits(line, eid)
        if circuits is None or circuits.empty:
            continue
        from_phases = set(circuits["from_phase"].dropna().astype(int).tolist())
        to_phases = set(circuits["to_phase"].dropna().astype(int).tolist())

        if from_phases and to_phases and from_phases != to_phases:
            missing_at_to = from_phases - to_phases
            missing_at_from = to_phases - from_phases
            if missing_at_to:
                issues.append(issue(
                    "critical", "open_conductor", "line", eid, "from_phase/to_phase",
                    f"Line {eid}: phases {sorted(missing_at_to)} present at from_bus "
                    f"but missing at to_bus — possible open conductor.",
                    "Check for broken conductor or incorrect phase assignment.",
                ))
            if missing_at_from:
                issues.append(issue(
                    "critical", "open_conductor", "line", eid, "from_phase/to_phase",
                    f"Line {eid}: phases {sorted(missing_at_from)} present at to_bus "
                    f"but missing at from_bus.",
                    "Check for broken conductor or incorrect phase assignment.",
                ))
    return issues


# ---------------------------------------------------------------------------
# oc_02 — Single-phasing: 3-phase bus with only 2 phases served
# ---------------------------------------------------------------------------

def _oc_02_single_phasing(net: Any) -> list[dict[str, Any]]:
    from ._connectivity import conductive_graph, supplied_terminals, split_bus_legs
    from ._windings import transformer_circuits, phase_number
    graph = conductive_graph(net)
    supplied = supplied_terminals(net, graph)
    split = split_bus_legs(net, graph)
    expected = {}
    def expect(bus_id, phase):
        phase = phase_number(phase)
        if phase not in (None, 0) and (bus_id, phase) in graph:
            expected.setdefault(bus_id, set()).add(phase)
    # Imported bus tables can include unused terminal placeholders. A terminal
    # referenced by equipment is expected even if its conductor is now open.
    for _, row in get_table(net, "line").iterrows():
        expect(row.get("from_bus"), row.get("from_phase"))
        expect(row.get("to_bus"), row.get("to_phase"))
    for windings in transformer_circuits(net, active_only=False).values():
        for winding in windings:
            for column in ("from_phase", "to_phase"):
                expect(winding.bus, winding.row.get(column))
    for name in ("asymmetric_load", "asymmetric_sgen", "ext_grid", "ext_grid_sequence"):
        for _, row in get_table(net, name).iterrows():
            for column in ("from_phase", "to_phase"):
                expect(row.get("bus"), row.get(column))
    issues = []
    for bus_id, phases in expected.items():
        # Some imported split-phase buses carry an unused third-phase row.
        # Their winding ports define two legs; a load on the extra phase is
        # still checked independently by ph_01.
        if bus_id in split or len(phases) != 3:
            continue
        served = {phase for phase in phases if (bus_id, phase) in supplied}
        if len(served) == 2:
            missing = phases - served
            issues.append(issue(
                "high", "open_conductor", "bus", bus_id, "phase",
                f"3-phase bus {bus_id} is only supplied on 2 phases; missing {sorted(missing)}.",
                "Check source, transformer, switch, and line connections for the missing phase.",
                evidence={"bus": bus_id, "missing_phases": sorted(missing)},
            ))
    return issues


# ---------------------------------------------------------------------------
# oc_03 — Series element with one end out-of-service
# ---------------------------------------------------------------------------

def _oc_03_series_element_with_oos_bus(net: Any) -> list[dict[str, Any]]:
    issues: list[dict[str, Any]] = []
    bus = get_table(net, "bus")
    line = get_table(net, "line")
    if bus.empty or line.empty:
        return issues

    # Build set of in-service buses
    in_service_buses: set = set()
    if isinstance(bus.index, pd.MultiIndex):
        for idx in bus.index:
            if "in_service" not in bus.columns or bus.at[idx, "in_service"]:
                in_service_buses.add(idx[0])
    else:
        for idx, row in bus.iterrows():
            if is_in_service(row):
                in_service_buses.add(idx)

    for eid, row in dedup_iter(line):
        if not is_in_service(row):
            continue
        fb = row.get("from_bus")
        tb = row.get("to_bus")
        fb_ok = fb in in_service_buses
        tb_ok = tb in in_service_buses
        if fb_ok != tb_ok:
            oos_bus = fb if not fb_ok else tb
            issues.append(issue(
                "high", "open_conductor", "line", eid, "bus",
                f"Line {eid} is in-service but endpoint bus {oos_bus} is out of service.",
                "Disable the line or restore the bus to service.",
            ))
    return issues


# ---------------------------------------------------------------------------
# oc_04 — Open switch isolates downstream loads
# ---------------------------------------------------------------------------

def _oc_04_open_switch_isolates_loads(net: Any) -> list[dict[str, Any]]:
    issues: list[dict[str, Any]] = []
    sw = get_table(net, "switch")
    if sw.empty:
        return issues

    load = get_table(net, "asymmetric_load")
    load_buses: set = set()
    if not load.empty and "bus" in load.columns:
        load_buses = set(load["bus"].dropna().unique().tolist())

    if not load_buses:
        return issues

    # Build graph WITH all switches closed to get full topology
    graph_full = build_network_graph(net)

    # For each open switch, check if removing it would strand loads
    for eid, row in dedup_iter(sw):
        if bool(row.get("closed", True)):
            continue
        # This switch is open — check if there are loads only reachable via this switch
        bus_val = row.get("bus")
        element_val = row.get("element")
        et = row.get("et")
        if et != "b" or bus_val is None or element_val is None:
            continue
        # Temporarily check: if this switch were closed, does it connect to loads?
        if element_val not in graph_full:
            continue
        component = set()
        # Do a BFS from element_val side excluding the switch endpoint
        import networkx as nx
        temp_graph = graph_full.copy()
        if temp_graph.has_edge(bus_val, element_val):
            temp_graph.remove_edge(bus_val, element_val)
        if element_val in temp_graph:
            component = nx.node_connected_component(temp_graph, element_val)
        stranded_loads = component.intersection(load_buses)
        if stranded_loads:
            issues.append(issue(
                "medium", "open_conductor", "switch", eid, "closed",
                f"Open switch {eid} isolates {len(stranded_loads)} bus(es) with loads.",
                "Verify this is intentional or close the switch to restore service.",
            ))
    return issues
