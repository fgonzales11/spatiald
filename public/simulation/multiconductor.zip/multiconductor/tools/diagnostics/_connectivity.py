"""Separate conductive ground paths from transformer-mediated supply paths."""
from __future__ import annotations

from collections import defaultdict, deque
from typing import Any

import networkx as nx
import pandas as pd

from ._common import get_table, is_in_service, elem_id
from ._windings import phase_number, transformer_circuits, split_secondary_pairs


def conductive_graph(net: Any) -> nx.Graph:
    """Active terminal connections through wires and closed switches only.

    Magnetic coupling must never act as a galvanic neutral/earth connection.
    """
    graph = nx.Graph()
    bus = get_table(net, "bus")
    if not isinstance(bus.index, pd.MultiIndex):
        return graph
    for idx, row in bus.iterrows():
        if is_in_service(row):
            graph.add_node((idx[0], idx[1]), grounded=bool(row.get("grounded", False)))
    blocked = set()
    for _, row in get_table(net, "switch").iterrows():
        if not is_in_service(row):
            continue
        phase = phase_number(row.get("phase"))
        if not bool(row.get("closed", True)) and row.get("et") in ("l", "t"):
            blocked.add((row.get("et"), row.get("element"), row.get("bus"), phase))
    graph.graph["blocked"] = blocked
    for idx, row in get_table(net, "line").iterrows():
        if not is_in_service(row):
            continue
        fp, tp = (phase_number(row.get(col)) for col in ("from_phase", "to_phase"))
        left, right = (row.get("from_bus"), fp), (row.get("to_bus"), tp)
        if any(("l", elem_id(idx), b, p) in blocked or ("l", elem_id(idx), b, None) in blocked
               for b, p in (left, right)):
            continue
        if left in graph and right in graph:
            graph.add_edge(left, right, element="line", index=elem_id(idx))
    for idx, row in get_table(net, "switch").iterrows():
        if not is_in_service(row) or not bool(row.get("closed", True)) or row.get("et") != "b":
            continue
        phase = phase_number(row.get("phase"))
        phases = [phase] if phase is not None else [p for b, p in graph if b == row.get("bus")]
        for p in phases:
            left, right = (row.get("bus"), p), (row.get("element"), p)
            if left in graph and right in graph:
                graph.add_edge(left, right, element="switch", index=elem_id(idx))
    return graph


def connected_windings(net: Any, graph: nx.Graph):
    blocked = graph.graph.get("blocked", set())
    for key, windings in transformer_circuits(net).items():
        valid = []
        for winding in windings:
            terminals = winding.terminals
            if terminals is None or any(t not in graph for t in terminals):
                continue
            if any(("t", winding.transformer, b, p) in blocked
                   or ("t", winding.transformer, b, None) in blocked for b, p in terminals):
                continue
            valid.append(winding)
        if len(valid) >= 2:
            yield key, valid


def grounded_terminals(net: Any, graph: nx.Graph | None = None) -> set[tuple]:
    if graph is None:
        graph = conductive_graph(net)
    grounded = set()
    for component in nx.connected_components(graph):
        if any(graph.nodes[t].get("grounded", False) for t in component):
            grounded.update(component)
    return grounded


def split_bus_legs(net: Any, graph: nx.Graph | None = None) -> dict[Any, set[int]]:
    """Follow both center-tap hot legs through secondary wires and switches."""
    if graph is None:
        graph = conductive_graph(net)
    component_of = {}
    components = list(nx.connected_components(graph))
    for number, component in enumerate(components):
        component_of.update(dict.fromkeys(component, number))
    legs = defaultdict(set)
    for left, right in split_secondary_pairs(transformer_circuits(net)):
        hot = [next(t for t in w.terminals if t[1] != 0) for w in (left, right)]
        if any(t not in component_of for t in hot):
            continue
        first, second = (components[component_of[t]] for t in hot)
        common_buses = {b for b, p in first if p != 0} & {b for b, p in second if p != 0}
        for bus, phase in first | second:
            if bus in common_buses and phase != 0:
                legs[bus].add(phase)
    return dict(legs)


def source_terminals(net: Any, graph: nx.Graph) -> set[tuple]:
    sources = set()
    for name in ("ext_grid", "ext_grid_sequence"):
        table = get_table(net, name)
        for _, row in table.iterrows():
            if not is_in_service(row):
                continue
            if "from_phase" in table:
                phases = [phase_number(row.get(col)) for col in ("from_phase", "to_phase")]
            else:
                phases = [p for b, p in graph if b == row.get("bus")]
            for phase in phases:
                terminal = (row.get("bus"), phase)
                if phase not in (None, 0) and terminal in graph:
                    sources.add(terminal)
    return sources


def supplied_terminals(net: Any, graph: nx.Graph | None = None) -> set[tuple]:
    """Propagate excitation per magnetic circuit, requiring both input terminals.

    A grounded neutral alone cannot energize a winding. Once a winding is
    excited, all active ports in its circuit can supply their connected legs.
    This includes reverse-fed transformers without assuming HV/LV row order.
    """
    if graph is None:
        graph = conductive_graph(net)
    components = list(nx.connected_components(graph))
    component_of = {terminal: number for number, terms in enumerate(components) for terminal in terms}
    referenced = {number for number, terms in enumerate(components)
                  if any(graph.nodes[t].get("grounded", False) for t in terms)}
    energized = {component_of[t] for t in source_terminals(net, graph)}
    available = referenced | energized
    circuits = dict(connected_windings(net, graph))
    dependents = defaultdict(set)
    for key, windings in circuits.items():
        for winding in windings:
            for terminal in winding.terminals:
                dependents[component_of[terminal]].add(key)
    pending = deque(circuits)
    queued = set(circuits)
    activated = set()
    while pending:
        key = pending.popleft()
        queued.discard(key)
        if key in activated:
            continue
        windings = circuits[key]
        excited = any(
            all(component_of[t] in available for t in w.terminals)
            and component_of[w.terminals[0]] != component_of[w.terminals[1]]
            and any(t[1] != 0 and component_of[t] in energized for t in w.terminals)
            for w in windings
        )
        if not excited:
            continue
        activated.add(key)
        for winding in windings:
            for terminal in winding.terminals:
                component = component_of[terminal]
                changed = component not in available or (terminal[1] != 0 and component not in energized)
                available.add(component)
                if terminal[1] != 0:
                    energized.add(component)
                if changed:
                    for dependent in dependents[component] - activated - queued:
                        pending.append(dependent)
                        queued.add(dependent)
    return {terminal for component in available for terminal in components[component]}


def network_graph(net: Any, *, per_phase: bool = False) -> nx.Graph:
    conductors = conductive_graph(net)
    graph = conductors.copy() if per_phase else nx.Graph()
    if not per_phase:
        graph.add_nodes_from(b for b, _ in conductors)
        # Retain support for scalar bus tables in lightweight legacy checks.
        bus = get_table(net, "bus")
        if not isinstance(bus.index, pd.MultiIndex):
            graph.add_nodes_from(idx for idx, row in bus.iterrows() if is_in_service(row))
            for idx, row in get_table(net, "line").iterrows():
                if is_in_service(row) and row.get("from_bus") in graph and row.get("to_bus") in graph:
                    graph.add_edge(row.from_bus, row.to_bus, element="line", index=elem_id(idx))
        for left, right, data in conductors.edges(data=True):
            if left[0] != right[0]:
                graph.add_edge(left[0], right[0], **data)
    for (tid, _), windings in connected_windings(net, conductors):
        if per_phase:
            # Supply adjacency only; use supplied_terminals for excitation and
            # conductive_graph for ground paths. Never join magnetic neutrals.
            hot = list(dict.fromkeys(t for w in windings for t in w.terminals if t[1] != 0))
            for terminal in hot[1:]:
                graph.add_edge(hot[0], terminal, element="trafo1ph", index=tid)
        else:
            buses = list(dict.fromkeys(w.bus for w in windings))
            for other in buses[1:]:
                graph.add_edge(buses[0], other, element="trafo1ph", index=tid)
    return graph
