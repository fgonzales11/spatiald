"""Category 2 — Transformer Modeling Errors.

Checks: tx_01 through tx_07.
"""
from __future__ import annotations

from typing import Any

import pandas as pd

from ._common import (
    get_table,
    is_in_service,
    safe_float,
    dedup_iter,
    issue,
)


def check_transformers(net: Any) -> list[dict[str, Any]]:
    """Run all transformer modeling checks."""
    issues: list[dict[str, Any]] = []
    issues.extend(_tx_01_zero_or_missing_impedance(net))
    issues.extend(_tx_02_turns_ratio_vs_bus_kv(net))
    issues.extend(_tx_03_sn_mva_out_of_range(net))
    issues.extend(_tx_04_tap_at_extreme(net))
    issues.extend(_tx_05_center_tap_grounding(net))
    issues.extend(_tx_06_xr_ratio(net))
    issues.extend(_tx_07_center_tap_polarity(net))
    return issues


def _parameter_rows(net: Any):
    """Inspect every winding, including the two rows of a center tap."""
    from ._windings import transformer_circuits, split_secondary_pairs
    circuits = transformer_circuits(net)
    split = {(left.transformer, left.circuit) for left, _ in split_secondary_pairs(circuits)}
    for key, windings in circuits.items():
        for winding in windings:
            yield "trafo1ph", winding.transformer, winding.row, winding.evidence, key in split
    for eid, row in dedup_iter(get_table(net, "trafo")):
        if is_in_service(row):
            yield "trafo", eid, row, {}, False


# ---------------------------------------------------------------------------
# tx_01 — Zero, missing, or inconsistent winding impedance
# ---------------------------------------------------------------------------

def _tx_01_zero_or_missing_impedance(net: Any) -> list[dict[str, Any]]:
    import math
    issues = []
    for table, eid, row, evidence, _ in _parameter_rows(net):
        vk, vkr = (safe_float(row.get(col)) for col in ("vk_percent", "vkr_percent"))
        for column, value, invalid in (
            ("vk_percent", vk, vk is None or not math.isfinite(vk) or vk <= 0),
            ("vkr_percent", vkr, vkr is None or not math.isfinite(vkr) or vkr < 0),
        ):
            if invalid:
                issues.append(issue(
                    "critical", "transformer_model", table, eid, column,
                    f"Transformer {eid} winding has invalid {column}={value}.",
                    "Verify each winding's short-circuit impedance and copper losses against nameplate data.",
                    evidence=evidence,
                ))
        if vk is not None and vkr is not None and 0 < vk < vkr:
            issues.append(issue(
                "critical", "transformer_model", table, eid, "vk_percent/vkr_percent",
                f"Transformer {eid} winding resistance ({vkr}%) exceeds impedance magnitude ({vk}%).",
                "Correct inconsistent winding short-circuit test values; resistance cannot exceed |Z|.",
                evidence=evidence,
            ))
    return issues


# ---------------------------------------------------------------------------
# tx_02 — Turns ratio vs bus kV mismatch
# ---------------------------------------------------------------------------

def _tx_02_turns_ratio_vs_bus_kv(net: Any) -> list[dict[str, Any]]:
    from ._windings import winding_voltage_issues
    return winding_voltage_issues(net, "transformer_model")


# ---------------------------------------------------------------------------
# tx_03 — sn_mva out of range
# ---------------------------------------------------------------------------

def _tx_03_sn_mva_out_of_range(net: Any) -> list[dict[str, Any]]:
    import math
    issues = []
    for table, eid, row, evidence, _ in _parameter_rows(net):
        sn = safe_float(row.get("sn_mva"))
        if sn is None or not math.isfinite(sn) or sn <= 0 or sn > 500:
            issues.append(issue(
                "high", "transformer_model", table, eid, "sn_mva",
                f"Transformer {eid} winding sn_mva={sn} is missing, non-positive, or exceeds 500 MVA.",
                "Verify this winding's apparent power rating and units against nameplate data.",
                evidence=evidence,
            ))
    return issues


# ---------------------------------------------------------------------------
# tx_04 — Tap position at extreme
# ---------------------------------------------------------------------------

def _tx_04_tap_at_extreme(net: Any) -> list[dict[str, Any]]:
    issues = []
    for table, eid, row, evidence, _ in _parameter_rows(net):
        start = len(issues)
        _check_tap_extreme(issues, table, eid, row)
        for finding in issues[start:]:
            finding["evidence"] = evidence
    return issues


def _check_tap_extreme(issues: list, table_name: str, eid: Any, row: pd.Series) -> None:
    tap_pos = safe_float(row.get("tap_pos"))
    tap_min = safe_float(row.get("tap_min"))
    tap_max = safe_float(row.get("tap_max"))
    if tap_pos is None or tap_min is None or tap_max is None:
        return
    if tap_min == tap_max or safe_float(row.get("tap_step_percent")) == 0:
        return  # A fixed winding is not an exhausted regulating tap.
    if tap_pos == tap_min:
        issues.append(issue(
            "medium", "transformer_model", table_name, eid, "tap_pos",
            f"Transformer {eid} tap is at minimum ({tap_pos}).",
            "This may indicate a voltage regulation issue — verify intentional.",
        ))
    elif tap_pos == tap_max:
        issues.append(issue(
            "medium", "transformer_model", table_name, eid, "tap_pos",
            f"Transformer {eid} tap is at maximum ({tap_pos}).",
            "This may indicate a voltage regulation issue — verify intentional.",
        ))


# ---------------------------------------------------------------------------
# tx_05 — Center-tap / split-phase grounding
# ---------------------------------------------------------------------------

def _tx_05_center_tap_grounding(net: Any) -> list[dict[str, Any]]:
    from ._connectivity import grounded_terminals
    from ._windings import transformer_circuits, split_secondary_pairs
    grounded = grounded_terminals(net)
    issues = []
    for left, right in split_secondary_pairs(transformer_circuits(net)):
        neutral = (left.bus, 0)
        if neutral not in grounded:
            issues.append(issue(
                "medium", "transformer_model", "trafo1ph", left.transformer, "grounding",
                f"Split-phase transformer {left.transformer} circuit {left.circuit} center tap "
                f"at bus {left.bus}, terminal 0, has no conductive path to ground.",
                "Verify center-tap neutral grounding locally or through the secondary neutral. "
                "A grounded primary or grounded hot leg does not ground the center tap.",
                phase=0, evidence={**left.evidence, "neutral_terminal": neutral,
                                   "winding_rows": [left.position, right.position]},
            ))
    return issues


# ---------------------------------------------------------------------------
# tx_06 — X/R ratio out of typical range
# ---------------------------------------------------------------------------

def _tx_06_xr_ratio(net: Any) -> list[dict[str, Any]]:
    import math
    issues = []
    for table, eid, row, evidence, split in _parameter_rows(net):
        vk, vkr = (safe_float(row.get(col)) for col in ("vk_percent", "vkr_percent"))
        if vk is None or vkr is None or not math.isfinite(vk + vkr) or vkr <= 0 or vk < vkr:
            continue
        xr = math.sqrt(vk * vk - vkr * vkr) / vkr
        # Center-tap secondary legs legitimately have different, relatively
        # resistive impedances. The generic large-transformer lower bound does
        # not establish a defect in these small distribution windings.
        if xr > 50 or (not split and xr < 2):
            issues.append(issue(
                "low", "transformer_model", table, eid, "vk_percent/vkr_percent",
                f"Transformer {eid} winding X/R={xr:.2f}; verify against its test report.",
                "Check this winding's resistance and reactance against nameplate data; "
                "vk_percent is impedance magnitude, not reactance.",
                evidence={**evidence, "xr_ratio": xr, "split_phase": split},
            ))
    return issues


def _tx_07_center_tap_polarity(net: Any) -> list[dict[str, Any]]:
    """Two legs in one magnetic circuit must oppose about their common neutral."""
    from ._windings import transformer_circuits, split_secondary_pairs
    issues = []
    for left, right in split_secondary_pairs(transformer_circuits(net)):
        if (left.terminals[0][1] == 0) != (right.terminals[0][1] == 0):
            continue
        issues.append(issue(
            "high", "transformer_model", "trafo1ph", left.transformer, "from_phase/to_phase",
            f"Split-phase transformer {left.transformer} circuit {left.circuit} at bus {left.bus} "
            "has both secondary windings oriented the same way about neutral; "
            "the two hot legs will not have the expected opposite polarity.",
            "Verify the winding diagram: connect hot leg 1 → neutral and neutral → hot leg 2 "
            "within the same transformer circuit (or reverse both orientations).",
            evidence={"bus": left.bus, "circuit": left.circuit,
                      "winding_rows": [left.position, right.position],
                      "connections": [left.terminals, right.terminals]},
        ))
    return issues
