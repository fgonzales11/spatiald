"""Native transformer ports, preserving repeated (index, bus, circuit) rows.

``from_phase`` and ``to_phase`` are the two terminals of ONE winding at ONE
bus. Windings sharing (transformer, circuit) are magnetically coupled. In a
center tap, hot1 -> neutral and neutral -> hot2 legitimately share an index.
"""
from __future__ import annotations

from collections import defaultdict
from dataclasses import dataclass
import math
from typing import Any

import pandas as pd

from ._common import get_table, get_bus_vn_kv, is_in_service, safe_float, issue


def phase_number(value: Any) -> int | None:
    value = safe_float(value)
    return int(value) if value is not None and math.isfinite(value) and value.is_integer() else None


@dataclass(frozen=True)
class Winding:
    transformer: Any
    bus: Any
    circuit: Any
    position: int
    row: pd.Series

    @property
    def terminals(self) -> tuple[tuple, tuple] | None:
        fp, tp = (phase_number(self.row.get(col)) for col in ("from_phase", "to_phase"))
        if fp is None or tp is None or fp == tp:
            return None
        return (self.bus, fp), (self.bus, tp)

    @property
    def evidence(self) -> dict:
        return {"bus": self.bus, "circuit": self.circuit, "row_position": self.position,
                "from_phase": phase_number(self.row.get("from_phase")),
                "to_phase": phase_number(self.row.get("to_phase"))}


def transformer_circuits(net: Any, *, active_only: bool = True) -> dict[tuple, list[Winding]]:
    table = get_table(net, "trafo1ph")
    if not isinstance(table.index, pd.MultiIndex) or not {"bus", "circuit"}.issubset(table.index.names):
        return {}
    id_level = table.index.names.index("index") if "index" in table.index.names else 0
    bus_level, circuit_level = (table.index.names.index(name) for name in ("bus", "circuit"))
    circuits: dict[tuple, list[Winding]] = defaultdict(list)
    for position, (index, row) in enumerate(table.iterrows()):
        if active_only and not is_in_service(row):
            continue
        winding = Winding(index[id_level], index[bus_level], index[circuit_level], position, row)
        circuits[(winding.transformer, winding.circuit)].append(winding)
    return dict(circuits)


def split_secondary_pairs(circuits: dict[tuple, list[Winding]]):
    """Identify two secondary legs by ports, not by a 120/240-V heuristic.

    Include same-polarity pairs so the transformer checker can report them.
    A separate winding at another bus must exist in the same magnetic circuit.
    """
    for windings in circuits.values():
        by_bus: dict[Any, list[Winding]] = defaultdict(list)
        for winding in windings:
            by_bus[winding.bus].append(winding)
        if len(by_bus) < 2:
            continue
        for bus_windings in by_bus.values():
            if len(bus_windings) != 2:
                continue
            left, right = bus_windings
            if left.terminals is None or right.terminals is None:
                continue
            lp, rp = set(left.terminals), set(right.terminals)
            if lp & rp == {(left.bus, 0)} and len(lp | rp) == 3:
                yield left, right


def row_identity(table_name: str, index: Any, row: pd.Series) -> tuple:
    """Full physical row identity used by duplicate checks and repair guards."""
    if table_name == "trafo1ph" and {"from_phase", "to_phase"}.issubset(row.index):
        phases = [phase_number(row[col]) for col in ("from_phase", "to_phase")]
        if None not in phases:
            return index, tuple(sorted(phases))
    return (index,)


def duplicate_row_groups(table_name: str, table: pd.DataFrame) -> list[list[int]]:
    groups = defaultdict(list)
    for position, (index, row) in enumerate(table.iterrows()):
        groups[row_identity(table_name, index, row)].append(position)
    return [positions for positions in groups.values() if len(positions) > 1]


def winding_voltage_issues(net: Any, category: str) -> list[dict]:
    """Compare actual coil ratings with the native solver's terminal base.

    MC stores a line-line-equivalent bus base even on a split-phase bus; every
    terminal uses bus.vn_kv / sqrt(3). A 120-V leg thus has a ~0.208-kV bus base.
    """
    bus = get_table(net, "bus")
    circuits = transformer_circuits(net)
    from ._connectivity import split_bus_legs
    split_legs = split_bus_legs(net)
    issues = []
    for windings in circuits.values():
        for winding in windings:
            terminals = winding.terminals
            actual = safe_float(winding.row.get("vn_kv"))
            base = get_bus_vn_kv(bus, winding.bus)
            if terminals is None or base is None or not math.isfinite(base) or base <= 0:
                continue
            if isinstance(bus.index, pd.MultiIndex) and any(t not in bus.index for t in terminals):
                continue  # ph_02 reports the invalid terminal, not a guessed base.
            phases = {terminal[1] for terminal in terminals}
            if 0 in phases:
                expected, connection = base / math.sqrt(3), "phase-to-neutral"
            elif phases.issubset(split_legs.get(winding.bus, set())):
                expected, connection = 2 * base / math.sqrt(3), "split-phase hot-to-hot"
            else:
                expected, connection = base, "phase-to-phase"
            if actual is None or not math.isfinite(actual) or actual <= 0:
                issues.append(issue(
                    "high", category, "trafo1ph", winding.transformer, "vn_kv",
                    f"Transformer {winding.transformer} winding at bus {winding.bus} has "
                    f"missing or non-positive voltage rating {actual}.",
                    "Set the verified terminal-to-terminal winding voltage in kV.",
                    evidence={**winding.evidence, "expected_winding_kv": expected,
                              "connection": connection},
                ))
                continue
            mismatch = abs(actual - expected) / max(actual, expected)
            if mismatch > 0.10:
                issues.append(issue(
                    "high", category, "trafo1ph", winding.transformer, "vn_kv",
                    f"Transformer {winding.transformer} circuit {winding.circuit} winding "
                    f"at bus {winding.bus} ({connection}, {terminals[0][1]} → {terminals[1][1]}): "
                    f"rated {actual:.4f} kV; expected {expected:.4f} kV from MC bus base "
                    f"{base:.4f} kV ({mismatch * 100:.1f}% mismatch).",
                    "Verify the winding's terminal-to-terminal rating and the MC bus base "
                    "(phase-to-neutral base = bus vn_kv / sqrt(3)). Preserve center-tap polarity.",
                    evidence={**winding.evidence, "winding_vn_kv": actual, "bus_vn_kv": base,
                              "expected_winding_kv": expected, "connection": connection,
                              "relative_mismatch": mismatch},
                ))
    return issues
