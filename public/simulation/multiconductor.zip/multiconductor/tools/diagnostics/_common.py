"""Shared helpers for the diagnostics package.

Re-exports useful functions from network_validators and adds graph utilities
needed by multiple diagnostic modules.
"""
from __future__ import annotations

import inspect
import re
from typing import Any

import networkx as nx
import pandas as pd


# ---------------------------------------------------------------------------
# Issue builder (same contract as network_validators._issue)
# ---------------------------------------------------------------------------

def issue(
    severity: str,
    check: str,
    element_type: str,
    element_index: Any,
    field: str,
    message: str,
    suggestion: str,
    code: str | None = None,
    *,
    phase: int | None = None,
    evidence: Any | None = None,
) -> dict[str, Any]:
    if code is None:
        frame = inspect.currentframe()
        caller_frame = frame.f_back if frame is not None else None
        code = "unknown"
        while caller_frame is not None:
            match = re.match(r"^_([a-z]+_\d{2})_", caller_frame.f_code.co_name)
            if match:
                code = match.group(1)
                break
            caller_frame = caller_frame.f_back
    return {
        "code": code,
        "category": check,
        "severity": severity,
        "check": check,
        "element_type": element_type,
        "element_index": element_index,
        "phase": phase,
        "field": field,
        "evidence": {"field": field} if evidence is None else evidence,
        "message": message,
        "recommendation": suggestion,
        "suggestion": suggestion,
    }


# ---------------------------------------------------------------------------
# Table / index helpers
# ---------------------------------------------------------------------------

def get_table(net: Any, name: str) -> pd.DataFrame:
    table = getattr(net, name, None)
    if isinstance(table, pd.DataFrame):
        return table
    return pd.DataFrame()


def unique_bus_ids(bus: pd.DataFrame) -> set:
    if bus.empty:
        return set()
    if isinstance(bus.index, pd.MultiIndex):
        return set(bus.index.get_level_values(0).unique().tolist())
    return set(bus.index.tolist())


def elem_id(idx: Any) -> Any:
    """Extract the scalar element id from a possibly-tuple MultiIndex key."""
    return idx[0] if isinstance(idx, tuple) else idx


def get_bus_vn_kv(bus: pd.DataFrame, bus_id: Any) -> float | None:
    if bus.empty or "vn_kv" not in bus.columns:
        return None
    if isinstance(bus.index, pd.MultiIndex):
        try:
            sub = bus.xs(bus_id, level=0)
            vn = sub["vn_kv"]
            return safe_float(vn.iloc[0] if hasattr(vn, "iloc") else vn)
        except (KeyError, TypeError, IndexError):
            return None
    try:
        return safe_float(bus.at[bus_id, "vn_kv"])
    except (KeyError, TypeError):
        return None


def is_in_service(row: pd.Series) -> bool:
    if "in_service" not in row.index:
        return True
    return bool(row.get("in_service", True))


def safe_float(value: Any) -> float | None:
    try:
        if value is None or (isinstance(value, float) and pd.isna(value)):
            return None
        return float(value)
    except (TypeError, ValueError):
        return None


def dedup_iter(table: pd.DataFrame):
    """Yield (element_id, first_row) for each unique element, skipping MultiIndex duplicates."""
    seen: set = set()
    for idx, row in table.iterrows():
        eid = elem_id(idx)
        if eid in seen:
            continue
        seen.add(eid)
        yield eid, row


def get_element_circuits(table: pd.DataFrame, eid: Any) -> pd.DataFrame | None:
    """Get all circuit/phase rows for an element from a possibly-MultiIndex table."""
    if not isinstance(table.index, pd.MultiIndex):
        try:
            return table.loc[[eid]]
        except KeyError:
            return None
    try:
        return table.xs(eid, level=0)
    except (KeyError, TypeError):
        return None


# ---------------------------------------------------------------------------
# Graph builders (used by topology, grounding, phase, open-conductor checks)
# ---------------------------------------------------------------------------

def build_network_graph(net: Any, per_phase: bool = False) -> nx.Graph:
    """Active branch adjacency; transformer ports are grouped by magnetic circuit.

    For electrical supply use ``supplied_terminals``; for grounding use the
    conductive graph, which deliberately excludes transformer coupling.
    """
    from ._connectivity import network_graph
    return network_graph(net, per_phase=per_phase)


def trafo1ph_bus_pair(trafo1ph: pd.DataFrame, trafo_id: Any) -> tuple[Any, Any] | None:
    """Extract (hv_bus, lv_bus) for a trafo1ph element from its MultiIndex."""
    if trafo1ph.empty or not isinstance(trafo1ph.index, pd.MultiIndex):
        return None
    idx_level = trafo1ph.index.names.index("index") if "index" in trafo1ph.index.names else 0
    bus_level_name = "bus" if "bus" in trafo1ph.index.names else None
    if bus_level_name is None:
        return None
    try:
        sub = trafo1ph.xs(trafo_id, level=idx_level)
        bus_lv = sub.index.names.index(bus_level_name) if bus_level_name in sub.index.names else 0
        buses = list(dict.fromkeys(sub.index.get_level_values(bus_lv).tolist()))
    except Exception:
        return None
    if len(buses) < 2:
        return None
    # Native indices are sorted by bus ID; that is not a voltage-side order.
    if "vn_kv" in sub:
        ratings = sub.groupby(level=bus_lv)["vn_kv"].max()
        buses.sort(key=lambda b: safe_float(ratings.get(b)) or 0, reverse=True)
    return (buses[0], buses[-1])


def bfs_from_sources(net: Any, graph: nx.Graph | None = None) -> set:
    """Return set of bus IDs reachable from any ext_grid or ext_grid_sequence bus."""
    if graph is None:
        graph = build_network_graph(net)

    source_buses: set = set()
    eg = get_table(net, "ext_grid")
    if not eg.empty and "bus" in eg.columns:
        source_buses.update(row["bus"] for _, row in eg.iterrows() if is_in_service(row))
    egs = get_table(net, "ext_grid_sequence")
    if not egs.empty and "bus" in egs.columns:
        source_buses.update(row["bus"] for _, row in egs.iterrows() if is_in_service(row))

    reachable: set = set()
    for src in source_buses:
        if src in graph:
            reachable.update(nx.node_connected_component(graph, src))
    return reachable
