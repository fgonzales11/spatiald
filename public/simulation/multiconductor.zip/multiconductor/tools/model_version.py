"""Version records for pickled network models.

This module creates small JSON sidecars that can be committed with network
model pickle files.  The sidecar records an exact pickle hash, a canonical
loaded-model hash, table counts, and optional operator metadata.  Pickle files
must only be inspected when they come from a trusted source.
"""

from __future__ import annotations

import argparse
import copy
import hashlib
import hmac
import json
import math
import os
import pickle
import platform
import re
import shutil
import sys
from collections.abc import Mapping
from datetime import date, datetime, timezone
from decimal import Decimal
from pathlib import Path
from typing import Any, Iterable, Optional, Sequence, Union

try:
    from multiconductor._version import __version__ as _MULTICONDUCTOR_VERSION
except Exception:  # pragma: no cover - direct script execution fallback
    _MULTICONDUCTOR_VERSION = None


SCHEMA_VERSION = "network-model-version/v1"
DEFAULT_CHUNK_SIZE = 1024 * 1024
DEFAULT_VERSION_STORE = ".network-model-versions"
DEFAULT_MODEL_TYPE = "historical"
MODEL_TYPES = ("forecast", "historical")
DEFAULT_SNOWFLAKE_TABLE = "MODEL_VERSION"
SNOWFLAKE_MODEL_VERSION_COLUMNS = (
    "SCHEMA_VERSION",
    "VERSION_ID",
    "MODEL_TYPE",
    "CREATED_AT",
    "FEEDER_ID",
    "PICKLE_PATH",
    "PICKLE_FILENAME",
    "PICKLE_SIZE_BYTES",
    "PICKLE_MODIFIED_AT",
    "PICKLE_SHA256",
    "PICKLE_SHORT_SHA256",
    "BINARY_ENCODED_CA",
    "MODEL_HASH",
    "MODEL_SHORT_HASH",
    "MODEL_INSPECTED",
    "IGNORE_RESULT_TABLES",
    "SUMMARY",
    "METADATA",
    "ENVIRONMENT",
    "SNAPSHOT",
    "RECORD_JSON",
)

_MISSING = object()
_PD: Any = _MISSING
_NP: Any = _MISSING
_MEMORY_ADDRESS_RE = re.compile(r" at 0x[0-9a-fA-F]+")
_SAFE_NAME_RE = re.compile(r"[^A-Za-z0-9_.-]+")
_SNOWFLAKE_IDENTIFIER_RE = re.compile(r"^[A-Za-z_][A-Za-z0-9_$]*$")
_SNOWFLAKE_VARIANT_COLUMNS = {"SUMMARY", "METADATA", "ENVIRONMENT", "SNAPSHOT", "RECORD_JSON"}
_SNOWFLAKE_TIMESTAMP_COLUMNS = {"CREATED_AT", "PICKLE_MODIFIED_AT"}
_SNOWFLAKE_BINARY_COLUMNS = {"BINARY_ENCODED_CA"}
_SHA256_RE = re.compile(r"^[0-9a-f]{64}$")

_RESULT_TABLE_PREFIXES = ("res_", "_empty_res_")
_VOLATILE_MODEL_KEYS = {
    "_is_elements",
    "_options",
    "_pd2ppc_lookups",
    "_ppc",
    "_ppc0",
    "_ppc1",
    "_ppc2",
}

_NETWORK_TABLE_HINTS = (
    "bus",
    "line",
    "switch",
    "trafo",
    "trafo3w",
    "trafo1ph",
    "center_tap_trafo",
    "ext_grid",
    "ext_grid_sequence",
    "load",
    "asymmetric_load",
    "sgen",
    "asymmetric_sgen",
    "gen",
    "asymmetric_gen",
    "shunt",
    "storage",
    "ward",
    "xward",
    "impedance",
    "measurement",
    "controller",
    "group",
    "bus_geodata",
    "line_geodata",
    "std_types",
    "configuration_std_type",
    "matrix_std_type",
)


def utc_now_iso() -> str:
    """Return an ISO-8601 UTC timestamp with a stable ``Z`` suffix."""

    return datetime.now(timezone.utc).replace(microsecond=0).isoformat().replace("+00:00", "Z")


PathLike = Union[os.PathLike[str], str]
RecordOrPath = Union[Mapping[str, Any], PathLike]


class PickleTrustError(ValueError):
    """Raised when a pickle artifact is not approved or fails integrity checks."""


def hash_file(path: PathLike, chunk_size: int = DEFAULT_CHUNK_SIZE) -> str:
    """Compute the SHA-256 digest of a file without loading it into memory."""

    file_path = Path(path)
    digest = hashlib.sha256()
    with file_path.open("rb") as handle:
        for chunk in iter(lambda: handle.read(chunk_size), b""):
            digest.update(chunk)
    return digest.hexdigest()


def hash_bytes(data: bytes) -> str:
    """Compute the SHA-256 digest of in-memory bytes."""

    return hashlib.sha256(data).hexdigest()


def read_file_bytes(path: PathLike) -> bytes:
    """Read a file as raw bytes."""

    with Path(path).expanduser().open("rb") as handle:
        return handle.read()


def load_pickle(path: PathLike) -> Any:
    """Load a pickle file.

    Pickle can execute code during loading.  Only call this for pickle files
    that are trusted within your model-development workflow.
    """

    with Path(path).open("rb") as handle:
        return pickle.load(handle)


def validate_approved_version_record(record_or_path: RecordOrPath) -> dict[str, Any]:
    """Validate the trust metadata required before loading a pickle artifact.

    Approval is an explicit operator decision stored as
    ``metadata.approved=true``.  Inspection and a canonical model hash prove
    that the approved record was created from a successfully loaded model.
    """

    record = (
        read_version_record(record_or_path)
        if isinstance(record_or_path, (str, os.PathLike))
        else dict(record_or_path)
    )
    if record.get("schema_version") != SCHEMA_VERSION:
        raise PickleTrustError(
            f"Unsupported version-record schema: {record.get('schema_version')!r}"
        )

    metadata = record.get("metadata", {})
    model = record.get("model", {})
    pickle_info = record.get("pickle", {})
    if not isinstance(metadata, Mapping) or metadata.get("approved") is not True:
        raise PickleTrustError("Network model version is not approved")
    if not isinstance(model, Mapping) or model.get("inspected") is not True:
        raise PickleTrustError("Approved network model was not successfully inspected")
    if "load_error" in model:
        raise PickleTrustError("Approved network model record contains a load error")
    if not isinstance(pickle_info, Mapping):
        raise PickleTrustError("Approved network model record has invalid pickle metadata")

    pickle_hash = str(pickle_info.get("sha256", "")).lower()
    model_hash = str(model.get("hash", "")).lower()
    if not _SHA256_RE.fullmatch(pickle_hash):
        raise PickleTrustError("Approved network model record has no valid pickle SHA-256")
    if not _SHA256_RE.fullmatch(model_hash):
        raise PickleTrustError("Approved network model record has no valid canonical model hash")
    return record


def read_verified_pickle_bytes(
    pickle_path: PathLike,
    record_or_path: RecordOrPath,
) -> tuple[bytes, dict[str, Any]]:
    """Read and verify an approved pickle without deserializing it.

    The returned bytes are the exact buffer whose digest was checked.  Callers
    that deserialize must use this buffer rather than reopening the path.
    """

    record = validate_approved_version_record(record_or_path)
    path = Path(pickle_path).expanduser()
    expected_filename = record.get("pickle", {}).get("filename")
    if expected_filename and path.name != expected_filename:
        raise PickleTrustError("Network model filename does not match its approved record")

    data = read_file_bytes(path)
    expected_hash = str(record["pickle"]["sha256"]).lower()
    actual_hash = hash_bytes(data)
    if not hmac.compare_digest(expected_hash, actual_hash):
        raise PickleTrustError("Network model pickle SHA-256 does not match its approved record")
    return data, record


def load_verified_pickle(pickle_path: PathLike, record_or_path: RecordOrPath) -> Any:
    """Load an approved pickle after verifying the same bytes being decoded."""

    data, record = read_verified_pickle_bytes(pickle_path, record_or_path)
    return load_verified_pickle_bytes(data, record)


def load_verified_pickle_bytes(data: bytes, record_or_path: RecordOrPath) -> Any:
    """Load approved in-memory bytes after verifying their exact record."""

    record = validate_approved_version_record(record_or_path)
    expected_hash = str(record["pickle"]["sha256"]).lower()
    actual_hash = hash_bytes(data)
    if not hmac.compare_digest(expected_hash, actual_hash):
        raise PickleTrustError("Network model pickle SHA-256 does not match its approved record")
    model = pickle.loads(data)
    expected_model_hash = str(record["model"]["hash"]).lower()
    actual_model_hash = hash_model(
        model,
        ignore_result_tables=bool(record["model"].get("ignore_result_tables", True)),
    )
    if not hmac.compare_digest(expected_model_hash, actual_model_hash):
        raise PickleTrustError(
            "Loaded network model hash does not match its approved record"
        )
    return model


def canonical_json(value: Any, *, ignore_result_tables: bool = True) -> str:
    """Serialize a Python object into deterministic JSON for hashing."""

    normalized = _normalize(value, ignore_result_tables=ignore_result_tables, seen=set())
    return json.dumps(
        normalized,
        allow_nan=False,
        ensure_ascii=True,
        separators=(",", ":"),
        sort_keys=True,
    )


def compute_hash(value: Any, *, ignore_result_tables: bool = True, length: Optional[int] = None) -> str:
    """Compute a deterministic SHA-256 hash for structured Python values."""

    digest = hashlib.sha256(canonical_json(value, ignore_result_tables=ignore_result_tables).encode("utf-8"))
    value_hash = digest.hexdigest()
    return value_hash[:length] if length is not None else value_hash


def hash_model(model: Any, *, ignore_result_tables: bool = True) -> str:
    """Compute a canonical hash for a loaded network model object."""

    return compute_hash(model, ignore_result_tables=ignore_result_tables)


def normalize_model_type(model_type: str) -> str:
    """Validate and normalize a network model type."""

    normalized = str(model_type).strip().lower()
    if normalized not in MODEL_TYPES:
        allowed = ", ".join(MODEL_TYPES)
        raise ValueError(f"model_type must be one of: {allowed}")
    return normalized


def create_version_record(
    pickle_path: PathLike,
    *,
    version_id: Optional[str] = None,
    model_type: str = DEFAULT_MODEL_TYPE,
    feeder_id: Optional[str] = None,
    metadata: Optional[Mapping[str, Any]] = None,
    inspect_pickle: bool = True,
    ignore_result_tables: bool = True,
    created_at: Optional[str] = None,
) -> dict[str, Any]:
    """Create a version-control record for a network pickle.

    The exact pickle SHA tracks byte-for-byte artifact changes.  When
    ``inspect_pickle`` is true, the function also loads the pickle and computes
    a canonical model hash for content-level comparisons.
    """

    resolved_model_type = normalize_model_type(model_type)
    path = Path(pickle_path).expanduser().resolve()
    if not path.is_file():
        raise FileNotFoundError(f"No pickle file found at {path}")

    stat = path.stat()
    pickle_sha256 = hash_file(path)
    summary: dict[str, Any] = {}
    model_hash: Optional[str] = None
    load_error: Optional[str] = None

    if inspect_pickle:
        try:
            model = load_pickle(path)
            summary = summarize_network_model(model, ignore_result_tables=ignore_result_tables)
            model_hash = hash_model(model, ignore_result_tables=ignore_result_tables)
        except Exception as exc:
            load_error = f"{type(exc).__name__}: {exc}"

    timestamp = created_at or utc_now_iso()
    resolved_feeder_id = feeder_id or summary.get("name") or path.stem
    resolved_version_id = version_id or _default_version_id(timestamp, model_hash or pickle_sha256)

    record = {
        "schema_version": SCHEMA_VERSION,
        "version_id": resolved_version_id,
        "model_type": resolved_model_type,
        "created_at": timestamp,
        "feeder_id": str(resolved_feeder_id),
        "pickle": {
            "path": str(path),
            "filename": path.name,
            "size_bytes": stat.st_size,
            "modified_at": _datetime_from_timestamp(stat.st_mtime),
            "sha256": pickle_sha256,
            "short_sha256": pickle_sha256[:12],
        },
        "model": {
            "hash": model_hash,
            "short_hash": model_hash[:12] if model_hash else None,
            "inspected": inspect_pickle and load_error is None,
            "ignore_result_tables": ignore_result_tables,
            "summary": summary,
        },
        "environment": {
            "python": platform.python_version(),
            "platform": platform.platform(),
            "multiconductor_version": _MULTICONDUCTOR_VERSION,
        },
        "metadata": dict(metadata or {}),
    }
    if load_error:
        record["model"]["load_error"] = load_error
    return record


def default_record_path(pickle_path: PathLike) -> Path:
    """Return the conventional sidecar path for a pickle version record."""

    path = Path(pickle_path)
    if path.suffix:
        return path.with_suffix(path.suffix + ".version.json")
    return path.with_name(path.name + ".version.json")


def write_version_record(record: Mapping[str, Any], output_path: Optional[PathLike] = None) -> Path:
    """Write a version record JSON file atomically."""

    target = Path(output_path) if output_path else default_record_path(str(record["pickle"]["path"]))
    target = target.expanduser().resolve()
    target.parent.mkdir(parents=True, exist_ok=True)
    tmp_path = target.with_name(target.name + ".tmp")
    with tmp_path.open("w", encoding="utf-8") as handle:
        json.dump(record, handle, indent=2, sort_keys=True)
        handle.write("\n")
    os.replace(tmp_path, target)
    return target


def snowflake_model_version_ddl(table_name: str = DEFAULT_SNOWFLAKE_TABLE) -> str:
    """Return DDL for the Snowflake model-version table."""

    table = _snowflake_table_name(table_name)
    return f"""CREATE TABLE IF NOT EXISTS {table} (
    SCHEMA_VERSION VARCHAR NOT NULL,
    VERSION_ID VARCHAR NOT NULL,
    MODEL_TYPE VARCHAR(20) NOT NULL
        CONSTRAINT MODEL_VERSION_MODEL_TYPE_CK CHECK (MODEL_TYPE IN ('forecast', 'historical')),
    CREATED_AT TIMESTAMP_TZ NOT NULL,
    FEEDER_ID VARCHAR NOT NULL,
    PICKLE_PATH VARCHAR,
    PICKLE_FILENAME VARCHAR,
    PICKLE_SIZE_BYTES NUMBER(38,0),
    PICKLE_MODIFIED_AT TIMESTAMP_TZ,
    PICKLE_SHA256 VARCHAR(64),
    PICKLE_SHORT_SHA256 VARCHAR(12),
    BINARY_ENCODED_CA BINARY,
    MODEL_HASH VARCHAR(64),
    MODEL_SHORT_HASH VARCHAR(12),
    MODEL_INSPECTED BOOLEAN,
    IGNORE_RESULT_TABLES BOOLEAN,
    SUMMARY VARIANT,
    METADATA VARIANT,
    ENVIRONMENT VARIANT,
    SNAPSHOT VARIANT,
    RECORD_JSON VARIANT,
    INGESTED_AT TIMESTAMP_TZ DEFAULT CURRENT_TIMESTAMP(),
    CONSTRAINT MODEL_VERSION_PK PRIMARY KEY (FEEDER_ID, MODEL_TYPE, VERSION_ID)
)"""


def snowflake_model_version_row(record: Mapping[str, Any]) -> dict[str, Any]:
    """Flatten a version record into the Snowflake table shape."""

    model = record.get("model", {})
    pickle_info = record.get("pickle", {})
    return {
        "SCHEMA_VERSION": record.get("schema_version", SCHEMA_VERSION),
        "VERSION_ID": record.get("version_id"),
        "MODEL_TYPE": normalize_model_type(record.get("model_type", DEFAULT_MODEL_TYPE)),
        "CREATED_AT": record.get("created_at"),
        "FEEDER_ID": record.get("feeder_id"),
        "PICKLE_PATH": pickle_info.get("path"),
        "PICKLE_FILENAME": pickle_info.get("filename"),
        "PICKLE_SIZE_BYTES": pickle_info.get("size_bytes"),
        "PICKLE_MODIFIED_AT": pickle_info.get("modified_at"),
        "PICKLE_SHA256": pickle_info.get("sha256"),
        "PICKLE_SHORT_SHA256": pickle_info.get("short_sha256"),
        "BINARY_ENCODED_CA": _record_pickle_bytes(record),
        "MODEL_HASH": model.get("hash"),
        "MODEL_SHORT_HASH": model.get("short_hash"),
        "MODEL_INSPECTED": model.get("inspected"),
        "IGNORE_RESULT_TABLES": model.get("ignore_result_tables"),
        "SUMMARY": model.get("summary", {}),
        "METADATA": record.get("metadata", {}),
        "ENVIRONMENT": record.get("environment", {}),
        "SNAPSHOT": record.get("snapshot", {}),
        "RECORD_JSON": dict(record),
    }


def snowflake_model_version_insert_sql(
    record: Mapping[str, Any],
    table_name: str = DEFAULT_SNOWFLAKE_TABLE,
) -> str:
    """Return a Snowflake INSERT statement for a model-version record."""

    row = snowflake_model_version_row(record)
    columns = ", ".join(SNOWFLAKE_MODEL_VERSION_COLUMNS)
    values = ", ".join(
        _snowflake_value_expression(column, row.get(column))
        for column in SNOWFLAKE_MODEL_VERSION_COLUMNS
    )
    return f"INSERT INTO {_snowflake_table_name(table_name)} ({columns}) SELECT {values}"


def write_snowflake_insert_script(
    pkl_path: PathLike,
    output_path: PathLike,
    *,
    table_name: str = DEFAULT_SNOWFLAKE_TABLE,
    version_id: Optional[str] = None,
    model_type: str = DEFAULT_MODEL_TYPE,
    metadata: Optional[Mapping[str, Any]] = None,
    inspect_pickle: bool = False,
    ignore_result_tables: bool = True,
    pattern: str = "*.pkl",
) -> dict[str, Any]:
    """Write Snowflake INSERT statements for pickle files under ``pkl_path``."""

    source = Path(pkl_path).expanduser().resolve()
    files = _iter_pickle_files(source, pattern=pattern)
    target = Path(output_path).expanduser().resolve()
    target.parent.mkdir(parents=True, exist_ok=True)

    default_metadata = {"source_path": str(source)}
    default_metadata.update(dict(metadata or {}))

    with target.open("w", encoding="utf-8") as handle:
        handle.write("-- Generated by multiconductor.tools.model_version.write_snowflake_insert_script\n")
        handle.write(f"-- Source pickle path: {source}\n")
        handle.write(f"-- Target table: {_snowflake_table_name(table_name)}\n")
        handle.write("-- Binary payloads use HEX_DECODE_BINARY('<hex>') for Snowflake BINARY columns.\n\n")
        for index, pickle_file in enumerate(files, start=1):
            record = create_version_record(
                pickle_file,
                version_id=version_id,
                model_type=model_type,
                feeder_id=pickle_file.stem,
                metadata=default_metadata,
                inspect_pickle=inspect_pickle,
                ignore_result_tables=ignore_result_tables,
            )
            handle.write(f"-- {index}: {pickle_file.name}\n")
            handle.write(snowflake_model_version_insert_sql(record, table_name))
            handle.write(";\n\n")

    return {
        "output_path": str(target),
        "source_path": str(source),
        "table_name": table_name,
        "file_count": len(files),
        "size_bytes": target.stat().st_size,
    }


def persist_version_record_to_snowflake(
    snowflake_client: Any,
    record_or_path: RecordOrPath,
    *,
    table_name: str = DEFAULT_SNOWFLAKE_TABLE,
    create_table: bool = True,
) -> dict[str, Any]:
    """Persist a model-version record to Snowflake.

    ``snowflake_client`` may be a Snowpark ``Session``, a Snowflake connector
    connection, or a Snowflake connector cursor.  The function returns the
    flattened row that was inserted.
    """

    record = (
        read_version_record(record_or_path)
        if isinstance(record_or_path, (str, os.PathLike))
        else dict(record_or_path)
    )
    if create_table:
        _execute_snowflake_statement(snowflake_client, snowflake_model_version_ddl(table_name))
    _execute_snowflake_statement(
        snowflake_client,
        snowflake_model_version_insert_sql(record, table_name),
    )
    return snowflake_model_version_row(record)


def read_version_record(path: PathLike) -> dict[str, Any]:
    """Read a version record JSON sidecar."""

    with Path(path).expanduser().open("r", encoding="utf-8") as handle:
        record = json.load(handle)
    if record.get("schema_version") != SCHEMA_VERSION:
        raise ValueError(f"Unsupported version-record schema: {record.get('schema_version')!r}")
    return record


def verify_pickle_version(
    pickle_path: PathLike,
    record_or_path: RecordOrPath,
    *,
    inspect_pickle: bool = False,
) -> dict[str, Any]:
    """Verify that a pickle still matches a saved version record."""

    record = (
        read_version_record(record_or_path)
        if isinstance(record_or_path, (str, os.PathLike))
        else dict(record_or_path)
    )
    current = create_version_record(
        pickle_path,
        model_type=record.get("model_type", DEFAULT_MODEL_TYPE),
        feeder_id=record.get("feeder_id"),
        inspect_pickle=inspect_pickle,
        ignore_result_tables=record.get("model", {}).get("ignore_result_tables", True),
    )
    mismatches = []

    expected_pickle_hash = record.get("pickle", {}).get("sha256")
    current_pickle_hash = current.get("pickle", {}).get("sha256")
    if expected_pickle_hash != current_pickle_hash:
        mismatches.append(
            {
                "field": "pickle.sha256",
                "expected": expected_pickle_hash,
                "actual": current_pickle_hash,
            }
        )

    expected_model_hash = record.get("model", {}).get("hash")
    current_model_hash = current.get("model", {}).get("hash")
    if inspect_pickle and expected_model_hash and expected_model_hash != current_model_hash:
        mismatches.append(
            {
                "field": "model.hash",
                "expected": expected_model_hash,
                "actual": current_model_hash,
            }
        )

    return {
        "matches": not mismatches,
        "mismatches": mismatches,
        "expected": record,
        "current": current,
    }


def compare_version_records(
    left: RecordOrPath,
    right: RecordOrPath,
) -> dict[str, Any]:
    """Compare two saved version records."""

    left_record = read_version_record(left) if isinstance(left, (str, os.PathLike)) else dict(left)
    right_record = read_version_record(right) if isinstance(right, (str, os.PathLike)) else dict(right)

    left_tables = left_record.get("model", {}).get("summary", {}).get("table_counts", {})
    right_tables = right_record.get("model", {}).get("summary", {}).get("table_counts", {})

    return {
        "same_pickle": left_record.get("pickle", {}).get("sha256") == right_record.get("pickle", {}).get("sha256"),
        "same_model": left_record.get("model", {}).get("hash") == right_record.get("model", {}).get("hash"),
        "same_model_type": left_record.get("model_type", DEFAULT_MODEL_TYPE)
        == right_record.get("model_type", DEFAULT_MODEL_TYPE),
        "left": _compact_record(left_record),
        "right": _compact_record(right_record),
        "table_count_changes": _diff_table_counts(left_tables, right_tables),
    }


def snapshot_pickle_version(
    pickle_path: PathLike,
    store_dir: PathLike = DEFAULT_VERSION_STORE,
    *,
    version_id: Optional[str] = None,
    model_type: str = DEFAULT_MODEL_TYPE,
    feeder_id: Optional[str] = None,
    metadata: Optional[Mapping[str, Any]] = None,
    inspect_pickle: bool = True,
    ignore_result_tables: bool = True,
) -> tuple[dict[str, Any], Path, Path]:
    """Copy a pickle into a version store and write its sidecar record."""

    source_path = Path(pickle_path).expanduser().resolve()
    record = create_version_record(
        source_path,
        version_id=version_id,
        model_type=model_type,
        feeder_id=feeder_id,
        metadata=metadata,
        inspect_pickle=inspect_pickle,
        ignore_result_tables=ignore_result_tables,
    )
    safe_feeder = _safe_name(record["feeder_id"])
    model_dir = Path(store_dir).expanduser().resolve() / safe_feeder
    model_dir.mkdir(parents=True, exist_ok=True)

    suffix = source_path.suffix or ".pkl"
    artifact_name = f"{_safe_name(record['version_id'])}__{record['pickle']['short_sha256']}{suffix}"
    artifact_path = model_dir / artifact_name
    if not artifact_path.exists():
        shutil.copy2(source_path, artifact_path)

    record = copy.deepcopy(record)
    record["snapshot"] = {
        "pickle_path": str(artifact_path),
        "record_path": str(default_record_path(artifact_path)),
        "history_path": str(model_dir / "history.jsonl"),
    }
    record_path = write_version_record(record, record["snapshot"]["record_path"])
    _append_history(record["snapshot"]["history_path"], record)
    return record, artifact_path, record_path


def summarize_network_model(model: Any, *, ignore_result_tables: bool = True) -> dict[str, Any]:
    """Extract lightweight metadata from a loaded pandapower-style network."""

    name = _network_name(model)
    summary: dict[str, Any] = {
        "type": _type_name(model),
        "name": name,
        "table_counts": {},
        "tables": {},
    }

    for table_name in _iter_network_table_names(model):
        if ignore_result_tables and _is_volatile_model_key(table_name):
            continue
        try:
            table = _get_model_value(model, table_name)
        except Exception:
            continue
        table_summary = _summarize_table(table)
        if table_summary is None:
            continue
        summary["table_counts"][table_name] = table_summary["rows"]
        summary["tables"][table_name] = table_summary

    return summary


def format_version_record(record: Mapping[str, Any]) -> str:
    """Format the important record fields for terminal output."""

    lines = [
        f"Version: {record.get('version_id')}",
        f"Model type: {record.get('model_type', DEFAULT_MODEL_TYPE)}",
        f"Feeder: {record.get('feeder_id')}",
        f"Pickle: {record.get('pickle', {}).get('filename')}",
        f"Pickle SHA-256: {record.get('pickle', {}).get('short_sha256')}",
    ]
    model = record.get("model", {})
    if model.get("hash"):
        lines.append(f"Model hash: {model.get('short_hash')}")
    if model.get("load_error"):
        lines.append(f"Model inspect error: {model.get('load_error')}")
    table_counts = model.get("summary", {}).get("table_counts", {})
    if table_counts:
        counts = ", ".join(f"{name}={count}" for name, count in sorted(table_counts.items()))
        lines.append(f"Tables: {counts}")
    return "\n".join(lines)


def main(argv: Optional[Sequence[str]] = None) -> int:
    """CLI entry point."""

    args = list(sys.argv[1:] if argv is None else argv)
    if args and args[0] not in {
        "record",
        "snapshot",
        "check",
        "diff",
        "ddl",
        "bulk-inserts",
        "-h",
        "--help",
    }:
        args = ["record"] + args

    parser = _build_parser()
    namespace = parser.parse_args(args)

    if namespace.command == "record":
        metadata = _parse_metadata(namespace.metadata)
        record = create_version_record(
            namespace.pickle_path,
            version_id=namespace.version_id,
            model_type=namespace.model_type,
            feeder_id=namespace.feeder_id,
            metadata=metadata,
            inspect_pickle=not namespace.no_inspect,
            ignore_result_tables=not namespace.include_results,
        )
        output_path = write_version_record(record, namespace.output)
        if namespace.json:
            print(json.dumps({"record_path": str(output_path), "record": record}, indent=2, sort_keys=True))
        else:
            print(format_version_record(record))
            print(f"Record: {output_path}")
        return 0

    if namespace.command == "snapshot":
        metadata = _parse_metadata(namespace.metadata)
        record, artifact_path, record_path = snapshot_pickle_version(
            namespace.pickle_path,
            namespace.store_dir,
            version_id=namespace.version_id,
            model_type=namespace.model_type,
            feeder_id=namespace.feeder_id,
            metadata=metadata,
            inspect_pickle=not namespace.no_inspect,
            ignore_result_tables=not namespace.include_results,
        )
        if namespace.json:
            print(
                json.dumps(
                    {"pickle_path": str(artifact_path), "record_path": str(record_path), "record": record},
                    indent=2,
                    sort_keys=True,
                )
            )
        else:
            print(format_version_record(record))
            print(f"Snapshot pickle: {artifact_path}")
            print(f"Snapshot record: {record_path}")
        return 0

    if namespace.command == "check":
        result = verify_pickle_version(namespace.pickle_path, namespace.record, inspect_pickle=namespace.inspect)
        if namespace.json:
            print(json.dumps(result, indent=2, sort_keys=True))
        elif result["matches"]:
            print("OK: pickle matches version record")
        else:
            print("MISMATCH: pickle differs from version record")
            for mismatch in result["mismatches"]:
                print(f"  {mismatch['field']}: expected {mismatch['expected']} actual {mismatch['actual']}")
        return 0 if result["matches"] else 1

    if namespace.command == "diff":
        result = compare_version_records(namespace.left_record, namespace.right_record)
        if namespace.json:
            print(json.dumps(result, indent=2, sort_keys=True))
        else:
            print(f"Same pickle: {result['same_pickle']}")
            print(f"Same model: {result['same_model']}")
            print(f"Same model type: {result['same_model_type']}")
            for change in result["table_count_changes"]:
                print(
                    f"Table {change['table']}: "
                    f"{change['left_rows']} -> {change['right_rows']}"
                )
        return 0

    if namespace.command == "ddl":
        print(snowflake_model_version_ddl(namespace.table_name))
        return 0

    if namespace.command == "bulk-inserts":
        metadata = _parse_metadata(namespace.metadata)
        result = write_snowflake_insert_script(
            namespace.pkl_path,
            namespace.output,
            table_name=namespace.table_name,
            version_id=namespace.version_id,
            model_type=namespace.model_type,
            metadata=metadata,
            inspect_pickle=namespace.inspect,
            ignore_result_tables=not namespace.include_results,
            pattern=namespace.pattern,
        )
        if namespace.json:
            print(json.dumps(result, indent=2, sort_keys=True))
        else:
            print(f"Wrote {result['file_count']} INSERT statements to {result['output_path']}")
            print(f"SQL size: {result['size_bytes']} bytes")
        return 0

    parser.print_help()
    return 2


def _snowflake_table_name(table_name: str) -> str:
    return ".".join(_snowflake_identifier(part) for part in str(table_name).split("."))


def _snowflake_identifier(identifier: str) -> str:
    if identifier.startswith('"') and identifier.endswith('"'):
        return identifier
    if _SNOWFLAKE_IDENTIFIER_RE.match(identifier):
        return identifier
    escaped = identifier.replace('"', '""')
    return f'"{escaped}"'


def _snowflake_value_expression(column: str, value: Any) -> str:
    if value is None:
        return "NULL"
    if column in _SNOWFLAKE_BINARY_COLUMNS:
        if not isinstance(value, (bytes, bytearray, memoryview)):
            raise TypeError(f"{column} must be bytes, got {type(value).__name__}")
        return f"HEX_DECODE_BINARY({_snowflake_literal(bytes(value).hex().upper())})"
    if column in _SNOWFLAKE_VARIANT_COLUMNS:
        return f"PARSE_JSON({_snowflake_literal(_json_dumps(value))})"
    if column in _SNOWFLAKE_TIMESTAMP_COLUMNS:
        return f"TO_TIMESTAMP_TZ({_snowflake_literal(str(value))})"
    if isinstance(value, bool):
        return "TRUE" if value else "FALSE"
    if isinstance(value, (int, float)) and not isinstance(value, bool):
        return str(value)
    return _snowflake_literal(str(value))


def _snowflake_literal(value: str) -> str:
    return "'" + value.replace("'", "''") + "'"


def _json_dumps(value: Any) -> str:
    return json.dumps(value, ensure_ascii=True, sort_keys=True, default=str)


def _execute_snowflake_statement(snowflake_client: Any, sql: str) -> Any:
    if hasattr(snowflake_client, "sql"):
        return snowflake_client.sql(sql).collect()
    if hasattr(snowflake_client, "execute"):
        return snowflake_client.execute(sql)
    if hasattr(snowflake_client, "cursor"):
        cursor = snowflake_client.cursor()
        return cursor.execute(sql)
    raise TypeError("snowflake_client must be a Snowpark Session, connector connection, or connector cursor")


def _iter_pickle_files(source: Path, *, pattern: str = "*.pkl") -> list[Path]:
    if source.is_file():
        return [source]
    if source.is_dir():
        return sorted(path for path in source.rglob(pattern) if path.is_file())
    raise FileNotFoundError(f"No pickle file or directory found at {source}")


def _record_pickle_bytes(record: Mapping[str, Any]) -> Optional[bytes]:
    candidate_paths = [
        record.get("snapshot", {}).get("pickle_path"),
        record.get("pickle", {}).get("path"),
    ]
    for candidate in candidate_paths:
        if not candidate:
            continue
        path = Path(candidate).expanduser()
        if path.is_file():
            return read_file_bytes(path)
    return None


def _normalize(value: Any, *, ignore_result_tables: bool, seen: set[int]) -> Any:
    if value is None or isinstance(value, (bool, int, str)):
        return value
    if isinstance(value, float):
        return _normalize_float(value)
    if isinstance(value, Decimal):
        return {"__decimal__": str(value)}
    if isinstance(value, bytes):
        return {"__bytes_sha256__": hash_bytes(value), "size": len(value)}
    if isinstance(value, (datetime, date)):
        return {"__datetime__": value.isoformat()}
    if isinstance(value, Path):
        return str(value)

    value_id = id(value)
    if value_id in seen:
        return {"__cycle__": _type_name(value)}

    pd = _get_pandas()
    if pd is not None:
        if isinstance(value, pd.DataFrame):
            return _normalize_dataframe(value, ignore_result_tables=ignore_result_tables, seen=seen)
        if isinstance(value, pd.Series):
            return _normalize_series(value, ignore_result_tables=ignore_result_tables, seen=seen)
        if isinstance(value, pd.Index):
            return _normalize_index(value, ignore_result_tables=ignore_result_tables, seen=seen)
        if pd.isna(value) is True:
            return {"__missing__": True}

    np = _get_numpy()
    if np is not None:
        if isinstance(value, np.generic):
            return _normalize(value.item(), ignore_result_tables=ignore_result_tables, seen=seen)
        if isinstance(value, np.ndarray):
            seen.add(value_id)
            try:
                return {
                    "__ndarray__": True,
                    "dtype": str(value.dtype),
                    "shape": list(value.shape),
                    "data": _normalize(value.tolist(), ignore_result_tables=ignore_result_tables, seen=seen),
                }
            finally:
                seen.remove(value_id)

    if isinstance(value, Mapping):
        seen.add(value_id)
        try:
            pairs = []
            for key, item in value.items():
                if ignore_result_tables and _is_volatile_model_key(key):
                    continue
                normalized_key = _normalize(key, ignore_result_tables=ignore_result_tables, seen=seen)
                normalized_item = _normalize(item, ignore_result_tables=ignore_result_tables, seen=seen)
                pairs.append((normalized_key, normalized_item))
            pairs.sort(key=lambda pair: json.dumps(pair[0], sort_keys=True, default=str))
            return {"__mapping__": pairs}
        finally:
            seen.remove(value_id)

    if isinstance(value, (list, tuple)):
        seen.add(value_id)
        try:
            return [_normalize(item, ignore_result_tables=ignore_result_tables, seen=seen) for item in value]
        finally:
            seen.remove(value_id)

    if isinstance(value, (set, frozenset)):
        seen.add(value_id)
        try:
            normalized_items = [
                _normalize(item, ignore_result_tables=ignore_result_tables, seen=seen) for item in value
            ]
            return sorted(normalized_items, key=lambda item: json.dumps(item, sort_keys=True, default=str))
        finally:
            seen.remove(value_id)

    return {"__type__": _type_name(value), "__repr__": _stable_repr(value)}


def _normalize_dataframe(frame: Any, *, ignore_result_tables: bool, seen: set[int]) -> dict[str, Any]:
    value_id = id(frame)
    if value_id in seen:
        return {"__cycle__": _type_name(frame)}
    seen.add(value_id)
    try:
        columns = list(frame.columns)
        return {
            "__dataframe__": True,
            "shape": list(frame.shape),
            "index": _normalize_index(frame.index, ignore_result_tables=ignore_result_tables, seen=seen),
            "columns": [_normalize(column, ignore_result_tables=ignore_result_tables, seen=seen) for column in columns],
            "dtypes": [
                [
                    _normalize(column, ignore_result_tables=ignore_result_tables, seen=seen),
                    str(dtype),
                ]
                for column, dtype in frame.dtypes.items()
            ],
            "data": [
                [_normalize(cell, ignore_result_tables=ignore_result_tables, seen=seen) for cell in row]
                for row in frame.itertuples(index=False, name=None)
            ],
        }
    finally:
        seen.remove(value_id)


def _normalize_series(series: Any, *, ignore_result_tables: bool, seen: set[int]) -> dict[str, Any]:
    value_id = id(series)
    if value_id in seen:
        return {"__cycle__": _type_name(series)}
    seen.add(value_id)
    try:
        return {
            "__series__": True,
            "name": _normalize(series.name, ignore_result_tables=ignore_result_tables, seen=seen),
            "index": _normalize_index(series.index, ignore_result_tables=ignore_result_tables, seen=seen),
            "dtype": str(series.dtype),
            "data": [_normalize(item, ignore_result_tables=ignore_result_tables, seen=seen) for item in series.tolist()],
        }
    finally:
        seen.remove(value_id)


def _normalize_index(index: Any, *, ignore_result_tables: bool, seen: set[int]) -> dict[str, Any]:
    value_id = id(index)
    if value_id in seen:
        return {"__cycle__": _type_name(index)}
    seen.add(value_id)
    try:
        return {
            "__index__": True,
            "type": _type_name(index),
            "names": _normalize(list(getattr(index, "names", [])), ignore_result_tables=ignore_result_tables, seen=seen),
            "values": [_normalize(item, ignore_result_tables=ignore_result_tables, seen=seen) for item in index.tolist()],
        }
    finally:
        seen.remove(value_id)


def _normalize_float(value: float) -> Any:
    if math.isnan(value):
        return {"__float__": "NaN"}
    if math.isinf(value):
        return {"__float__": "Infinity" if value > 0 else "-Infinity"}
    return value


def _get_pandas() -> Any:
    global _PD
    if _PD is _MISSING:
        try:
            import pandas as pd

            _PD = pd
        except Exception:
            _PD = None
    return _PD


def _get_numpy() -> Any:
    global _NP
    if _NP is _MISSING:
        try:
            import numpy as np

            _NP = np
        except Exception:
            _NP = None
    return _NP


def _summarize_table(table: Any) -> Optional[dict[str, Any]]:
    pd = _get_pandas()
    if pd is not None and isinstance(table, pd.DataFrame):
        return {
            "rows": int(len(table)),
            "columns": [str(column) for column in table.columns],
            "dtypes": {str(column): str(dtype) for column, dtype in table.dtypes.items()},
        }
    if isinstance(table, Mapping):
        return {"rows": int(len(table)), "columns": sorted(str(key) for key in table.keys())}
    if hasattr(table, "__len__") and not isinstance(table, (str, bytes)):
        try:
            return {"rows": int(len(table)), "columns": []}
        except Exception:
            return None
    return None


def _iter_network_table_names(model: Any) -> Iterable[str]:
    seen = set()
    if isinstance(model, Mapping):
        for key in model.keys():
            if isinstance(key, str):
                seen.add(key)
                yield key
    for key in _NETWORK_TABLE_HINTS:
        if key not in seen and hasattr(model, key):
            seen.add(key)
            yield key


def _get_model_value(model: Any, name: str) -> Any:
    if isinstance(model, Mapping) and name in model:
        return model[name]
    return getattr(model, name)


def _network_name(model: Any) -> Optional[str]:
    for source in ("name",):
        try:
            if isinstance(model, Mapping) and source in model and model[source]:
                return str(model[source])
            value = getattr(model, source, None)
            if value:
                return str(value)
        except Exception:
            continue
    return None


def _is_volatile_model_key(key: Any) -> bool:
    key_text = str(key)
    return key_text in _VOLATILE_MODEL_KEYS or key_text.startswith(_RESULT_TABLE_PREFIXES)


def _diff_table_counts(left: Mapping[str, Any], right: Mapping[str, Any]) -> list[dict[str, Any]]:
    changes = []
    for table in sorted(set(left) | set(right)):
        left_rows = left.get(table)
        right_rows = right.get(table)
        if left_rows != right_rows:
            changes.append({"table": table, "left_rows": left_rows, "right_rows": right_rows})
    return changes


def _compact_record(record: Mapping[str, Any]) -> dict[str, Any]:
    return {
        "version_id": record.get("version_id"),
        "model_type": record.get("model_type", DEFAULT_MODEL_TYPE),
        "feeder_id": record.get("feeder_id"),
        "created_at": record.get("created_at"),
        "pickle_sha256": record.get("pickle", {}).get("sha256"),
        "model_hash": record.get("model", {}).get("hash"),
    }


def _default_version_id(timestamp: str, digest: str) -> str:
    compact_timestamp = timestamp.replace("-", "").replace(":", "").replace("Z", "Z")
    return f"v{compact_timestamp}-{digest[:12]}"


def _datetime_from_timestamp(timestamp: float) -> str:
    return datetime.fromtimestamp(timestamp, timezone.utc).replace(microsecond=0).isoformat().replace("+00:00", "Z")


def _safe_name(value: Any) -> str:
    safe = _SAFE_NAME_RE.sub("-", str(value)).strip(".-")
    return safe or "network-model"


def _stable_repr(value: Any, max_length: int = 2000) -> str:
    text = _MEMORY_ADDRESS_RE.sub(" at 0x...", repr(value))
    if len(text) > max_length:
        return text[:max_length] + "...<truncated>"
    return text


def _type_name(value: Any) -> str:
    value_type = type(value)
    return f"{value_type.__module__}.{value_type.__qualname__}"


def _append_history(history_path: PathLike, record: Mapping[str, Any]) -> None:
    path = Path(history_path)
    path.parent.mkdir(parents=True, exist_ok=True)
    history_entry = _compact_record(record)
    history_entry["record_path"] = record.get("snapshot", {}).get("record_path")
    history_entry["pickle_path"] = record.get("snapshot", {}).get("pickle_path")
    with path.open("a", encoding="utf-8") as handle:
        json.dump(history_entry, handle, sort_keys=True)
        handle.write("\n")


def _parse_metadata(items: Optional[Sequence[str]]) -> dict[str, Any]:
    metadata: dict[str, Any] = {}
    for item in items or ():
        key, separator, raw_value = item.partition("=")
        if not separator or not key:
            raise ValueError(f"Metadata must use KEY=VALUE form, got {item!r}")
        metadata[key] = _parse_metadata_value(raw_value)
    return metadata


def _parse_metadata_value(raw_value: str) -> Any:
    try:
        return json.loads(raw_value)
    except json.JSONDecodeError:
        return raw_value


def _build_parser() -> argparse.ArgumentParser:
    parser = argparse.ArgumentParser(
        description="Create and verify version records for network model pickle files.",
    )
    subparsers = parser.add_subparsers(dest="command", required=True)

    record = subparsers.add_parser("record", help="write a JSON sidecar for a pickle")
    _add_record_options(record)
    record.add_argument("-o", "--output", help="record path, defaults to <pickle>.version.json")
    record.add_argument("--json", action="store_true", help="print machine-readable output")

    snapshot = subparsers.add_parser("snapshot", help="copy a pickle into a version store")
    _add_record_options(snapshot)
    snapshot.add_argument(
        "--store-dir",
        default=DEFAULT_VERSION_STORE,
        help=f"version store directory (default: {DEFAULT_VERSION_STORE})",
    )
    snapshot.add_argument("--json", action="store_true", help="print machine-readable output")

    check = subparsers.add_parser("check", help="verify that a pickle matches a sidecar")
    check.add_argument("pickle_path")
    check.add_argument("record")
    check.add_argument("--inspect", action="store_true", help="also compare canonical model hash")
    check.add_argument("--json", action="store_true", help="print machine-readable output")

    diff = subparsers.add_parser("diff", help="compare two version sidecars")
    diff.add_argument("left_record")
    diff.add_argument("right_record")
    diff.add_argument("--json", action="store_true", help="print machine-readable output")

    ddl = subparsers.add_parser("ddl", help="print Snowflake table DDL")
    ddl.add_argument(
        "--table-name",
        default=DEFAULT_SNOWFLAKE_TABLE,
        help=f"Snowflake table name (default: {DEFAULT_SNOWFLAKE_TABLE})",
    )

    bulk = subparsers.add_parser("bulk-inserts", help="write Snowflake INSERT statements for pickle files")
    bulk.add_argument("pkl_path", help="pickle file or directory containing pickle files")
    bulk.add_argument("-o", "--output", required=True, help="output .sql file")
    bulk.add_argument(
        "--table-name",
        default=DEFAULT_SNOWFLAKE_TABLE,
        help=f"Snowflake table name (default: {DEFAULT_SNOWFLAKE_TABLE})",
    )
    bulk.add_argument("--version-id", help="explicit version id for all rows")
    bulk.add_argument(
        "--model-type",
        choices=MODEL_TYPES,
        default=DEFAULT_MODEL_TYPE,
        help=f"network model type (default: {DEFAULT_MODEL_TYPE})",
    )
    bulk.add_argument(
        "--metadata",
        action="append",
        default=[],
        metavar="KEY=VALUE",
        help="operator metadata; value may be JSON",
    )
    bulk.add_argument("--inspect", action="store_true", help="load pickles and compute canonical model hashes")
    bulk.add_argument(
        "--include-results",
        action="store_true",
        help="include res_* and transient solver tables in canonical model hashes when --inspect is used",
    )
    bulk.add_argument("--pattern", default="*.pkl", help="glob pattern for directory scans")
    bulk.add_argument("--json", action="store_true", help="print machine-readable output")
    return parser


def _add_record_options(parser: argparse.ArgumentParser) -> None:
    parser.add_argument("pickle_path")
    parser.add_argument("--version-id", help="explicit version id, for example v1.2.0")
    parser.add_argument(
        "--model-type",
        choices=MODEL_TYPES,
        default=DEFAULT_MODEL_TYPE,
        help=f"network model type (default: {DEFAULT_MODEL_TYPE})",
    )
    parser.add_argument("--feeder-id", help="network or feeder identifier")
    parser.add_argument(
        "--metadata",
        action="append",
        default=[],
        metavar="KEY=VALUE",
        help="operator metadata; value may be JSON",
    )
    parser.add_argument(
        "--no-inspect",
        action="store_true",
        help="do not load the pickle; only hash bytes",
    )
    parser.add_argument(
        "--include-results",
        action="store_true",
        help="include res_* and transient solver tables in the canonical model hash",
    )


if __name__ == "__main__":
    raise SystemExit(main())
