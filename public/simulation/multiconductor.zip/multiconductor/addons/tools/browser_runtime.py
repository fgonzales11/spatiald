"""Shared native/WebAssembly snapshot runner; no browser or filesystem access."""
import json
import math
import pickle
import time

import numpy as np

import multiconductor as mc


def validate_parameters(parameters):
    expected = {"tol_vmag_pu", "tol_vang_rad", "MaxIter", "run_control"}
    if set(parameters) != expected:
        raise ValueError("Supply voltage tolerance, angle tolerance, maximum iterations and device controls")
    for name in ("tol_vmag_pu", "tol_vang_rad"):
        value = parameters[name]
        if isinstance(value, bool) or not isinstance(value, (int, float)) or not math.isfinite(value) or not 1e-12 <= value <= .1:
            raise ValueError(f"{name} must be between 1e-12 and 0.1")
    iterations = parameters["MaxIter"]
    if isinstance(iterations, bool) or not isinstance(iterations, int) or not 1 <= iterations <= 1000:
        raise ValueError("Maximum iterations must be an integer between 1 and 1000")
    if not isinstance(parameters["run_control"], bool):
        raise ValueError("Device controls must be true or false")
    return parameters


def _finite(value):
    return float(value) if np.isfinite(value) else None


def run_snapshot(pickle_bytes, parameters):
    """Run a fresh copy of a trusted catalog pickle and return JSON-safe results.

    The worker verifies the file against its generated catalog before calling
    this function. Pickles are executable Python data: do not build catalogs
    from untrusted files.
    """
    parameters = validate_parameters(parameters)
    net = pickle.loads(pickle_bytes)
    started = time.perf_counter()
    mc.run_pf(net, **parameters)
    if not net.model.solved:
        raise RuntimeError("Power flow did not converge")
    phases = net.res_bus.loc[net.res_bus.index.get_level_values("phase").isin([1, 2, 3])]
    energized = phases.vm_pu[np.isfinite(phases.vm_pu) & (phases.vm_pu > 0)]
    geo = net.get("bus_geo", net.get("bus_geodata"))
    if geo is None:
        raise ValueError("Network has no bus coordinates for displaying results")
    coords = geo.groupby(level=0, sort=False).first()
    names = net.bus.groupby(level=0, sort=False).first()
    features = []
    for bus, rows in phases.groupby(level=0, sort=False):
        position = coords.loc[bus]
        x = position.get("longitude", position.get("Longitude"))
        y = position.get("latitude", position.get("Latitude"))
        if x is None or y is None or not np.isfinite([x, y]).all():
            raise ValueError(f"Missing geographic coordinates at bus {bus}")
        voltages = rows.vm_pu[np.isfinite(rows.vm_pu) & (rows.vm_pu > 0)]
        low = _finite(voltages.min())
        high = _finite(voltages.max())
        state = "Unenergized" if low is None else "Low voltage" if low < .95 else "High voltage" if high > 1.05 else "Within limits"
        properties = {"bus": str(bus), "name": str(names.loc[bus, "name"]),
                      "CIRCUIT_ID": str(net.get("CIRCUIT_ID", "")), "status": state,
                      "vm_pu_min": low, "vm_pu_max": high}
        for index, row in rows.iterrows():
            properties[f"voltage_{int(index[-1])}_pu"] = _finite(row.vm_pu)
        features.append({"type": "Feature", "geometry": {"type": "Point", "coordinates": [float(x), float(y)]},
                         "properties": properties})
    tables = {name: json.loads(net[name].reset_index().to_json(orient="records", double_precision=12))
              for name in ("res_bus", "res_line", "res_trafo") if name in net}
    result = {"solved": True, "iterations": int(net.model.iterations),
              "seconds": time.perf_counter() - started, "parameters": dict(parameters),
              "voltage_min": _finite(energized.min()), "voltage_max": _finite(energized.max()),
              "unenergized_phase_terminals": int(len(phases) - len(energized)),
              "voltage_violations": int(((energized < .95) | (energized > 1.05)).sum()),
              "voltages": {"type": "FeatureCollection", "features": features}, "tables": tables}
    json.dumps(result, allow_nan=False)
    return result
