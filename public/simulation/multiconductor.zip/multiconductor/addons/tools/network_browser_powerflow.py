"""Attach a browser-local Pyodide power-flow panel to an exported Kepler map."""
import hashlib
import html
import json
import os
from pathlib import Path
import pickle
import shutil
from urllib.parse import quote
import zipfile


_BOOTSTRAP = '(0,s.addDataConfigToKeplerGl)({data:d,config:h,options:y,store:f.store})'
_BRIDGE = """,window.__mcPowerflowBridge={
add:(data,config)=>s.addDataConfigToKeplerGl({data,config,
options:{centerMap:false,keepExistingConfig:true,autoCreateLayers:false},store:f.store}),
focus:viewport=>f.store.dispatch({type:'@@kepler.gl/UPDATE_MAP',payload:{viewport}}),
remove:dataId=>f.store.dispatch({type:'@@kepler.gl/REMOVE_DATASET',dataId})}
"""


def enable_browser_powerflow(map_file, pickle_files, *, asset_directory=None):
    """Enhance a Kepler 0.3.7 export using trusted network pickles in map order.

    Network paths are relative URLs, fetched only when selected for a solve.
    Serve the map, assets and pickle directory from the same HTTPS origin or
    localhost HTTP server (the browser requires a secure context for hashing).
    No Python application server is needed. The map retains its existing data.
    Re-run this exporter whenever the library or pickles change.
    """
    page = Path(map_file).resolve()
    assets = Path(asset_directory).resolve() if asset_directory else page.with_name(page.stem + "_assets")
    source = page.read_text()
    if _BOOTSTRAP not in source:
        raise ValueError("Expected the Kepler 0.3.7 HTML template; cannot attach its map bridge")
    # Confirm catalog identities against the actual map, not only file ordering.
    start = source.index("window.__keplerglDataConfig = ") + len("window.__keplerglDataConfig = ")
    config = json.loads(source[start:source.index(";</script>", start)])
    identities = {f["properties"]["network_key"]: f["properties"]
                  for f in config["data"]["bus"]["features"]}
    files = [Path(p).resolve() for p in pickle_files]
    if len(files) != len(identities):
        raise ValueError("Pickle catalog must contain every mapped network exactly once")
    networks = []
    for i, path in enumerate(files):
        data = path.read_bytes()
        net = pickle.loads(data)
        key = f"network_{i}"
        props = identities[key]
        if (str(net.SUB_ID), str(net.CIRCUIT_ID)) != (props["SUB_ID"], props["CIRCUIT_ID"]):
            raise ValueError(f"Pickle order does not match map identity: {path}")
        geo = net.bus_geo
        networks.append({"key": key, "name": path.stem, "substation": str(net.SUB_ID),
                         "circuit": str(net.CIRCUIT_ID), "url": quote(os.path.relpath(path, assets).replace(os.sep, "/")),
                         "sha256": hashlib.sha256(data).hexdigest(),
                         "buses": int(net.bus.index.get_level_values(0).nunique()),
                         "longitude": float(geo.longitude.mean()), "latitude": float(geo.latitude.mean()),
                         "bounds": [float(geo.longitude.min()), float(geo.latitude.min()),
                                    float(geo.longitude.max()), float(geo.latitude.max())]})
    assets.mkdir(parents=True, exist_ok=True)
    package = Path(__file__).resolve().parents[2]
    with zipfile.ZipFile(assets / "multiconductor.zip", "w", zipfile.ZIP_DEFLATED) as archive:
        for path in sorted(package.rglob("*.py")):
            archive.write(path, path.relative_to(package.parent))
    for path in (Path(__file__).parent / "browser").iterdir():
        if path.suffix in (".mjs", ".css"):
            shutil.copyfile(path, assets / path.name)
    manifest = {"format": 1, "pyodide": "0.28.3", "pandapower": "3.4.0", "networks": networks,
                "solver_sha256": hashlib.sha256((assets / "multiconductor.zip").read_bytes()).hexdigest()}
    (assets / "manifest.json").write_text(json.dumps(manifest, indent=2) + "\n")
    if "window.__mcPowerflowBridge=" not in source:
        source = source.replace(_BOOTSTRAP, _BOOTSTRAP + _BRIDGE, 1)
    if 'id="mc-powerflow-module"' not in source:
        relative = quote(os.path.relpath(assets, page.parent).replace(os.sep, "/"))
        tags = (f'<link rel="stylesheet" href="{html.escape(relative)}/powerflow.css">'
                f'<script id="mc-powerflow-module" type="module" src="{html.escape(relative)}/powerflow.mjs"></script>')
        before, after = source.rsplit("</body>", 1)
        source = before + tags + "</body>" + after
    page.write_text(source)
    return manifest
