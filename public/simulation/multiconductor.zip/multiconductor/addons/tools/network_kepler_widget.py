"""Optional Kepler widget with responsive standalone HTML exports."""
from keplergl import KeplerGl


_RESPONSIVE_PAGE = """
<style id="multiconductor-full-page-map">
html, body { width: 100%; height: 100%; margin: 0; overflow: hidden; }
.keplergl-widget-container {
    position: fixed !important;
    inset: 0;
    width: 100vw !important;
    height: 100vh !important;
    height: 100dvh !important;
}
</style>
<script>
(() => {
    const initialize = () => {
        const container = document.querySelector('.keplergl-widget-container');
        if (!container) return;
        let frame;
        const resize = () => {
            cancelAnimationFrame(frame);
            frame = requestAnimationFrame(() => {
                // Kepler's own resize handler updates both WebGL and controls.
                window.dispatchEvent(new Event('resize'));
            });
        };
        const observer = new ResizeObserver(resize);
        observer.observe(container);
        // Also initialize after assets load, when React's effects are attached.
        window.addEventListener('load', resize, {once: true});
        resize();
    };
    if (document.readyState === 'loading') {
        document.addEventListener('DOMContentLoaded', initialize, {once: true});
    } else {
        initialize();
    }
})();
</script>
"""


def make_responsive_html(html):
    """Enrich a Kepler HTML export, preserving its bytes/string return type."""
    encoded = isinstance(html, bytes)
    text = html.decode("utf-8") if encoded else html
    if 'id="multiconductor-full-page-map"' not in text:
        if "</body>" not in text:
            raise ValueError("Expected a complete Kepler HTML page")
        # The bundled JavaScript also contains literal closing-body strings.
        before, after = text.rsplit("</body>", 1)
        text = before + _RESPONSIVE_PAGE + "</body>" + after
    return text.encode("utf-8") if encoded else text


class FullPageKeplerGl(KeplerGl):
    """Keep notebook sizing while fitting exported HTML to the browser page."""

    def _repr_html_(self, *args, **kwargs):
        return make_responsive_html(super()._repr_html_(*args, **kwargs))
