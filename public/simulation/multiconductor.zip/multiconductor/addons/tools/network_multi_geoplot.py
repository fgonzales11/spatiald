"""Multi-network Kepler maps with physical-device identities and electrical glyphs.

Geometry preparation needs only pandas/numpy; the optional keplergl dependency
is loaded when a widget is requested. Input networks are never modified.
"""
from __future__ import annotations

import ast
from collections import Counter, defaultdict
import colorsys
import json
import math
import re
import warnings

import numpy as np
import pandas as pd

PALETTE = [
    [66, 165, 245], [255, 167, 38], [102, 187, 106], [239, 83, 80],
    [171, 112, 230], [38, 198, 218], [236, 112, 177], [220, 212, 83],
    [145, 196, 232], [255, 123, 64], [178, 220, 134], [194, 155, 231],
    [52, 211, 153], [255, 207, 151], [244, 143, 177], [158, 180, 194],
    [209, 160, 104], [91, 137, 229], [210, 216, 238], [231, 204, 72],
]
SYMBOL_STYLES = {
    "bus": ("Bus · busbar", [210, 223, 236]),
    "switch_closed": ("Switch · closed contacts", [113, 222, 164]),
    "switch_open": ("Switch · open blade", [255, 99, 105]),
    "switch_mixed": ("Switch · mixed phase states", [255, 188, 65]),
    "transformer": ("Transformer · coupled windings", [255, 198, 85]),
    "generator": ("Generator · AC source", [228, 145, 247]),
    "external_grid": ("External grid · supply", [255, 246, 196]),
}


def _table(net, name):
    value = net.get(name) if hasattr(net, "get") else getattr(net, name, None)
    return value if isinstance(value, pd.DataFrame) else pd.DataFrame()


def _value(net, name, fallback):
    value = net.get(name) if hasattr(net, "get") else getattr(net, name, None)
    return fallback if value is None or pd.isna(value) or str(value).strip()=="" else str(value)


def _id(index):
    return index[0] if isinstance(index, tuple) else index


def _groups(table):
    return table.groupby(level=0, sort=False) if not table.empty else []


def _number(value):
    try:
        value = float(value)
        return value if math.isfinite(value) else None
    except (ValueError, TypeError):
        return None


def _decode(value):
    if isinstance(value, str):
        if value.lstrip().upper().startswith(("LINESTRING", "POINT")):
            pairs = [[float(a),float(b)] for a,b in re.findall(
                r"(-?\d+(?:\.\d+)?(?:[eE][+-]?\d+)?)\s+(-?\d+(?:\.\d+)?(?:[eE][+-]?\d+)?)",value)]
            return pairs[0] if value.lstrip().upper().startswith("POINT") and pairs else pairs
        for decode in (json.loads,ast.literal_eval):
            try:
                return _decode(decode(value))
            except (ValueError,SyntaxError,TypeError):
                pass
        return None
    if isinstance(value, np.ndarray):
        return value.tolist()
    if isinstance(value, dict):
        return _decode(value.get("coordinates",value.get("geometry")))
    return value


def _point(value, crs="EPSG:4326"):
    value = _decode(value)
    if not isinstance(value,(tuple,list)) or len(value)<2:
        return None
    x,y = _number(value[0]),_number(value[1])
    if x is None or y is None:
        return None
    if crs=="EPSG:3857":
        if abs(x)>20037508.35 or abs(y)>20037508.35:
            return None
        x,y=math.degrees(x/6378137),math.degrees(2*math.atan(math.exp(y/6378137))-math.pi/2)
    return [x,y] if abs(x)<=180 and abs(y)<=85.05112878 else None


def _path(value, xy_crs):
    value=_decode(value)
    if not isinstance(value,(tuple,list)) or len(value)<2:
        return None
    path=[_point(p) for p in value]
    if all(p is not None for p in path):
        return path
    if xy_crs=="EPSG:3857":
        path=[_point(p,xy_crs) for p in value]
        if all(p is not None for p in path):
            return path
    return None  # Never join across an invalid/missing interior vertex.


def _geometry(net, xy_crs):
    buses,lines={},{}
    for name in ("bus_geo","bus_geodata","bus"):
        table=_table(net,name)
        columns={str(c).lower():c for c in table.columns}
        for index,row in table.iterrows():
            key=_id(index)
            if key in buses:
                continue
            point=None
            # Explicit geographic columns take precedence over projected x/y.
            for x,y,crs in (("longitude","latitude","EPSG:4326"),("lon","lat","EPSG:4326"),
                            ("lng","lat","EPSG:4326"),("x","y",xy_crs)):
                if x in columns and y in columns:
                    point=_point([row[columns[x]],row[columns[y]]],crs)
                    if point is not None:
                        break
            if point is None:
                for col in ("geo","geometry","coords"):
                    if col in columns:
                        point=_point(row[columns[col]])
                        if point is not None:
                            break
            if point is not None:
                buses[key]=point
    for name in ("line_geo","line_geodata","line"):
        table=_table(net,name)
        cols={str(c).lower():c for c in table.columns}
        for index,row in table.iterrows():
            key=_id(index)
            if key in lines:
                continue
            for col in ("coords","geometry","geo"):
                if col in cols:
                    path=_path(row[cols[col]],xy_crs)
                    if path:
                        lines[key]=path
                        break
    # Valid explicit routes can supply missing bus endpoint coordinates.
    for key,rows in _groups(_table(net,"line")):
        row=rows.iloc[0]
        if key in lines:
            buses.setdefault(row.from_bus,lines[key][0])
            buses.setdefault(row.to_bus,lines[key][-1])
    return buses,lines


def _circle(x,y,r,n=16):
    return [[x+r*math.cos(t*2*math.pi/n),y+r*math.sin(t*2*math.pi/n)] for t in range(n+1)]


def _symbol(kind, anchor, size, angle=0):
    """Engineering diagram symbols in local meter offsets, not physical sizes."""
    if kind=="bus":
        strokes=[[[-.3,-.12],[-.3,.12],[.3,.12],[.3,-.12],[-.3,-.12]]]
    elif kind=="transformer":
        strokes=[[[0,0],[.4,0]],_circle(.9,0,.5),_circle(1.55,0,.5),[[2.05,0],[2.4,0]]]
    elif kind=="generator":
        strokes=[[[0,0],[0,.65]],_circle(0,1.25,.6),
                 [[-.42+t*.84/16,1.25+.22*math.sin(t*2*math.pi/16)] for t in range(17)]]
    elif kind=="external_grid":
        strokes=[[[0,0],[0,.5]],[[-.6,.5],[-.6,1.7],[.6,1.7],[.6,.5],[-.6,.5]],
                 [[.15,1.6],[-.2,1.1],[.2,1.1],[-.15,.6]]]
    else:
        blade=[[.35,0],[1.12,.48]] if kind!="switch_closed" else [[.35,0],[1.15,0]]
        strokes=[[[0,0],[.25,0]],_circle(.3,0,.065,8),blade,_circle(1.2,0,.065,8),[[1.25,0],[1.5,0]]]
        if kind=="switch_mixed":
            strokes.append([[.35,-.2],[1.15,-.2]])
    coslat=max(math.cos(math.radians(anchor[1])),1e-6)
    c,s=math.cos(angle),math.sin(angle)
    coords=[]
    for stroke in strokes:
        coords.append([[anchor[0]+math.degrees(size*(x*c-y*s)/(6378137*coslat)),
                        anchor[1]+math.degrees(size*(x*s+y*c)/6378137)] for x,y in stroke])
    return {"type":"MultiLineString","coordinates":coords}


def _phases(rows):
    if "from_phase" in rows:
        values=rows.from_phase.dropna().unique()
    elif "phase" in rows:
        values=rows.phase.dropna().unique()
    elif isinstance(rows.index,pd.MultiIndex) and "phase" in rows.index.names:
        values=rows.index.get_level_values("phase").unique()
    else:
        return ""
    return ", ".join({0:"N",1:"A",2:"B",3:"C"}.get(int(p),str(p)) for p in sorted(values))


def _status(rows, field="in_service"):
    states=rows[field].fillna(True).astype(bool) if field in rows else pd.Series([True])
    return "in service" if states.all() else "out of service" if not states.any() else "mixed phases"


def _properties(identity,kind,key,rows):
    props=dict(identity,element_type=kind,element_id=str(key),
               name=str(rows.iloc[0].get("name",key)),phases=_phases(rows),status=_status(rows))
    for col in ("vn_kv","length_km"):
        if col in rows:
            props[col]=_number(rows.iloc[0][col])
    for col in ("p_mw","q_mvar"):
        if col in rows:
            scaling=rows.scaling.fillna(1) if "scaling" in rows else 1
            props[col]=_number((pd.to_numeric(rows[col],errors="coerce")*scaling).sum(min_count=1))
    return props


def _results(net,table,key,props):
    frame=_table(net,table)
    if frame.empty or key not in frame.index.get_level_values(0):
        return
    rows=frame.xs(key,level=0,drop_level=False) if isinstance(frame.index,pd.MultiIndex) else frame.loc[[key]]
    if table=="res_bus" and isinstance(rows.index,pd.MultiIndex):
        rows=rows[rows.index.get_level_values(-1).isin([1,2,3])]
    for col in ("vm_pu","va_degree","loading_percent","i_ka"):
        if col in rows:
            numbers=pd.to_numeric(rows[col],errors="coerce").replace([np.inf,-np.inf],np.nan).dropna()
            if len(numbers):
                props[col+"_min"]=float(numbers.min())
                props[col+"_max"]=float(numbers.max())


def _colors(substations, overrides):
    overrides={str(k):v for k,v in (overrides or {}).items()}
    colors={}
    for i,sub in enumerate(sorted(substations)):
        rgb=overrides.get(sub)
        if rgb is None:
            rgb=PALETTE[i] if i<len(PALETTE) else [round(255*c) for c in colorsys.hsv_to_rgb((i*.61803398875)%1,.55,.95)]
        if not isinstance(rgb,(tuple,list)) or len(rgb)!=3 or any(not isinstance(c,(int,np.integer)) or not 0<=c<=255 for c in rgb):
            raise ValueError(f"Color for SUB_ID={sub!r} must be three integers from 0 to 255")
        colors[sub]=[int(c) for c in rgb]
    if len({tuple(c) for c in colors.values()})!=len(colors):
        raise ValueError("Each SUB_ID must have a distinct line color")
    return colors


def _layer(data_id,label,color,width):
    return {"id":data_id+"_layer","type":"geojson","config":{
        "dataId":data_id,"label":label,"color":color,"columns":{"geojson":"_geojson"},"isVisible":True,
        # Kepler 0.3.x multiplies GeoJSON thickness by 8 meters and a zoom
        # factor. Keep glyph strokes thin enough to reveal coils and blades.
        "visConfig":{"opacity":1,"strokeOpacity":1,"thickness":width/16,"strokeColor":color,
                     "stroked":True,"filled":False,"enable3d":False,"wireframe":False}},
        "visualChannels":{"colorField":None,"strokeColorField":None,"sizeField":None}}


def prepare_multi_network_map(
    nets, title="Distribution networks", *, symbol_size_m=12, line_width=2,
    substation_colors=None, line_layer_by="substation", xy_crs="EPSG:4326", strict=True,
):
    """Return Kepler ``data``, ``config`` and a coverage/legend ``metadata`` dict.

    One physical device becomes one feature, even when it has many phase rows.
    IDs are namespaced per input network. Lines share a color for the same
    ``SUB_ID``; ``line_layer_by='circuit'`` gives each feeder its own toggle.
    Palette assignment is repeatable for the same set of substation IDs, even
    if network order changes. Supply ``substation_colors`` to fix colors across
    different subsets. Missing SUB_IDs form an explicit '(unassigned)' group.

    Geometry accepts GeoJSON, WKT, coords/Geometry and geographic columns in
    bus_geo/bus_geodata or the element tables. For projected x/y inputs opt in
    with xy_crs='EPSG:3857'. A missing route uses its bus endpoints. Missing
    equipment positions raise by default; strict=False warns and records every
    omission in metadata. Symbol dimensions are cartographic, in meters; zoom
    in to resolve the electrical glyphs. This function never loads pickle files.
    """
    if isinstance(nets,(dict,str,bytes)) or not hasattr(nets,"__iter__"):
        raise TypeError("nets must be a list or iterable of network objects")
    nets=list(nets)
    if not nets:
        raise ValueError("At least one network is required")
    if not math.isfinite(symbol_size_m) or symbol_size_m<=0 or not math.isfinite(line_width) or line_width<=0:
        raise ValueError("symbol_size_m and line_width must be positive and finite")
    if line_layer_by not in ("substation","circuit"):
        raise ValueError("line_layer_by must be 'substation' or 'circuit'")
    if xy_crs not in ("EPSG:4326","EPSG:3857"):
        raise ValueError("xy_crs must be EPSG:4326 or EPSG:3857")
    identities=[{"network_key":f"network_{i}","SUB_ID":_value(n,"SUB_ID","(unassigned)"),
                 "CIRCUIT_ID":_value(n,"CIRCUIT_ID",_value(n,"name",f"Network {i+1}"))} for i,n in enumerate(nets)]
    colors=_colors({v["SUB_ID"] for v in identities},substation_colors)
    station_ids={s:f"substation_{i}" for i,s in enumerate(sorted(colors))}
    features=defaultdict(list)
    line_labels={}
    extent=[]
    omitted=[]
    counts=[]
    inferred_routes=0

    def add(dataset,identity,table,key,geometry,props):
        feature_id=f'{identity["network_key"]}/{table}/{key}'
        features[dataset].append({"type":"Feature","id":feature_id,"geometry":geometry,
                                  "properties":dict(props,feature_id=feature_id)})

    for net,identity in zip(nets,identities):
        buses,paths=_geometry(net,xy_crs)
        tally=Counter()
        def missing(table,key):
            omitted.append(dict(identity,element_type=table,element_id=str(key)))
        bus_voltage={key:_number(rows.iloc[0].get("vn_kv")) for key,rows in _groups(_table(net,"bus"))}
        for key,rows in _groups(_table(net,"bus")):
            if key not in buses:
                missing("bus",key); continue
            props=_properties(identity,"Bus",key,rows)
            _results(net,"res_bus",key,props)
            add("bus",identity,"bus",key,_symbol("bus",buses[key],symbol_size_m),props)
            extent.append(buses[key]); tally["bus"]+=1
        for key,rows in _groups(_table(net,"line")):
            row=rows.iloc[0]
            path=paths.get(key)
            if path is None and row.from_bus in buses and row.to_bus in buses:
                path=[buses[row.from_bus],buses[row.to_bus]]
                inferred_routes+=1
            if path is None:
                missing("line",key); continue
            props=_properties(identity,"Line",key,rows)
            props.update(from_bus=str(row.from_bus),to_bus=str(row.to_bus),
                         vn_kv=bus_voltage.get(row.from_bus),circuits=len(rows))
            _results(net,"res_line",key,props)
            dataset="lines_"+(station_ids[identity["SUB_ID"]] if line_layer_by=="substation" else identity["network_key"])
            line_labels[dataset]=(identity["SUB_ID"]+(" / "+identity["CIRCUIT_ID"] if line_layer_by=="circuit" else "")+" · lines",colors[identity["SUB_ID"]])
            add(dataset,identity,"line",key,{"type":"LineString","coordinates":path},props)
            extent.extend(path); tally["line"]+=1
        for key,rows in _groups(_table(net,"switch")):
            row=rows.iloc[0]
            if row.bus not in buses:
                missing("switch",key); continue
            closed=rows.closed.fillna(False).astype(bool)
            state="closed" if closed.all() else "open" if not closed.any() else "mixed"
            props=_properties(identity,"Switch",key,rows)
            props.update(status=state,bus=str(row.bus),target_type=str(row.et),target_id=str(row.element),
                         phase_states=", ".join(f"{r.get('phase',idx[-1] if isinstance(idx,tuple) else idx)}: {'closed' if state else 'open'}" for (idx,r),state in zip(rows.iterrows(),closed)))
            angle=0
            if row.et=="b" and row.element in buses:
                target=buses[row.element]
            elif row.et=="l" and row.element in paths:
                route=paths[row.element]
                target=max((route[0],route[-1]),key=lambda p:(p[0]-buses[row.bus][0])**2+(p[1]-buses[row.bus][1])**2)
            else:
                target=None
            if target:
                angle=math.atan2(target[1]-buses[row.bus][1],(target[0]-buses[row.bus][0])*math.cos(math.radians(target[1])))
            add("switch_"+state,identity,"switch",key,_symbol("switch_"+state,buses[row.bus],symbol_size_m,angle),props)
            tally["switch"]+=1
        for table in ("trafo1ph","trafo","trafo3w"):
            for key,rows in _groups(_table(net,table)):
                if table=="trafo1ph" and "bus" in rows.index.names:
                    winding_buses=list(rows.index.get_level_values("bus").unique())
                else:
                    winding_buses=[rows.iloc[0][c] for c in ("hv_bus","mv_bus","lv_bus") if c in rows]
                positioned=[b for b in winding_buses if b in buses]
                if not positioned:
                    missing(table,key); continue
                bus=min(positioned,key=lambda b:bus_voltage.get(b) or float("inf"))
                props=_properties(identity,"Transformer",key,rows)
                props.update(bus=str(bus),winding_buses=", ".join(map(str,winding_buses)),winding_rows=len(rows))
                _results(net,"res_trafo",key,props)
                add("transformer",identity,table,key,_symbol("transformer",buses[bus],symbol_size_m),props)
                tally["transformer"]+=1
        for table in ("asymmetric_sgen","asymmetric_gen","sgen","gen","ext_grid_sequence","ext_grid"):
            kind="external_grid" if table.startswith("ext_grid") else "generator"
            for key,rows in _groups(_table(net,table)):
                bus=rows.iloc[0].bus
                if bus not in buses:
                    missing(table,key); continue
                props=_properties(identity,"External grid" if kind=="external_grid" else "Generator",key,rows)
                props.update(bus=str(bus),source_table=table)
                add(kind,identity,table,key,_symbol(kind,buses[bus],symbol_size_m),props)
                tally[kind]+=1
        counts.append(dict(identity,counts=dict(tally)))
    if omitted:
        message=f"Missing geographic coordinates for {len(omitted)} elements; first: {omitted[0]}"
        if strict:
            raise ValueError(message)
        warnings.warn(message,UserWarning,stacklevel=2)
    if not extent:
        raise ValueError("No geographic network geometry is available")
    data={key:{"type":"FeatureCollection","features":value} for key,value in features.items() if value}
    layers=[]
    for kind,(label,color) in SYMBOL_STYLES.items():
        if kind in data:
            layer=_layer(kind,label,color,.3 if kind=="bus" else 1)
            if kind=="bus":
                layer["config"]["visConfig"].update(opacity=.4,strokeOpacity=.4)
            layers.append(layer)
    for key,(label,color) in sorted(line_labels.items()):
        layers.append(_layer(key,label,color,line_width))
    tooltip={key:[{"name":col,"format":None} for col in sorted({c for f in value["features"] for c in f["properties"]}) if col not in ("feature_id","network_key")]
             for key,value in data.items()}
    xs=[p[0] for p in extent]
    ys=[math.log(math.tan(math.pi/4+math.radians(p[1])/2)) for p in extent]
    xspan=max((max(xs)-min(xs))/360,1e-9)
    yspan=max((max(ys)-min(ys))/(2*math.pi),1e-9)
    # Kepler's standalone HTML initially uses an 800 x 400 canvas.
    zoom=max(1,min(18,math.log2(min(700/(512*xspan),330/(512*yspan)))-.4))
    center_lat=math.degrees(2*math.atan(math.exp((min(ys)+max(ys))/2))-math.pi/2)
    config={"version":"v1","config":{
        "visState":{"layers":layers,"filters":[],"interactionConfig":{"tooltip":{"enabled":True,"fieldsToShow":tooltip}},"layerBlending":"normal"},
        "mapState":{"latitude":center_lat,"longitude":(min(xs)+max(xs))/2,"zoom":zoom,"pitch":0,"bearing":0,"dragRotate":False},
        "mapStyle":{"styleType":"dark-matter"}}}
    metadata={"title":str(title),"network_count":len(nets),"networks":counts,"substation_colors":colors,
              "symbol_legend":{k:v[0] for k,v in SYMBOL_STYLES.items() if k in data},
              "symbol_size_m":symbol_size_m,"inferred_line_routes":inferred_routes,"omitted_elements":omitted,
              "line_layer_by":line_layer_by,"feature_count":sum(len(v["features"]) for v in data.values())}
    return {"data":data,"config":config,"metadata":metadata}


def build_multi_network_kepler_map(nets, title="Distribution networks", *, height=800, **kwargs):
    """Build one KeplerGl widget from a list of networks.

    See :func:`prepare_multi_network_map` for coloring, geometry and symbol
    options. The returned widget supports ``save_to_html`` and exposes
    ``network_map_metadata`` with the palette, physical counts and omissions.
    HTML exports fill the browser page and resize with it; ``height`` controls
    the notebook widget only.
    Install the optional ``itron-pf-platform[maps]`` dependencies to render it.
    """
    if not isinstance(height,int) or height<=0:
        raise ValueError("height must be a positive integer")
    try:
        from .network_kepler_widget import FullPageKeplerGl
    except ImportError as exc:
        raise ImportError("Install the optional map dependencies: pip install 'keplergl==0.3.7' 'setuptools>=68,<82'") from exc
    prepared=prepare_multi_network_map(nets,title,**kwargs)
    widget=FullPageKeplerGl(height=height,data=prepared["data"],config=prepared["config"],show_docs=False)
    widget.network_map_metadata=prepared["metadata"]
    return widget
