"""Interactive MC/OpenDSS result plots shared by the notebook and Streamlit."""

from __future__ import annotations

import heapq
import math
from collections import defaultdict
from collections.abc import Mapping
from pathlib import Path
from typing import Any, Iterable, Sequence

import numpy as np
import pandas as pd
import plotly.graph_objects as go

try:  # Package import (platform) and direct import (notebooks/add-on folder).
    from .network_geoplot import (
        _canonical_key,
        _extract_bus_points,
        _extract_explicit_line_points,
        _get_table,
        _infer_line_points,
        _iter_edge_rows,
        _looks_geographic,
    )
except ImportError:  # pragma: no cover - exercised by notebook-style imports
    from network_geoplot import (  # type: ignore
        _canonical_key,
        _extract_bus_points,
        _extract_explicit_line_points,
        _get_table,
        _infer_line_points,
        _iter_edge_rows,
        _looks_geographic,
    )


SOURCE_COLORS = {"MC": "#1f77b4", "DSS": "#ff7f0e"}
SOURCE_SYMBOLS = {"MC": "circle", "DSS": "diamond"}
PHASE_DASHES = {"A": "solid", "B": "dash", "C": "dot"}
PHASE_SYMBOLS = {"A": "circle", "B": "square", "C": "triangle-up"}

CALCULATIONS = {
    "voltage": {
        "title": "Voltage magnitude",
        "frame": "bus",
        "fields": ("VA", "VB", "VC"),
        "unit": "pu",
    },
    "power": {
        "title": "Active power",
        "frame": "line",
        "fields": ("P_FROM",),
        "unit": "MW",
    },
    "current": {
        "title": "Current magnitude",
        "frame": "line",
        "fields": ("I_FROM",),
        "unit": "kA",
    },
    "losses": {
        "title": "Active line losses",
        "frame": "line",
        "fields": ("P_LOSS",),
        "unit": "MW",
    },
    "reactive_power": {
        "title": "Reactive power",
        "frame": "line",
        "fields": ("Q_FROM",),
        "unit": "MVAr",
    },
    "reactive_losses": {
        "title": "Reactive line losses",
        "frame": "line",
        "fields": ("Q_LOSS",),
        "unit": "MVAr",
    },
}


def _circuit_key(value: object) -> str:
    """Use the filename stem so notebook and app circuit labels agree."""
    return Path(str(value)).stem


def build_plot_dataframes(
    comparison_df: pd.DataFrame,
    line_comparison_df: pd.DataFrame,
) -> tuple[pd.DataFrame, pd.DataFrame]:
    """Convert Streamlit benchmark frames to the notebook plotting schema.

    The returned frames have the same ``circuit_key``/identifier columns and
    ``<FIELD>_MC``/``<FIELD>_DSS`` pairs created by ``mesh_benchmark.ipynb``.
    """
    bus = pd.DataFrame(index=comparison_df.index)
    if not comparison_df.empty:
        bus["circuit_key"] = comparison_df["network"].map(_circuit_key)
        if "bus_idx" in comparison_df:
            bus["BUS_ID"] = comparison_df["bus_idx"].map(_canonical_key)
        if "dss_bus" in comparison_df:
            bus["NODE_ID"] = comparison_df["dss_bus"]
        elif "bus_idx" in comparison_df:
            bus["NODE_ID"] = comparison_df["bus_idx"].astype(str)

        if "vn_kv" in comparison_df:
            bus["BASE_VOLTAGE_MC"] = pd.to_numeric(
                comparison_df["vn_kv"], errors="coerce"
            )
        if "dss_kv_base_ln" in comparison_df:
            # The notebook reports the OpenDSS L-N kVBase as L-L kV.
            bus["BASE_VOLTAGE_DSS"] = (
                pd.to_numeric(comparison_df["dss_kv_base_ln"], errors="coerce")
                * np.sqrt(3.0)
            )

        for phase_upper, phase_lower in (("A", "a"), ("B", "b"), ("C", "c")):
            mappings = {
                f"V{phase_upper}_MC": f"vm_{phase_lower}_pu",
                f"V{phase_upper}_DSS": f"dss_vm_{phase_lower}_pu",
                f"V{phase_upper}_ANGLE_MC": f"va_{phase_lower}_degree",
                f"V{phase_upper}_ANGLE_DSS": f"dss_va_{phase_lower}_degree",
            }
            for output_column, source_column in mappings.items():
                if source_column in comparison_df:
                    bus[output_column] = pd.to_numeric(
                        comparison_df[source_column], errors="coerce"
                    )

    line = pd.DataFrame(index=line_comparison_df.index)
    if not line_comparison_df.empty:
        line["circuit_key"] = line_comparison_df["network"].map(_circuit_key)
        if "line_idx" in line_comparison_df:
            line["LINE_IDX"] = line_comparison_df["line_idx"].map(_canonical_key)
        line["LINE_ID"] = line_comparison_df.get(
            "line_name", line_comparison_df.get("line_idx")
        )
        line["PHASE"] = line_comparison_df["phase"].astype(str).str.upper()
        line_fields = {
            "P_FROM": "p_from_mw",
            "Q_FROM": "q_from_mvar",
            "P_TO": "p_to_mw",
            "Q_TO": "q_to_mvar",
            "I_FROM": "i_from_ka",
            "I_FROM_ANGLE": "i_from_angle_degree",
            "I_TO": "i_to_ka",
            "I_TO_ANGLE": "i_to_angle_degree",
        }
        for plot_field, result_field in line_fields.items():
            for source, prefix in (("MC", "mc"), ("DSS", "dss")):
                source_column = f"{prefix}_{result_field}"
                if source_column in line_comparison_df:
                    line[f"{plot_field}_{source}"] = pd.to_numeric(
                        line_comparison_df[source_column], errors="coerce"
                    )

        # Both engines use the passive sign convention: terminal powers are
        # positive into the line, so their sum is the branch loss.
        for source in ("MC", "DSS"):
            for prefix in ("P", "Q"):
                from_column = f"{prefix}_FROM_{source}"
                to_column = f"{prefix}_TO_{source}"
                if from_column in line and to_column in line:
                    line[f"{prefix}_LOSS_{source}"] = line[from_column] + line[to_column]

    return bus.reset_index(drop=True), line.reset_index(drop=True)


def _fields(frame: pd.DataFrame) -> list[str]:
    return [
        column[:-3]
        for column in frame.columns
        if column.endswith("_MC") and f"{column[:-3]}_DSS" in frame.columns
    ]


def plot_options(
    df_combined: pd.DataFrame,
    df_power_combined: pd.DataFrame,
) -> dict[str, dict[str, list[str]]]:
    """Return available circuits and result fields for each plot category."""
    candidates = {
        "Bus": (df_combined, ["NODE_ID"]),
        "Line": (df_power_combined, ["LINE_ID", "PHASE"]),
    }
    options: dict[str, dict[str, list[str]]] = {}
    for category, (frame, id_columns) in candidates.items():
        required = {"circuit_key", *id_columns}
        fields = _fields(frame)
        if frame.empty or not required.issubset(frame.columns) or not fields:
            continue
        circuits = [str(value) for value in frame["circuit_key"].dropna().unique()]
        if circuits:
            options[category] = {"circuits": circuits, "fields": fields}
    return options


def plot_results(
    df_combined: pd.DataFrame,
    df_power_combined: pd.DataFrame,
    *,
    category: str | None = None,
    circuit_key: str | None = None,
    field: str | None = None,
    sources: Iterable[str] = ("MC", "DSS"),
) -> go.Figure:
    """Build a Plotly comparison figure and return it without displaying it."""
    datasets = {
        "Bus": {"frame": df_combined, "id_columns": ["NODE_ID"]},
        "Line": {"frame": df_power_combined, "id_columns": ["LINE_ID", "PHASE"]},
    }
    options = plot_options(df_combined, df_power_combined)
    if not options:
        raise ValueError("No paired MC/OpenDSS bus or line result fields are available.")

    category = category if category in options else next(iter(options))
    category_options = options[category]
    if circuit_key not in category_options["circuits"]:
        circuit_key = category_options["circuits"][0]
    if field not in category_options["fields"]:
        preferred = "VA" if category == "Bus" and "VA" in category_options["fields"] else None
        field = preferred or category_options["fields"][0]

    selected_sources = [source.upper() for source in sources]
    selected_sources = [source for source in ("MC", "DSS") if source in selected_sources]
    if not selected_sources:
        selected_sources = ["MC", "DSS"]

    dataset = datasets[category]
    frame = dataset["frame"]
    subset = frame.loc[frame["circuit_key"].astype(str) == circuit_key].reset_index(drop=True)

    if len(dataset["id_columns"]) == 1:
        labels = subset[dataset["id_columns"][0]].astype(str)
    else:
        labels = subset[dataset["id_columns"]].astype(str).agg(" · ".join, axis=1)

    figure = go.Figure()
    for source in selected_sources:
        column = f"{field}_{source}"
        values = pd.to_numeric(subset[column], errors="coerce")
        valid = values.notna()
        figure.add_trace(
            go.Scatter(
                x=np.flatnonzero(valid.to_numpy()),
                y=values.loc[valid].to_numpy(),
                text=labels.loc[valid].to_numpy(),
                mode="markers",
                name=source,
                marker={
                    "color": SOURCE_COLORS[source],
                    "symbol": SOURCE_SYMBOLS[source],
                    "size": 7,
                    "opacity": 0.75,
                },
                hovertemplate=f"%{{text}}<br>{field}: %{{y}}<extra></extra>",
            )
        )

    figure.update_layout(
        template="plotly_dark",
        title=f"{category} · {circuit_key} — {field}",
        xaxis_title="Element index",
        yaxis_title=field,
        height=560,
        legend_title="Source",
        margin={"t": 70, "r": 30, "b": 60, "l": 70},
    )
    return figure


def _first_physical_rows(table: Any) -> Iterable[tuple[Any, Any]]:
    """Yield one row per physical element from phase/circuit expanded tables."""
    if table is None or not hasattr(table, "iterrows"):
        return
    seen: set[Any] = set()
    for raw_index, row in table.iterrows():
        key = _canonical_key(raw_index[0] if isinstance(raw_index, tuple) else raw_index)
        if key in seen:
            continue
        seen.add(key)
        yield key, row


def _geometry_length_km(points: Sequence[tuple[float, float]], geographic: bool) -> float:
    """Measure a polyline in kilometres, using haversine for lon/lat data."""
    distance_km = 0.0
    for start, end in zip(points, points[1:]):
        if geographic:
            lon1, lat1 = map(math.radians, start)
            lon2, lat2 = map(math.radians, end)
            dlon = lon2 - lon1
            dlat = lat2 - lat1
            a = (
                math.sin(dlat / 2.0) ** 2
                + math.cos(lat1) * math.cos(lat2) * math.sin(dlon / 2.0) ** 2
            )
            distance_km += 6371.0088 * 2.0 * math.asin(min(1.0, math.sqrt(a)))
        else:
            # Projected network geodata is conventionally stored in metres.
            distance_km += math.hypot(end[0] - start[0], end[1] - start[1]) / 1000.0
    return distance_km


def _source_bus(net: Any, requested: Any | None) -> Any:
    if requested is not None:
        return _canonical_key(requested)

    for table_name in ("ext_grid", "ext_grid_sequence", "source"):
        table = _get_table(net, table_name)
        if table is None or not hasattr(table, "columns") or "bus" not in table.columns:
            continue
        active = table
        if "in_service" in active.columns:
            active = active.loc[active["in_service"].fillna(True).astype(bool)]
        if not active.empty:
            return _canonical_key(active.iloc[0]["bus"])

    for table_name in ("asymmetric_gen", "gen"):
        table = _get_table(net, table_name)
        if table is None or not hasattr(table, "columns"):
            continue
        if {"bus", "slack"}.issubset(table.columns):
            slack = table.loc[table["slack"].fillna(False).astype(bool)]
            if not slack.empty:
                return _canonical_key(slack.iloc[0]["bus"])

    raise ValueError("Could not infer the source bus; pass source_bus explicitly.")


def _trafo_bus_groups(net: Any) -> Iterable[list[Any]]:
    table = _get_table(net, "trafo1ph", "trafo")
    if table is None or not hasattr(table, "iterrows") or len(table) == 0:
        return

    if hasattr(table.index, "names") and "bus" in table.index.names:
        element_level = table.index.names.index("index") if "index" in table.index.names else 0
        bus_level = table.index.names.index("bus")
        groups: dict[Any, list[Any]] = defaultdict(list)
        active: dict[Any, bool] = defaultdict(bool)
        for raw_index, row in table.iterrows():
            if not isinstance(raw_index, tuple):
                continue
            element = _canonical_key(raw_index[element_level])
            bus = _canonical_key(raw_index[bus_level])
            active[element] = active[element] or bool(row.get("in_service", True))
            if bus not in groups[element]:
                groups[element].append(bus)
        for element, buses in groups.items():
            if active[element] and len(buses) > 1:
                yield buses
        return

    columns = {str(column).lower(): column for column in table.columns}
    bus_columns = [
        columns[name]
        for name in ("bus", "hv_bus", "lv_bus", "from_bus", "to_bus")
        if name in columns
    ]
    for _, row in _first_physical_rows(table) or ():
        if not bool(row.get("in_service", True)):
            continue
        buses = list(dict.fromkeys(_canonical_key(row[column]) for column in bus_columns))
        if len(buses) > 1:
            yield buses


def _network_distances_km(
    net: Any,
    *,
    source_bus: Any | None = None,
) -> tuple[dict[Any, float], dict[Any, float], Any]:
    """Return source-to-bus and source-to-line-midpoint geospatial distances."""
    bus_points = _extract_bus_points(net)
    if not bus_points:
        raise ValueError("The network has no usable bus geodata.")

    explicit_lines = _extract_explicit_line_points(net)
    inferred_lines = _infer_line_points(net, bus_points)
    for line_index, points in inferred_lines.items():
        explicit_lines.setdefault(line_index, points)
    all_points = list(bus_points.values())
    for points in explicit_lines.values():
        all_points.extend(points)
    geographic = _looks_geographic(all_points)

    graph: dict[Any, list[tuple[Any, float]]] = defaultdict(list)
    line_edges: dict[Any, tuple[Any, Any, float]] = {}
    line_table = _get_table(net, "line", "branch", "branches")
    active_lines = {
        line_index: bool(row.get("in_service", True))
        for line_index, row in (_first_physical_rows(line_table) or ())
    }
    for line_index, from_bus, to_bus in _iter_edge_rows(line_table) or ():
        if not active_lines.get(line_index, True):
            continue
        points = explicit_lines.get(line_index)
        if not points:
            endpoints = (bus_points.get(from_bus), bus_points.get(to_bus))
            points = [point for point in endpoints if point is not None]
        length_km = _geometry_length_km(points, geographic) if len(points) > 1 else 0.0
        graph[from_bus].append((to_bus, length_km))
        graph[to_bus].append((from_bus, length_km))
        line_edges[line_index] = (from_bus, to_bus, length_km)

    switch_table = _get_table(net, "switch", "switches")
    for _, row in _first_physical_rows(switch_table) or ():
        if str(row.get("et", "b")).lower() != "b":
            continue
        if not bool(row.get("closed", True)) or not bool(row.get("in_service", True)):
            continue
        from_bus = _canonical_key(row.get("bus"))
        to_bus = _canonical_key(row.get("element"))
        points = [point for point in (bus_points.get(from_bus), bus_points.get(to_bus)) if point]
        length_km = _geometry_length_km(points, geographic) if len(points) > 1 else 0.0
        graph[from_bus].append((to_bus, length_km))
        graph[to_bus].append((from_bus, length_km))

    # Transformer terminals are distinct buses at the same physical location.
    for buses in _trafo_bus_groups(net) or ():
        anchor = buses[0]
        for other in buses[1:]:
            points = [point for point in (bus_points.get(anchor), bus_points.get(other)) if point]
            length_km = _geometry_length_km(points, geographic) if len(points) > 1 else 0.0
            graph[anchor].append((other, length_km))
            graph[other].append((anchor, length_km))

    origin = _source_bus(net, source_bus)
    if origin not in bus_points:
        raise ValueError(f"Source bus {origin!r} has no geodata.")

    distances = {origin: 0.0}
    queue: list[tuple[float, int, Any]] = [(0.0, 0, origin)]
    sequence = 0
    while queue:
        distance, _, bus = heapq.heappop(queue)
        if distance > distances.get(bus, math.inf):
            continue
        for neighbour, weight in graph.get(bus, ()):
            candidate = distance + weight
            if candidate < distances.get(neighbour, math.inf):
                distances[neighbour] = candidate
                sequence += 1
                heapq.heappush(queue, (candidate, sequence, neighbour))

    line_distances = {
        line_index: min(distances.get(from_bus, math.inf), distances.get(to_bus, math.inf))
        + length_km / 2.0
        for line_index, (from_bus, to_bus, length_km) in line_edges.items()
        if from_bus in distances or to_bus in distances
    }
    return distances, line_distances, origin


def _rgba(hex_color: str, alpha: float) -> str:
    color = hex_color.lstrip("#")
    red, green, blue = (int(color[offset : offset + 2], 16) for offset in (0, 2, 4))
    return f"rgba({red},{green},{blue},{alpha})"


def _normalise_calculations(calculations: Iterable[str]) -> list[str]:
    aliases = {
        "voltage": "voltage",
        "power": "power",
        "active_power": "power",
        "current": "current",
        "loss": "losses",
        "losses": "losses",
        "reactive_power": "reactive_power",
        "reactive_losses": "reactive_losses",
    }
    selected: list[str] = []
    for value in calculations:
        key = str(value).strip().lower().replace(" ", "_")
        if key not in aliases:
            raise ValueError(
                f"Unknown calculation {value!r}; choose from {', '.join(CALCULATIONS)}."
            )
        canonical = aliases[key]
        if canonical not in selected:
            selected.append(canonical)
    if not selected:
        raise ValueError("Select at least one calculation.")
    return selected


def _network_collection(
    net: Any,
    available_circuits: Sequence[str],
    *,
    circuit_key: str | None,
    network_names: Sequence[str] | None,
) -> dict[str, Any]:
    """Normalize one network or a keyed/ordered network collection."""
    if (
        _get_table(net, "bus", "buses") is not None
        or _get_table(net, "bus_geo", "bus_geodata") is not None
    ):
        selected = _circuit_key(circuit_key or available_circuits[0])
        return {selected: net}

    if isinstance(net, Mapping):
        networks = {_circuit_key(key): value for key, value in net.items()}
    elif isinstance(net, Sequence) and not isinstance(net, (str, bytes)):
        values = list(net)
        names = list(network_names or available_circuits)
        if len(values) != len(names):
            raise ValueError(
                "network_names and the network sequence must have the same length."
            )
        networks = {_circuit_key(name): value for name, value in zip(names, values)}
    else:
        raise TypeError("net must be a network, a mapping, or a sequence of networks.")

    missing = [key for key in available_circuits if key not in networks]
    if missing:
        raise ValueError(
            "No network model was supplied for result circuit(s): " + ", ".join(missing)
        )
    return {key: networks[key] for key in available_circuits}


def _source_for_circuit(source_bus: Any, circuit_key: str) -> Any:
    if isinstance(source_bus, Mapping):
        return source_bus.get(circuit_key)
    return source_bus


def plot_power_flow_by_distance(
    net: Any,
    comparison_df: pd.DataFrame,
    line_comparison_df: pd.DataFrame,
    *,
    circuit_key: str | None = None,
    network_names: Sequence[str] | None = None,
    source_bus: Any | None = None,
    calculations: Iterable[str] = ("voltage", "power", "current", "losses"),
    engines: Iterable[str] = ("MC", "DSS"),
    chart_type: str = "area",
    distance_unit: str = "km",
    title: str | None = None,
) -> go.Figure:
    """Plot comparable MC/OpenDSS profiles against feeder distance.

    ``net`` may be one network, a ``{result_name: network}`` mapping, or a
    sequence paired with ``network_names``. Distance is the shortest connected
    path from each network's source bus, measured from bus/line geodata. Closed
    bus switches and transformer winding buses are included in the topology;
    disconnected floating buses are omitted. The menus select network, metric
    and engine, and transparent area, line, or scatter rendering independently.

    ``comparison_df`` and ``line_comparison_df`` are the bus and line frames
    returned by :func:`run_meshed_network_comparison`.
    """
    selected_calculations = _normalise_calculations(calculations)
    selected_engines = [str(engine).upper() for engine in engines]
    selected_engines = [engine for engine in ("MC", "DSS") if engine in selected_engines]
    if not selected_engines:
        raise ValueError("Select at least one engine: MC or DSS.")

    chart_type = str(chart_type).strip().lower()
    if chart_type not in {"area", "line", "scatter"}:
        raise ValueError("chart_type must be 'area', 'line', or 'scatter'.")
    unit_factors = {"km": (1.0, "km"), "m": (1000.0, "m"), "mi": (0.621371, "mi")}
    if distance_unit not in unit_factors:
        raise ValueError("distance_unit must be 'km', 'm', or 'mi'.")
    distance_factor, distance_label = unit_factors[distance_unit]

    bus, line = build_plot_dataframes(comparison_df, line_comparison_df)
    available_circuits = list(
        dict.fromkeys(
            [
                *bus.get("circuit_key", pd.Series(dtype=str)).dropna().astype(str),
                *line.get("circuit_key", pd.Series(dtype=str)).dropna().astype(str),
            ]
        )
    )
    if not available_circuits:
        raise ValueError("No circuit results are available to plot.")
    networks = _network_collection(
        net,
        available_circuits,
        circuit_key=circuit_key,
        network_names=network_names,
    )
    available_circuits = list(networks)
    if circuit_key is None:
        circuit_key = available_circuits[0]
    circuit_key = _circuit_key(circuit_key)
    if circuit_key not in available_circuits:
        raise ValueError(f"Circuit {circuit_key!r} is not present in the supplied networks.")

    needs_bus = any(CALCULATIONS[value]["frame"] == "bus" for value in selected_calculations)
    needs_line = any(CALCULATIONS[value]["frame"] == "line" for value in selected_calculations)
    if needs_bus and "BUS_ID" not in bus.columns:
        raise ValueError("comparison_df must contain bus_idx for geodata alignment.")
    if needs_line and "LINE_IDX" not in line.columns:
        raise ValueError("line_comparison_df must contain line_idx for geodata alignment.")

    aligned: dict[str, dict[str, Any]] = {}
    for network_key, network in networks.items():
        bus_distances, line_distances, origin = _network_distances_km(
            network,
            source_bus=_source_for_circuit(source_bus, network_key),
        )
        network_bus = bus.loc[bus["circuit_key"].astype(str) == network_key].copy()
        network_line = line.loc[line["circuit_key"].astype(str) == network_key].copy()
        if "BUS_ID" in network_bus:
            network_bus["DISTANCE"] = (
                network_bus["BUS_ID"].map(bus_distances) * distance_factor
            )
            network_bus = network_bus.loc[network_bus["DISTANCE"].notna()]
        if "LINE_IDX" in network_line:
            network_line["DISTANCE"] = (
                network_line["LINE_IDX"].map(line_distances) * distance_factor
            )
            network_line = network_line.loc[network_line["DISTANCE"].notna()]
        aligned[network_key] = {
            "bus": network_bus,
            "line": network_line,
            "origin": origin,
        }

    available_calculations = []
    for calculation in selected_calculations:
        definition = CALCULATIONS[calculation]
        frames = [values[definition["frame"]] for values in aligned.values()]
        if any(
            f"{field}_{engine}" in frame.columns
            and pd.to_numeric(frame[f"{field}_{engine}"], errors="coerce").notna().any()
            for frame in frames
            for field in definition["fields"]
            for engine in selected_engines
        ):
            available_calculations.append(calculation)
    selected_calculations = available_calculations
    if not selected_calculations:
        raise ValueError("No selected calculations are available in the aligned result frames.")

    mode = "markers" if chart_type == "scatter" else "lines"
    fill = "tozeroy" if chart_type == "area" else "none"
    def trace_payload(
        network_key: str,
        calculation: str,
        engine: str,
        field: str,
        phase_label: str,
    ) -> dict[str, Any]:
        definition = CALCULATIONS[calculation]
        frame = aligned[network_key][definition["frame"]]
        id_column = "NODE_ID" if definition["frame"] == "bus" else "LINE_ID"
        column = f"{field}_{engine}"
        if column not in frame.columns or "DISTANCE" not in frame.columns:
            return {"x": [], "y": [], "customdata": []}
        selected = frame
        if definition["frame"] == "line":
            selected = selected.loc[selected["PHASE"].astype(str).str.upper() == phase_label]
        values = pd.to_numeric(selected[column], errors="coerce")
        valid = values.notna() & selected["DISTANCE"].notna()
        selected = selected.loc[valid].copy()
        selected["VALUE"] = values.loc[valid]
        selected = selected.sort_values("DISTANCE")
        if selected.empty:
            return {"x": [], "y": [], "customdata": []}
        return {
            "x": selected["DISTANCE"].to_numpy(),
            "y": selected["VALUE"].to_numpy(),
            "customdata": np.column_stack(
                [
                    selected[id_column].astype(str),
                    np.full(len(selected), phase_label),
                    np.full(len(selected), engine),
                ]
            ),
        }

    trace_slots: list[tuple[str, str, str, str]] = []
    for calculation in selected_calculations:
        definition = CALCULATIONS[calculation]
        for engine in selected_engines:
            for field in definition["fields"]:
                if field in {"VA", "VB", "VC"}:
                    phases = [field[-1]]
                else:
                    phases = sorted(
                        {
                            str(phase).upper()
                            for values in aligned.values()
                            for phase in values["line"].get(
                                "PHASE", pd.Series(dtype=str)
                            ).dropna()
                        }
                    )
                for phase_label in phases:
                    if any(
                        len(trace_payload(key, calculation, engine, field, phase_label)["x"])
                        for key in available_circuits
                    ):
                        trace_slots.append(
                            (calculation, engine, field, phase_label)
                        )

    figure = go.Figure()
    trace_keys: list[tuple[str, str]] = []
    for calculation, engine, field, phase_label in trace_slots:
        definition = CALCULATIONS[calculation]
        payload = trace_payload(circuit_key, calculation, engine, field, phase_label)
        display_phase = phase_label if phase_label in {"A", "B", "C"} else "Total"
        figure.add_trace(
            go.Scatter(
                            x=payload["x"],
                            y=payload["y"],
                            customdata=payload["customdata"],
                            mode=mode,
                            fill=fill,
                            fillcolor=_rgba(SOURCE_COLORS[engine], 0.12),
                            line={
                                "color": SOURCE_COLORS[engine],
                                "width": 1.6,
                                "dash": PHASE_DASHES.get(display_phase, "solid"),
                            },
                            marker={
                                "color": SOURCE_COLORS[engine],
                                "size": 6,
                                "symbol": PHASE_SYMBOLS.get(
                                    display_phase, SOURCE_SYMBOLS[engine]
                                ),
                                "opacity": 0.82,
                            },
                            name=f"{engine} · {display_phase}",
                            legendgroup=f"{calculation}:{engine}",
                            legendgrouptitle_text=f"{definition['title']} · {engine}",
                            visible=calculation == selected_calculations[0],
                            hovertemplate=(
                                "%{customdata[0]} · phase %{customdata[1]}"
                                "<br>Engine: %{customdata[2]}"
                                f"<br>Distance: %{{x:.3f}} {distance_label}"
                                f"<br>{definition['title']}: %{{y:.6g}} {definition['unit']}"
                                "<extra></extra>"
                            ),
                        )
        )
        trace_keys.append((calculation, engine))

    if not figure.data:
        raise ValueError("No aligned MC/OpenDSS voltage, power, current, or loss data found.")

    view_buttons = []
    for calculation in selected_calculations:
        definition = CALCULATIONS[calculation]
        engine_views: list[tuple[str, set[str]]] = [("Both", set(selected_engines))]
        if len(selected_engines) > 1:
            engine_views.extend((engine, {engine}) for engine in selected_engines)
        for engine_label, enabled_engines in engine_views:
            visibility = [
                trace_calculation == calculation and trace_engine in enabled_engines
                for trace_calculation, trace_engine in trace_keys
            ]
            view_buttons.append(
                {
                    "label": f"{definition['title']} · {engine_label}",
                    "method": "update",
                    "args": [
                        {"visible": visibility},
                        {
                            "annotations[1].text": f" · {definition['title']}",
                            "yaxis.title.text": f"{definition['title']} ({definition['unit']})",
                        },
                    ],
                }
            )

    style_buttons = [
        {
            "label": "Area",
            "method": "restyle",
            "args": [{"mode": "lines", "fill": "tozeroy"}],
        },
        {
            "label": "Line",
            "method": "restyle",
            "args": [{"mode": "lines", "fill": "none"}],
        },
        {
            "label": "Scatter",
            "method": "restyle",
            "args": [{"mode": "markers", "fill": "none"}],
        },
    ]
    network_buttons = []
    for network_key in available_circuits:
        payloads = [
            trace_payload(network_key, calculation, engine, field, phase)
            for calculation, engine, field, phase in trace_slots
        ]
        display_title = f"{title} · {network_key}" if title else network_key
        network_buttons.append(
            {
                "label": network_key,
                "method": "update",
                "args": [
                    {
                        "x": [payload["x"] for payload in payloads],
                        "y": [payload["y"] for payload in payloads],
                        "customdata": [payload["customdata"] for payload in payloads],
                    },
                    {
                        "annotations[0].text": display_title,
                        "xaxis.title.text": (
                            "Distance from source bus "
                            f"{aligned[network_key]['origin']} ({distance_label})"
                        ),
                    },
                ],
            }
        )

    initial = CALCULATIONS[selected_calculations[0]]
    initial_title = f"{title} · {circuit_key}" if title else circuit_key
    figure.update_layout(
        template="plotly_dark",
        paper_bgcolor="rgba(0,0,0,0)",
        plot_bgcolor="rgba(0,0,0,0)",
        title=None,
        xaxis_title=(
            f"Distance from source bus {aligned[circuit_key]['origin']} ({distance_label})"
        ),
        yaxis_title=f"{initial['title']} ({initial['unit']})",
        height=630,
        hovermode="x unified",
        legend={
            "title": {"text": ""},
            "groupclick": "togglegroup",
            "orientation": "h",
            "yanchor": "top",
            "y": -0.20,
            "xanchor": "center",
            "x": 0.5,
        },
        updatemenus=[
            {
                "buttons": network_buttons,
                "direction": "down",
                "showactive": True,
                "active": available_circuits.index(circuit_key),
                "x": 0.0,
                "xanchor": "left",
                "y": 1.20,
                "yanchor": "top",
                "name": "Network",
            },
            {
                "buttons": style_buttons,
                "direction": "down",
                "showactive": True,
                "active": {"area": 0, "line": 1, "scatter": 2}[chart_type],
                "x": 1.0,
                "xanchor": "right",
                "y": 1.22,
                "yanchor": "top",
                "name": "Chart",
            },
            {
                "buttons": view_buttons,
                "direction": "down",
                "showactive": True,
                "x": 1.0,
                "xanchor": "right",
                "y": 1.08,
                "yanchor": "top",
                "name": "View",
            },
        ],
        annotations=[
            {
                "text": initial_title,
                "xref": "paper",
                "yref": "paper",
                "x": 0.495,
                "y": 1.205,
                "showarrow": False,
                "xanchor": "right",
                "font": {"size": 16},
            },
            {
                "text": f" · {initial['title']}",
                "xref": "paper",
                "yref": "paper",
                "x": 0.505,
                "y": 1.205,
                "showarrow": False,
                "xanchor": "left",
                "font": {"size": 16},
            },
        ],
        margin={"t": 135, "r": 30, "b": 145, "l": 75},
    )
    figure.update_xaxes(showgrid=True, gridcolor="rgba(148,163,184,0.20)", zeroline=False)
    figure.update_yaxes(showgrid=True, gridcolor="rgba(148,163,184,0.20)", zeroline=False)
    return figure
