"""
Multiconductor Network Diagnostic Agent
========================================
Uses the OpenAI Agents SDK to diagnose convergence issues in unbalanced
three-phase distribution system network models (pandapower-multiconductor).

Usage:
    python mc_diagnostic_agent.py <path_to_network.pkl>

Requires:
    - OPENAI_API_KEY environment variable set
    - openai-agents  (pip install openai-agents)
    - multiconductor package on sys.path
"""

from __future__ import annotations

import json
import os
import pickle
import sys
import traceback
from pathlib import Path

import numpy as np
import pandas as pd

# Ensure the workspace root is on sys.path for local packages
_ws = str(Path(__file__).resolve().parent)
if _ws not in sys.path:
    sys.path.insert(0, _ws)

from agents import Agent, Runner, function_tool

# ---------------------------------------------------------------------------
# Tool helpers — serialise DataFrames / network tables for the LLM
# ---------------------------------------------------------------------------

def _df_summary(df: pd.DataFrame, name: str, max_rows: int = 30) -> str:
    """Return a compact text summary of a DataFrame."""
    if df.empty:
        return f"{name}: empty (0 rows)"
    lines = [f"{name}: {len(df)} rows, columns={list(df.columns)}"]
    lines.append(df.head(max_rows).to_string(max_colwidth=60))
    if len(df) > max_rows:
        lines.append(f"  … ({len(df) - max_rows} more rows)")
    return "\n".join(lines)


def _load_network(pkl_path: str):
    """Load a pickled pandapower-multiconductor network."""
    with open(pkl_path, "rb") as fh:
        return pickle.load(fh)


# ---------------------------------------------------------------------------
# Agent tools
# ---------------------------------------------------------------------------

_NET_STORE: dict = {}  # holds the loaded network during the session


@function_tool
def load_network(pkl_path: str) -> str:
    """Load a multiconductor network from a .pkl file and return a high-level summary."""
    try:
        net = _load_network(pkl_path)
        _NET_STORE["net"] = net
        _NET_STORE["pkl_path"] = pkl_path

        element_types = [
            "bus", "line", "switch", "ext_grid", "ext_grid_sequence",
            "trafo", "trafo1ph", "trafo3w",
            "asymmetric_load", "asymmetric_sgen", "asymmetric_gen",
            "asymmetric_shunt", "shunt", "measurement", "controller",
        ]
        summary_rows = []
        for et in element_types:
            tbl = getattr(net, et, None)
            if isinstance(tbl, pd.DataFrame) and not tbl.empty:
                summary_rows.append({"element": et, "count": len(tbl)})

        info = {
            "name": getattr(net, "name", ""),
            "f_hz": float(getattr(net, "f_hz", 0)),
            "sn_mva": float(getattr(net, "sn_mva", 0)),
            "converged": bool(getattr(net, "converged", False)),
            "elements": summary_rows,
        }
        return json.dumps(info, indent=2)
    except Exception:
        return f"ERROR loading network: {traceback.format_exc()}"


@function_tool
def inspect_table(table_name: str, max_rows: int = 30) -> str:
    """Return the first N rows of a network table (bus, line, ext_grid, etc.)."""
    net = _NET_STORE.get("net")
    if net is None:
        return "No network loaded. Call load_network first."
    tbl = getattr(net, table_name, None)
    if not isinstance(tbl, pd.DataFrame):
        return f"Table '{table_name}' not found or is not a DataFrame."
    return _df_summary(tbl, table_name, max_rows)


@function_tool
def run_powerflow(max_iter: int = 100) -> str:
    """Run the multiconductor CCI power flow and return convergence info."""
    net = _NET_STORE.get("net")
    if net is None:
        return "No network loaded. Call load_network first."
    try:
        from multiconductor.pycci.cci_powerflow import run_pf
        run_pf(net, MaxIter=max_iter)
        solved = bool(getattr(net.model, "solved", False))
        iters = int(getattr(net.model, "iterations", -1))
        converged = bool(getattr(net, "converged", False))
        return json.dumps({
            "converged": converged,
            "solved": solved,
            "iterations": iters,
            "max_iter": max_iter,
        })
    except Exception:
        return f"Power flow failed:\n{traceback.format_exc()}"


@function_tool
def get_voltage_profile() -> str:
    """Return per-bus voltage magnitude statistics from the last power flow."""
    net = _NET_STORE.get("net")
    if net is None:
        return "No network loaded."
    res_bus = getattr(net, "res_bus", None)
    if res_bus is None or not isinstance(res_bus, pd.DataFrame) or res_bus.empty:
        return "No power flow results available. Run run_powerflow first."
    if "vm_pu" not in res_bus.columns:
        return "res_bus has no vm_pu column."
    vm = pd.to_numeric(res_bus["vm_pu"], errors="coerce").dropna()
    vm = vm[vm > 0]
    if vm.empty:
        return "All vm_pu values are NaN or zero."

    # Per-bus aggregation (collapse phases)
    if isinstance(res_bus.index, pd.MultiIndex):
        bus_vm = vm.groupby(level=0).agg(["min", "max", "mean", "std"])
    else:
        bus_vm = vm.to_frame("vm_pu")
        bus_vm["min"] = vm
        bus_vm["max"] = vm
        bus_vm["mean"] = vm
        bus_vm["std"] = 0.0

    out_of_range = bus_vm[(bus_vm["min"] < 0.9) | (bus_vm["max"] > 1.1)]
    stats = {
        "total_buses": int(bus_vm.shape[0]),
        "vm_min": float(vm.min()),
        "vm_max": float(vm.max()),
        "vm_mean": float(vm.mean()),
        "buses_outside_0.9_1.1": int(len(out_of_range)),
        "worst_low_buses": out_of_range.nsmallest(5, "min").to_dict("index") if len(out_of_range) else {},
        "worst_high_buses": out_of_range.nlargest(5, "max").to_dict("index") if len(out_of_range) else {},
    }
    return json.dumps(stats, indent=2, default=str)


@function_tool
def run_validation_checks() -> str:
    """Run the multiconductor network validation suite and return all issues."""
    net = _NET_STORE.get("net")
    if net is None:
        return "No network loaded."
    try:
        from multiconductor.network_validators import run_multiconductor_validations
        result = run_multiconductor_validations(net)
        parts = []
        parts.append(f"Issues found: {len(result.issues)}")
        if not result.issues.empty:
            parts.append(result.issues.to_string(max_colwidth=80))
        parts.append(f"\nRecommendations: {len(result.recommendations)}")
        if not result.recommendations.empty:
            parts.append(result.recommendations.to_string(max_colwidth=80))
        return "\n".join(parts)
    except Exception:
        return f"Validation failed:\n{traceback.format_exc()}"


@function_tool
def check_topology() -> str:
    """Analyze network topology: components, loops, slack bus assignment."""
    net = _NET_STORE.get("net")
    if net is None:
        return "No network loaded."
    try:
        import networkx as nx
        bus = getattr(net, "bus", pd.DataFrame())
        if bus.empty:
            return "No buses in network."

        bus_ids = set(bus.index.get_level_values(0).unique()) if isinstance(bus.index, pd.MultiIndex) else set(bus.index)
        G = nx.Graph()
        G.add_nodes_from(bus_ids)

        checked = set()
        for tbl_name, from_col, to_col in [("line", "from_bus", "to_bus")]:
            tbl = getattr(net, tbl_name, pd.DataFrame())
            for idx, row in tbl.iterrows():
                eid = idx[0] if isinstance(idx, tuple) else idx
                if eid in checked:
                    continue
                checked.add(eid)
                fb, tb = row.get(from_col), row.get(to_col)
                if fb in bus_ids and tb in bus_ids:
                    G.add_edge(fb, tb)

        checked_t = set()
        for tbl_name in ("trafo", "trafo1ph"):
            tbl = getattr(net, tbl_name, pd.DataFrame())
            if tbl.empty:
                continue
            if tbl_name == "trafo1ph" and isinstance(tbl.index, pd.MultiIndex) and "bus" in tbl.index.names:
                idx_level = tbl.index.names.index("index") if "index" in tbl.index.names else 0
                for tid in tbl.index.get_level_values(idx_level).unique():
                    if tid in checked_t:
                        continue
                    checked_t.add(tid)
                    try:
                        sub = tbl.xs(tid, level=idx_level)
                        bus_level = sub.index.names.index("bus") if "bus" in sub.index.names else 0
                        trafo_buses = list(dict.fromkeys(sub.index.get_level_values(bus_level).tolist()))
                        if len(trafo_buses) >= 2 and trafo_buses[0] in bus_ids and trafo_buses[1] in bus_ids:
                            G.add_edge(trafo_buses[0], trafo_buses[1])
                    except Exception:
                        pass
            else:
                for idx, row in tbl.iterrows():
                    eid = idx[0] if isinstance(idx, tuple) else idx
                    if eid in checked_t:
                        continue
                    checked_t.add(eid)
                    hv, lv = row.get("hv_bus"), row.get("lv_bus")
                    if hv in bus_ids and lv in bus_ids:
                        G.add_edge(hv, lv)

        # Switches
        sw = getattr(net, "switch", pd.DataFrame())
        for idx, row in sw.iterrows():
            if bool(row.get("closed", True)) and row.get("et") == "b":
                u, v = row.get("bus"), row.get("element")
                if u in bus_ids and v in bus_ids:
                    G.add_edge(u, v)

        components = list(nx.connected_components(G))
        cycles = nx.cycle_basis(G)

        # Slack buses
        eg = getattr(net, "ext_grid", pd.DataFrame())
        egs = getattr(net, "ext_grid_sequence", pd.DataFrame())
        slack_buses = set()
        if not eg.empty and "bus" in eg.columns:
            slack_buses.update(eg["bus"].tolist())
        if not egs.empty and "bus" in egs.columns:
            slack_buses.update(egs["bus"].tolist())

        islanded = []
        for comp in components:
            if not comp.intersection(slack_buses):
                islanded.append({"size": len(comp), "sample_buses": sorted(list(comp))[:10]})

        info = {
            "total_buses": len(bus_ids),
            "total_components": len(components),
            "main_component_size": max(len(c) for c in components) if components else 0,
            "islanded_components": islanded,
            "num_loops": len(cycles),
            "slack_buses": sorted(list(slack_buses)),
        }
        return json.dumps(info, indent=2, default=str)
    except Exception:
        return f"Topology check failed:\n{traceback.format_exc()}"


@function_tool
def check_phase_consistency() -> str:
    """Examine phase assignments across buses, lines, loads, and transformers."""
    net = _NET_STORE.get("net")
    if net is None:
        return "No network loaded."
    bus = getattr(net, "bus", pd.DataFrame())
    if bus.empty:
        return "No buses."

    bus_phase_map = {}
    if isinstance(bus.index, pd.MultiIndex):
        for bid in bus.index.get_level_values(0).unique():
            phases = set(bus.index.get_level_values(1)[bus.index.get_level_values(0) == bid].tolist())
            bus_phase_map[bid] = phases

    issues = []
    for tbl_name, bus_col, phase_col in [
        ("line", "from_bus", "from_phase"),
        ("asymmetric_load", "bus", "from_phase"),
        ("asymmetric_sgen", "bus", "from_phase"),
    ]:
        tbl = getattr(net, tbl_name, pd.DataFrame())
        if tbl.empty or phase_col not in tbl.columns:
            continue
        checked = set()
        for idx, row in tbl.iterrows():
            eid = idx[0] if isinstance(idx, tuple) else idx
            if eid in checked:
                continue
            checked.add(eid)
            bus_idx = row.get(bus_col)
            elem_phase = row.get(phase_col)
            bus_phases = bus_phase_map.get(bus_idx, set())
            if bus_phases and isinstance(elem_phase, (int, float, np.integer)):
                if int(elem_phase) not in bus_phases:
                    issues.append({
                        "element": tbl_name,
                        "index": str(eid),
                        "bus": str(bus_idx),
                        "elem_phase": int(elem_phase),
                        "bus_phases": sorted(list(bus_phases)),
                    })

    return json.dumps({
        "buses_with_phase_info": len(bus_phase_map),
        "phase_mismatch_issues": issues[:50],
        "total_mismatches": len(issues),
    }, indent=2, default=str)


@function_tool
def get_ext_grid_info() -> str:
    """Return external grid / slack bus configuration details."""
    net = _NET_STORE.get("net")
    if net is None:
        return "No network loaded."
    parts = []
    for name in ("ext_grid", "ext_grid_sequence"):
        tbl = getattr(net, name, pd.DataFrame())
        if not tbl.empty:
            parts.append(_df_summary(tbl, name, 20))
    if not parts:
        return "No ext_grid or ext_grid_sequence found — network has no slack bus!"
    return "\n\n".join(parts)


@function_tool
def get_transformer_info() -> str:
    """Return transformer configuration summary."""
    net = _NET_STORE.get("net")
    if net is None:
        return "No network loaded."
    parts = []
    for name in ("trafo", "trafo1ph", "trafo3w"):
        tbl = getattr(net, name, pd.DataFrame())
        if not tbl.empty:
            parts.append(_df_summary(tbl, name, 30))
    if not parts:
        return "No transformers in network."
    return "\n\n".join(parts)


# ---------------------------------------------------------------------------
# The Agent
# ---------------------------------------------------------------------------

SYSTEM_PROMPT = """\
You are an expert in distribution power system modeling, analysis, and diagnostics, \
specializing in unbalanced three-phase network power flow for distribution systems. \
You assist engineers in understanding and resolving issues in models that fail to \
converge during power flow or state estimation analysis.

Your knowledge includes network modeling, load flow solution techniques \
(e.g., Newton-Raphson, Forward-Backward Sweep, and Fast Decoupled methods), \
distribution topology validation, and phase connectivity verification.

Core Responsibilities:
1. Diagnose convergence issues: Identify likely causes of non-convergence in \
unbalanced three-phase distribution system network models.
2. Analyze input data quality: Verify node voltage bases, load/generation data, \
transformer connections, tap positions, and shunt elements.
3. Validate network topology: Ensure radial or weakly meshed topology, proper \
slack bus assignment, detect open points, loops, and isolated nodes.
4. Check phase connectivity: Verify phase assignments, sequencing, and balance.
5. Recommend corrective actions with concrete steps.

Troubleshooting Approach:
1. Load the network and review its structure.
2. Run the validation checks to identify data and topology issues.
3. Attempt a power flow and examine convergence behavior.
4. Check voltage profile for anomalies.
5. Analyze topology for isolated components or loops.
6. Check phase consistency across elements.
7. Provide a comprehensive diagnostic report.

IMPORTANT: Always return your final answer as strict JSON with this schema:
{
  "summary": "...",
  "likely_root_causes": ["..."],
  "topology_checks": ["..."],
  "data_checks": ["..."],
  "phasing_checks": ["..."],
  "numerical_stabilization": ["..."],
  "recommended_fixes": ["..."],
  "next_retest_plan": ["..."]
}
"""

diagnostic_agent = Agent(
    name="MC Diagnostic Agent",
    instructions=SYSTEM_PROMPT,
    tools=[
        load_network,
        inspect_table,
        run_powerflow,
        get_voltage_profile,
        run_validation_checks,
        check_topology,
        check_phase_consistency,
        get_ext_grid_info,
        get_transformer_info,
    ],
)


# ---------------------------------------------------------------------------
# CLI entry point
# ---------------------------------------------------------------------------

async def _run(pkl_path: str) -> None:
    user_msg = (
        f"Please diagnose the multiconductor network at: {pkl_path}\n\n"
        "1. Load the network\n"
        "2. Run validation checks\n"
        "3. Attempt power flow\n"
        "4. Check voltage profile\n"
        "5. Analyze topology\n"
        "6. Check phase consistency\n"
        "7. Examine ext_grid and transformer configuration\n"
        "8. Provide your full diagnostic report as JSON."
    )
    result = await Runner.run(diagnostic_agent, user_msg)
    print("\n" + "=" * 72)
    print("DIAGNOSTIC REPORT")
    print("=" * 72)
    print(result.final_output)


def main() -> None:
    if len(sys.argv) < 2:
        print("Usage: python mc_diagnostic_agent.py <path_to_network.pkl>")
        sys.exit(1)
    pkl_path = sys.argv[1]
    if not Path(pkl_path).exists():
        print(f"File not found: {pkl_path}")
        sys.exit(1)

    import asyncio
    asyncio.run(_run(pkl_path))


if __name__ == "__main__":
    main()
