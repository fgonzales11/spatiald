"""Native numerical and wire-level regression tests for the MCP adapter."""
import asyncio
import json
import sys
from pathlib import Path

import numpy as np
import pandas as pd
import pytest
from multiconductor.addons.mcp import mc_mcp as a


def ok(result):
    assert result['status'] == 'success', result
    json.dumps(result, allow_nan=False)
    return result


def frame(payload):
    return pd.DataFrame(payload['data'], columns=payload['columns'])


@pytest.fixture(autouse=True)
def demo():
    ok(a.create_demo_network())


def test_serialization_and_real_pf():
    result = ok(a.run_power_flow())['results']
    assert result['converged']
    assert result['violations']['complete']
    assert not result['violations']['has_violations']
    assert result['bus_results']['index_names'] == ['index', 'phase']
    assert result['line_results']['index_names'] == ['index', 'circuit']
    assert result['trafo_results']['index_names'] == ['index', 'bus', 'circuit']
    assert ok(a.get_network_info())['info']['elements']['buses'] == 3
    payload = a._clean_data({'b': np.bool_(True), 'z': np.complex128(1 + 2j), 'bad': np.inf})
    assert payload == {'b': True, 'z': {'real': 1., 'imag': 2.}, 'bad': None}


def test_atomic_updates_and_invalidation():
    ok(a.run_power_flow())
    original = a._current_net.line.copy(deep=True)
    assert a.update_network_rows([
        {'table': 'line', 'selector': {'index': 0}, 'values': {'length_km': 0.1}},
        {'table': 'line', 'selector': {'phase': 1}, 'values': {'length_km': 1}},
    ])['status'] == 'error'
    pd.testing.assert_frame_equal(a._current_net.line, original)
    ok(a.update_network_rows([{'table': 'line', 'selector': {'index': 0, 'circuit': 1}, 'values': {'df': 0.5}}]))
    assert not a.analysis.is_solved(a._current_net)
    assert a._current_net.res_bus.empty
    result = ok(a.run_power_flow())['results']
    ratings = frame(result['line_results']).rating_ka.tolist()
    assert ratings == [0.2, 0.1, 0.2, 0.2, 0.2, 0.2]


def test_lifecycle_pickle_requires_explicit_trust(tmp_path):
    path = tmp_path / 'network.pkl'
    ok(a.save_network(str(path)))
    baseline = a._current_net
    assert a.load_network(str(path))['status'] == 'error'
    assert a._current_net is baseline
    ok(a.load_network(str(path), trusted_pickle=True))
    ok(a.run_power_flow())
    assert a.load_network(str(tmp_path / 'bad.xlsx'))['status'] == 'error'
    assert len(a._current_net.bus) == 12


def test_diagnostics_and_independent_scenarios():
    result = ok(a.run_diagnostics())['results']
    assert result['execution_errors'] == []
    original = a._current_net.asymmetric_load.copy(deep=True)
    update = {'table': 'asymmetric_load', 'selector': {'index': 0}, 'values': {'scaling': 0.5}}
    result = ok(a.compare_scenarios([
        {'name': 'half', 'updates': [update]}, {'name': 'half-again', 'updates': [update]},
        {'name': 'bad', 'updates': [{'table': 'line', 'selector': {'index': 999}, 'values': {'in_service': False}}]},
    ]))['scenarios']
    assert result[1]['results'] == result[2]['results']
    assert result[3]['status'] == 'error'
    pd.testing.assert_frame_equal(a._current_net.asymmetric_load, original)


def test_contingency_retains_island_and_failures():
    original = a._current_net.line.copy(deep=True)
    result = ok(a.run_contingency_analysis(elements=['line']))
    assert len(frame(result['results']['case_table'])) == 2
    result = ok(a.run_contingency_analysis(cases=[
        {'case_id': 'both', 'actions': [{'table': 'line', 'index': 0}, {'table': 'line', 'index': 1}]},
        {'case_id': 'bad', 'actions': [{'table': 'line', 'index': 999}]},
    ]))
    statuses = frame(result['results']['case_table']).status.tolist()
    assert statuses[0] == 'islanded'
    assert statuses[1] in {'invalid', 'error'}
    pd.testing.assert_frame_equal(a._current_net.line, original)
    assert a.run_contingency_analysis(cases=[{'case_id': 'bad', 'actions': [
        {'table': 'line', 'index': 0, 'bus': 1}]}])['status'] == 'error'


def test_time_series_baseline_and_failures():
    original = a._current_net.asymmetric_load.copy(deep=True)
    result = ok(a.run_time_series(
        [{'TIME_STEP': i, 'demand': v} for i, v in enumerate([0.5, 1., 1.5])],
        [{'table': 'asymmetric_load', 'variable': col, 'profile': 'demand', 'mode': 'scale'} for col in ['p_mw', 'q_mvar']],
    ))
    assert frame(result['statuses']).STATUS.tolist() == ['converged'] * 3
    assert len(frame(result['results'])) > 0
    pd.testing.assert_frame_equal(a._current_net.asymmetric_load, original)


def test_state_estimation_and_observability():
    ok(a.run_power_flow())
    net = a._current_net
    truth = net.model.E.reshape(-1).copy()
    pf = net.res_bus.copy(deep=True)
    # Creation invalidates results, so retain solved truth before adding measurements.
    for (bus, phase), row in pf.iterrows():
        if net.bus.at[(bus, phase), 'grounded'] or not np.isfinite(row.vm_pu):
            continue
        voltage = row.vm_pu * np.exp(1j * np.deg2rad(row.va_degree))
        for kind, value in [('vr', voltage.real), ('vi', voltage.imag)]:
            ok(a.create_native_element('create_state_measurement', dict(
                measurement_type=kind, element_type='bus', element=int(bus),
                value=float(value), std_dev=5e-4, phase=int(phase))))
    result = ok(a.run_state_estimation())['results']
    assert result['converged']
    estimate = np.array([complex(v['real'], v['imag']) for v in result['voltage']])
    assert np.max(np.abs(estimate - truth)) < 1e-7
    pd.testing.assert_frame_equal(a._current_net.res_bus, pf)
    a._current_net.measurement = a._current_net.measurement.iloc[:1].copy()
    assert a.run_state_estimation({'raise_on_failure': True})['status'] == 'error'


def finite_source():
    ok(a.update_network_rows([{'table': 'ext_grid_sequence', 'selector': {'index': 0},
        'values': {'r_ohm': 0.1, 'x_ohm': 1.0}}]))


@pytest.mark.parametrize('fault,phases', [('LLL', [1, 2, 3]), ('LL', [1, 2]), ('LG', [1]), ('LLG', [1, 2])])
def test_short_circuit(fault, phases):
    finite_source()
    result = ok(a.run_short_circuit({'fault': fault, 'bus': 2, 'phases': phases, 'ip': True, 'ith': True}))
    rows = frame(result['results']['res_bus_sc'])
    faulted = rows[rows.faulted]
    assert len(faulted) == len(phases)
    assert (faulted.ikss_ka > 0).all()
    assert np.isfinite(faulted[['ikss_ka', 'ip_ka', 'ith_ka']].to_numpy()).all()


def test_line_fault_and_protection():
    finite_source()
    ok(a.run_short_circuit({'fault': 'LG', 'line': 0, 'location': 0.5, 'phases': [1]}))
    ok(a.update_network_rows([{'table': 'line', 'selector': {'index': 1}, 'values': {'in_service': False}}]))
    for bus, delay in [(1, 0.4), (2, 0.1)]:
        sid = ok(a.create_switch(bus=bus, phase=[1, 2, 3], element=0, et='l'))['index']
        ok(a.create_native_element('create_dtoc', {'switch_index': sid, 'pickup_ka': 0.2, 'delay_s': delay}))
    original = a._current_net.switch.closed.copy()
    result = ok(a.run_protection_coordination({'fault': 'LG', 'bus': 2, 'phases': [1]}, trip_switches=True))
    assert sorted(frame(result['timing']).trip_time_s) == [0.1, 0.4]
    backup = frame(result['coordination']).query("role == 'backup'")
    assert np.isclose(backup.grading_margin_s.iloc[0], 0.3)
    assert frame(result['operations']).operated.sum() == 1
    pd.testing.assert_series_equal(a._current_net.switch.closed, original)


def test_fixed_opf():
    finite_source()
    ok(a.create_native_element('create_poly_cost', {'element': 0, 'et': 'ext_grid_sequence', 'cp1_eur_per_mw': 100}))
    original = a._current_net.asymmetric_load.copy(deep=True)
    result = ok(a.run_optimal_power_flow())['results']
    assert result['converged']
    assert np.isfinite(result['objective'])
    pd.testing.assert_frame_equal(a._current_net.asymmetric_load, original)


def test_equivalent_and_complex_boundary():
    model = ok(a.create_grid_equivalent([2]))['model']
    assert model['validation']['passed']
    result = ok(a.solve_grid_equivalent())
    assert result['residual_max'] < 1e-6
    ok(a.solve_grid_equivalent({'voltage': model['base_voltage']}))
    assert a.create_grid_equivalent([[999, 1]])['status'] == 'error'
    assert len(a._current_net.bus) == 12


def test_native_configuration_and_plugin_coverage():
    result = ok(a.get_capabilities())
    assert len(result['plugins']) == 14
    for operation in result['native_operations']:
        assert ok(a.get_native_api(operation))['signature']
    assert a.create_native_element('__import__', {})['status'] == 'error'
    ok(a.create_asymmetric_sgen(2, [1, 2, 3], 0, [0.001] * 3, [0.] * 3))
    ok(a.update_network_rows([{'table': 'asymmetric_sgen', 'selector': {'index': 0}, 'values': {'sn_mva': 0.01}}]))
    ok(a.configure_volt_var(0, [0.95, 0.99, 1.01, 1.05], [0.4, 0., 0., -0.4]))
    assert ok(a.run_power_flow(run_control=True))['results']['converged']


def test_stdio_client_from_unrelated_cwd(tmp_path):
    from mcp import ClientSession, StdioServerParameters
    from mcp.client.stdio import stdio_client

    async def exercise():
        params = StdioServerParameters(command=sys.executable, args=[str(Path(a.__file__).resolve())], cwd=str(tmp_path))
        async with stdio_client(params) as (read, write):
            async with ClientSession(read, write) as session:
                await session.initialize()
                tools = {t.name for t in (await session.list_tools()).tools}
                assert all(t in tools for names in a.PLUGIN_TOOLS.values() for t in names)
                for name, arguments in [('create_demo_network', {}), ('run_power_flow', {}), ('run_diagnostics', {})]:
                    result = await session.call_tool(name, arguments)
                    assert not result.isError, result
                    payload = result.structuredContent or json.loads(result.content[0].text)
                    ok(payload.get('result', payload))
    asyncio.run(exercise())


def test_cold_estimation_and_failed_step_retention():
    assert a.run_state_estimation()['status'] == 'error'  # no measurements
    result = ok(a.run_time_series(
        [{'TIME_STEP': 0, 'demand': 1.0}, {'TIME_STEP': 1, 'demand': 1e6}, {'TIME_STEP': 2, 'demand': 1.0}],
        [{'table': 'asymmetric_load', 'variable': 'scaling', 'profile': 'demand', 'mode': 'absolute'}],
    ))
    states = frame(result['statuses']).STATUS.tolist()
    assert states[0] == states[2] == 'converged'
    assert states[1] != 'converged'


@pytest.mark.parametrize('operation,settings', [
    ('create_dtoc', {'pickup_ka': 0.2, 'delay_s': 0.1}),
    ('create_idmt', {'pickup_ka': 0.2, 'time_multiplier_s': 0.1}),
    ('create_idtoc', {'pickup_ka': 0.2, 'time_multiplier_s': 0.1, 'definite_pickup_ka': 0.4, 'definite_delay_s': 0.05}),
    ('create_fuse', {'rated_i_a': 100.}),
])
def test_protection_device_roundtrip(operation, settings, tmp_path):
    finite_source()
    sid = ok(a.create_switch(bus=1, phase=[1, 2, 3], element=0, et='l'))['index']
    ok(a.create_native_element(operation, {'switch_index': sid, **settings}))
    path = str(tmp_path / 'devices.pkl')
    ok(a.save_network(path))
    ok(a.load_network(path, trusted_pickle=True))
    timing = frame(ok(a.run_protection_coordination({'fault': 'LG', 'bus': 2, 'phases': [1]}))['timing'])
    assert len(timing) == 1 and timing.trip.all()


def test_legacy_creation_invalidation_and_rollback():
    ok(a.run_power_flow())
    ok(a.create_asymmetric_load(2, [1, 2, 3], 0, [0.001] * 3, [0.] * 3))
    assert not a.analysis.is_solved(a._current_net)
    previous = a._current_net.trafo1ph.copy(deep=True)
    ok(a.create_transformer_3ph(0, 1, '0.63 MVA 20/0.4 kV'))
    assert len(a._current_net.trafo1ph) == len(previous) * 2
    bus_before = a._current_net.bus.copy(deep=True)
    assert a.create_bus(0.4, index=0)['status'] == 'error'
    pd.testing.assert_frame_equal(a._current_net.bus, bus_before)
    assert a.run_diagnostics('unknown')['status'] == 'error'
    assert len(frame(ok(a.run_diagnostics('topology'))['results']['summary'])) > 0


def test_cold_estimator_recovers_synthetic_voltages():
    from copy import deepcopy
    truth_net = deepcopy(a._current_net)
    a.mc.run_pf(truth_net)
    for (bus, phase), row in truth_net.res_bus.iterrows():
        if truth_net.bus.at[(bus, phase), 'grounded'] or not np.isfinite(row.vm_pu):
            continue
        voltage = row.vm_pu * np.exp(1j * np.deg2rad(row.va_degree))
        for kind, value in [('vr', voltage.real), ('vi', voltage.imag)]:
            ok(a.create_native_element('create_state_measurement', dict(
                measurement_type=kind, element_type='bus', element=int(bus),
                value=float(value), std_dev=5e-4, phase=int(phase))))
    assert not a.analysis.is_solved(a._current_net)
    result = ok(a.run_state_estimation())['results']
    assert result['converged']
    voltage = np.array([complex(v['real'], v['imag']) for v in result['voltage']])
    assert np.max(np.abs(voltage - truth_net.model.E.reshape(-1))) < 1e-7
