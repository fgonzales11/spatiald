"""Transport-independent native tools with isolated, explicitly bound network sessions."""
from typing import Dict, List, Optional, Any, Union
from pathlib import Path
from copy import deepcopy
from contextvars import ContextVar
from dataclasses import fields, is_dataclass
from functools import wraps
from threading import RLock
from tempfile import TemporaryDirectory
from enum import Enum
import inspect
import json
import logging
import pickle
import numpy as np
import pandas as pd
import multiconductor as mc
import multiconductor.create as mc_create
from pydantic import ConfigDict, create_model
from multiconductor.addons.mcp import network_analysis as analysis

ROOT = Path(__file__).resolve().parents[3]
logger = logging.getLogger(__name__)
TOOLS = {}
SCHEMAS = {}
VALIDATORS = {}
MUTATIONS = {'create_bus', 'create_line', 'create_switch', 'create_transformer_3ph',
    'create_asymmetric_load', 'create_asymmetric_sgen', 'create_ext_grid',
    'create_native_element', 'configure_volt_var', 'update_network_rows'}
ELECTRICAL_CREATION = MUTATIONS - {'create_native_element', 'configure_volt_var', 'update_network_rows'}

class NetworkSession:
    """No web session ever borrows another session's model or equivalent."""
    def __init__(self, net=None, max_cases=None):
        self.net = net
        self.max_cases = max_cases
        self.equivalent = None
        self.lock = RLock()

    def call(self, name, arguments=None):
        if name not in TOOLS:
            raise ValueError('Unknown tool')
        token = _active.set(self)
        try:
            return TOOLS[name](**(arguments or {}))
        finally:
            _active.reset(token)

DEFAULT_SESSION = NetworkSession()
_active = ContextVar('mc_network_session', default=None)

def _state():
    return _active.get() or DEFAULT_SESSION

def tool(fn):
    parameters = inspect.signature(fn).parameters
    validator = create_model(fn.__name__ + 'Arguments', __config__=ConfigDict(extra='forbid'),
        **{name: (p.annotation, ... if p.default is inspect.Parameter.empty else p.default)
           for name, p in parameters.items()})
    VALIDATORS[fn.__name__] = validator
    SCHEMAS[fn.__name__] = validator.model_json_schema()
    @wraps(fn)
    def guarded(*args, **kwargs):
        session = _state()
        with session.lock:
            mutating = fn.__name__ in MUTATIONS
            saved = deepcopy(session.net) if mutating and session.net is not None else None
            try:
                bound = inspect.signature(fn).bind(*args, **kwargs)
                values = validator.model_validate(bound.arguments).model_dump()
                result = fn(**values)
                if mutating and result.get('status') == 'error':
                    session.net = saved
                elif fn.__name__ in ELECTRICAL_CREATION:
                    _invalidate(session.net)
                if mutating and result.get('status') != 'error':
                    session.equivalent = None
                return _clean_data(result)
            except Exception as exc:
                if mutating:
                    session.net = saved
                logger.info('Native tool %s failed (%s)', fn.__name__, type(exc).__name__)
                return {'status': 'error', 'error_type': type(exc).__name__, 'message': str(exc)}
    TOOLS[fn.__name__] = guarded
    return guarded

def _get_network():
    if _state().net is None:
        raise RuntimeError("No multiconductor network loaded; create or load one first.")
    return _state().net


def _clean_data(obj):
    """Lossless index/column structure and JSON-safe numeric values."""
    if isinstance(obj, pd.DataFrame):
        return {"index_names": list(obj.index.names),
                "column_names": list(obj.columns.names),
                "index": _clean_data(obj.index.tolist()),
                "columns": _clean_data(obj.columns.tolist()),
                "data": _clean_data(obj.to_numpy().tolist())}
    if isinstance(obj, pd.Series):
        return _clean_data(obj.to_frame())
    if is_dataclass(obj) and not isinstance(obj, type):
        return {f.name: _clean_data(getattr(obj, f.name)) for f in fields(obj)}
    if isinstance(obj, Enum):
        return _clean_data(obj.value)
    if isinstance(obj, dict):
        return {str(k): _clean_data(v) for k, v in obj.items()}
    if isinstance(obj, (list, tuple, set, pd.Index, np.ndarray)):
        return [_clean_data(v) for v in list(obj)]
    if isinstance(obj, np.generic):
        return _clean_data(obj.item())
    if isinstance(obj, complex):
        return {"real": _clean_data(obj.real), "imag": _clean_data(obj.imag)}
    if isinstance(obj, float):
        return obj if np.isfinite(obj) else None
    if obj is None or obj is pd.NA or obj is pd.NaT:
        return None
    if isinstance(obj, (str, int, bool)):
        return obj
    if isinstance(obj, (Path, pd.Timestamp)):
        return str(obj)
    # Controller objects can occur in model tables; never serialize their net.
    return {"object_type": type(obj).__name__}



def _ok(**values):
    return {"status": "success", **values}


def _invalidate(net):
    net.pop("model", None)
    for key in list(net):
        if key.startswith("res_") and isinstance(net[key], pd.DataFrame):
            net[key] = net[key].iloc[:0].copy()
    net["converged"] = False
    net["OPF_converged"] = False


@tool
def create_empty_network(name: str = "", sn_mva: float = 1.0,
                         rho_ohmm: float = 100.0, f_hz: float = 50.0) -> Dict[str, Any]:
    """Replace the active network with a native empty MC network."""
    _state().net = mc.create_empty_network(name=name, sn_mva=sn_mva, rho_ohmm=rho_ohmm, f_hz=f_hz)
    _state().equivalent = None
    return _ok(network_info=analysis.summarize_network(_state().net))


@tool
def create_demo_network() -> Dict[str, Any]:
    """Load an illustrative unbalanced 3-bus feeder for smoke tests, not engineering assumptions."""
    _state().net = analysis.create_demo_network()
    _state().equivalent = None
    return _ok(network_info=analysis.summarize_network(_state().net))


@tool
def load_network(file_path: str, trusted_pickle: bool = False) -> Dict[str, Any]:
    """Load MC .xlsx, or explicitly trusted .p/.pkl. Pickle can execute code;
    set trusted_pickle only for a controlled file whose provenance is known.
    Failed loads preserve the active network.
    """
    path = Path(file_path).expanduser().resolve()
    if path.suffix.lower() == ".xlsx":
        net = mc.from_excel(str(path))
    elif path.suffix.lower() in {".p", ".pkl"} and trusted_pickle:
        from multiconductor.file_io import from_pickle
        net = from_pickle(str(path))
    else:
        raise ValueError("Use .xlsx; .p/.pkl require trusted_pickle=True for a controlled file")
    analysis._validate_network(net)
    _state().net, _state().equivalent = net, None
    return _ok(network_info=analysis.summarize_network(net), file_path=str(path))


@tool
def save_network(file_path: str) -> Dict[str, Any]:
    """Save active MC network to .p/.pkl. Reload only as a trusted pickle."""
    net = _get_network()
    path = Path(file_path).expanduser().resolve()
    if path.suffix.lower() not in {".p", ".pkl"}:
        raise ValueError("Save requires .p or .pkl")
    path.parent.mkdir(parents=True, exist_ok=True)
    with path.open("wb") as handle:
        pickle.dump(net, handle, protocol=pickle.HIGHEST_PROTOCOL)
    return _ok(file_path=str(path))


@tool
def get_network_info() -> Dict[str, Any]:
    """Summarize physical IDs separately from phase/circuit rows and list available tables."""
    net = _get_network()
    return _ok(info=analysis.summarize_network(net), tables={
        k: {"rows": len(v), "index_names": list(v.index.names), "columns": list(v.columns)}
        for k, v in net.items() if isinstance(v, pd.DataFrame)})


@tool
def inspect_table(table: str, offset: int = 0, limit: int = 100) -> Dict[str, Any]:
    """Read an input or result table with explicit index arrays; pagination never drops index identity."""
    frame = _get_network().get(table)
    if not isinstance(frame, pd.DataFrame):
        raise ValueError("Unknown network table")
    if offset < 0 or not 1 <= limit <= 10000:
        raise ValueError("Require offset >= 0 and 1 <= limit <= 10000")
    return _ok(total_rows=len(frame), table=frame.iloc[offset:offset + limit])


@tool
def get_std_types(category: Optional[str] = None) -> Dict[str, Any]:
    """Read native standard types, optionally by category."""
    types = _get_network().std_types
    return _ok(std_types=types if category is None else types[category])


@tool
def run_power_flow(max_iteration: int = 100, tol_vmag_pu: float = 1e-6,
                   tol_vang_rad: float = 1e-6, runControls: bool = False,
                   run_control: Optional[bool] = None,
                   v_min: float = 0.95, v_max: float = 1.05,
                   loading_limit: float = 100.0) -> Dict[str, Any]:
    """Solve active MC network with MaxIter/run_control and model.solved.
    Returns phase voltages, circuit/winding loading, losses and missing coverage.
    Limits are user-overridable screening assumptions. runControls is a legacy alias.
    """
    if max_iteration < 1 or not np.isfinite([tol_vmag_pu, tol_vang_rad]).all() or min(tol_vmag_pu, tol_vang_rad) <= 0:
        raise ValueError("Iterations and tolerances must be positive and finite")
    net = _get_network()
    _invalidate(net)
    mc.run_pf(net, MaxIter=max_iteration, tol_vmag_pu=tol_vmag_pu,
              tol_vang_rad=tol_vang_rad, run_control=runControls if run_control is None else run_control)
    return _ok(results={"converged": analysis.is_solved(net),
        "bus_results": net.res_bus, "line_results": net.res_line,
        "trafo_results": net.res_trafo,
        "violations": analysis.check_violations(net, v_min, v_max, loading_limit),
        "losses": analysis.calculate_losses(net)})


@tool
def create_bus(vn_kv: float, num_phases: int = 4, name: Optional[str] = None,
               grounded_phases: Optional[List[int]] = None, grounding_r_ohm: float = 0.0,
               grounding_x_ohm: float = 0.0, in_service: bool = True,
               type: str = "b", zone: Optional[str] = None, index: Optional[int] = None) -> Dict[str, Any]:
    """Create a bus in the current network.

    Args:
        vn_kv: Rated voltage in kV
        num_phases: Number of phases (e.g. 4)
        name: Name of the bus
        grounded_phases: Indices of phases that are grounded (e.g. [0])
        grounding_r_ohm: Resistance of the grounding connection (Ohm)
        grounding_x_ohm: Reactance of the grounding connection (Ohm)
        in_service: Whether the bus is standard in service
        type: Bus type ("b" for busbar, etc.)
        zone: Bus zone (optional)
        index: Index of the bus (optional)
    """
    logger.info(f"Creating bus: {name} (Vn={vn_kv} kV)")
    try:
        net = _get_network()
        cls_grounded = tuple(grounded_phases) if grounded_phases is not None else (0,)

        bus_idx = mc_create.create_bus(
            net, vn_kv=vn_kv, num_phases=num_phases, name=name,
            grounded_phases=cls_grounded, grounding_r_ohm=grounding_r_ohm,
            grounding_x_ohm=grounding_x_ohm, in_service=in_service,
            type=type, zone=zone, index=index
        )
        return {
            "status": "success",
            "message": "Bus created successfully",
            "index": int(bus_idx)
        }
    except Exception as e:
        return {
            "status": "error",
            "message": f"Failed to create bus: {str(e)}"
        }


@tool
def create_line(std_type: str, model_type: str, from_bus: int, from_phase: Union[int, List[int]],
                to_bus: int, to_phase: Union[int, List[int]], length_km: float,
                name: Optional[str] = None, in_service: bool = True, index: Optional[int] = None) -> Dict[str, Any]:
    """Create a line in the current network.

    Args:
        std_type: Standard line type name
        model_type: Model type selection ('configuration', 'matrix', 'sequence')
        from_bus: Index of sending bus
        from_phase: Phase identifier(s) at sending bus (single integer or list of integers)
        to_bus: Index of receiving bus
        to_phase: Phase identifier(s) at receiving bus (single integer or list of integers)
        length_km: Line length in km
        name: Name of the line (optional)
        in_service: True if the line is in service (default True)
        index: Index of the line (optional)
    """
    logger.info(f"Creating line: {name} (length={length_km} km)")
    try:
        net = _get_network()

        line_idx = mc_create.create_line(
            net, std_type=std_type, model_type=model_type,
            from_bus=from_bus, from_phase=from_phase,
            to_bus=to_bus, to_phase=to_phase,
            length_km=length_km, name=name,
            in_service=in_service, index=index
        )
        return {
            "status": "success",
            "message": "Line created successfully",
            "index": int(line_idx)
        }
    except Exception as e:
        return {
            "status": "error",
            "message": f"Failed to create line: {str(e)}"
        }


@tool
def create_switch(bus: int, phase: Union[int, List[int]], element: int, et: str,
                  type: Optional[str] = None, closed: bool = True, name: Optional[str] = None,
                  r_ohm: float = 0.0, index: Optional[int] = None) -> Dict[str, Any]:
    """Create a switch in the current network.

    Args:
        bus: Connected bus index
        phase: Connected phase identifier(s) (single integer or list of integers)
        element: Index of the element (bus ID if et=='b', line ID if et=='l', trafo ID if et=='t')
        et: Element type: 'l' (line), 't' (transformer), 'b' (bus)
        type: Switch type (optional: 'LS', 'CB', 'LBS', 'DS')
        closed: Initial state (default True)
        name: Name of the switch (optional)
        r_ohm: Internal resistance of switch in Ohms (default 0.0)
        index: Index of the switch (optional)
    """
    logger.info(f"Creating switch: {name}")
    try:
        net = _get_network()

        switch_idx = mc_create.create_switch(
            net, bus=bus, phase=phase, element=element, et=et,
            type=type, closed=closed, name=name, r_ohm=r_ohm, index=index
        )
        return {
            "status": "success",
            "message": "Switch created successfully",
            "index": int(switch_idx)
        }
    except Exception as e:
        return {
            "status": "error",
            "message": f"Failed to create switch: {str(e)}"
        }


@tool
def create_transformer_3ph(hv_bus: int, lv_bus: int, std_type: str,
                           tap_pos: Optional[float] = None, name: str = "tr",
                           in_service: bool = True, index: Optional[int] = None,
                           shift_degree: int = 0) -> Dict[str, Any]:
    """Create a three-phase transformer.

    Args:
        hv_bus: High-voltage bus index
        lv_bus: Low-voltage bus index
        std_type: Standard transformer type
        tap_pos: Initial tap position (optional)
        name: Transformer name (default 'tr')
        in_service: Whether active (default True)
        index: Index of transformer (optional)
        shift_degree: Voltage angle shift degree (default 0)
    """
    logger.info(f"Creating transformer: {name} (type={std_type})")
    try:
        net = _get_network()
        t_pos = tap_pos if tap_pos is not None else np.nan

        trafo_idx = mc_create.create_transformer_3ph(
            net, hv_bus=hv_bus, lv_bus=lv_bus, std_type=std_type,
            tap_pos=t_pos, name=name, in_service=in_service,
            index=index, shift_degree=shift_degree
        )
        return {
            "status": "success",
            "message": "Transformer created successfully",
            "index": int(trafo_idx) if trafo_idx is not None else int(net.trafo1ph.index.get_level_values(0).max())
        }
    except Exception as e:
        return {
            "status": "error",
            "message": f"Failed to create transformer: {str(e)}"
        }


@tool
def create_asymmetric_load(bus: int, from_phase: Union[int, List[int]], to_phase: Union[int, List[int]],
                           p_mw: Union[float, List[float]], q_mvar: Union[float, List[float]], const_z_percent_p: float = 0.0,
                           const_i_percent_p: float = 0.0, const_z_percent_q: float = 0.0,
                           const_i_percent_q: float = 0.0, scaling: float = 1.0,
                           in_service: bool = True, name: Optional[str] = None,
                           type: Optional[str] = None, index: Optional[int] = None) -> Dict[str, Any]:
    """Create an asymmetric load in the current network.

    Args:
        bus: Connected bus index
        from_phase: Phase identifier(s) at sending side (int or list of ints)
        to_phase: Phase identifier(s) at receiving side (int or list of ints)
        p_mw: Active power in MW
        q_mvar: Reactive power in MVAr
        const_z_percent_p: Active power constant impedance percent share (default 0.0)
        const_i_percent_p: Active power constant current percent share (default 0.0)
        const_z_percent_q: Reactive power constant impedance percent share (default 0.0)
        const_i_percent_q: Reactive power constant current percent share (default 0.0)
        scaling: Scaling factor for active and reactive power (default 1.0)
        in_service: Whether load is in service (default True)
        name: Name of load (optional)
        type: Load type classification (optional)
        index: Index of the load (optional)
    """
    logger.info(f"Creating asymmetric load at bus: {bus}")
    try:
        net = _get_network()

        load_idx = mc_create.create_asymmetric_load(
            net, bus=bus, from_phase=from_phase, to_phase=to_phase,
            p_mw=p_mw, q_mvar=q_mvar, const_z_percent_p=const_z_percent_p,
            const_i_percent_p=const_i_percent_p, const_z_percent_q=const_z_percent_q,
            const_i_percent_q=const_i_percent_q, scaling=scaling,
            in_service=in_service, name=name, type=type, index=index
        )
        return {
            "status": "success",
            "message": "Asymmetric load created successfully",
            "index": int(load_idx)
        }
    except Exception as e:
        return {
            "status": "error",
            "message": f"Failed to create asymmetric load: {str(e)}"
        }


@tool
def create_asymmetric_sgen(bus: int, from_phase: Union[int, List[int]], to_phase: Union[int, List[int]],
                            p_mw: Union[float, List[float]], q_mvar: Union[float, List[float]], const_z_percent_p: float = 0.0,
                            const_i_percent_p: float = 0.0, const_z_percent_q: float = 0.0,
                            const_i_percent_q: float = 0.0, scaling: float = 1.0,
                            in_service: bool = True, name: Optional[str] = None,
                            type: Optional[str] = None, index: Optional[int] = None) -> Dict[str, Any]:
    """Make asymmetric static generator (e.g. solar, wind, battery) in the current network.

    Args:
        bus: Connected bus index
        from_phase: Phase identifier(s) at sending side (int or list of ints)
        to_phase: Phase identifier(s) at receiving side (int or list of ints)
        p_mw: Produced active power in MW
        q_mvar: Produced reactive power in MVAr
        const_z_percent_p: Active power constant impedance percent share (default 0.0)
        const_i_percent_p: Active power constant current percent share (default 0.0)
        const_z_percent_q: Reactive power constant impedance percent share (default 0.0)
        const_i_percent_q: Reactive power constant current percent share (default 0.0)
        scaling: Scaling factor (default 1.0)
        in_service: Whether in service (default True)
        name: Name of static generator (optional)
        type: Generator type (optional)
        index: Index of the static generator (optional)
    """
    logger.info(f"Creating asymmetric static generator at bus: {bus}")
    try:
        net = _get_network()

        sgen_idx = mc_create.create_asymmetric_sgen(
            net, bus=bus, from_phase=from_phase, to_phase=to_phase,
            p_mw=p_mw, q_mvar=q_mvar, const_z_percent_p=const_z_percent_p,
            const_i_percent_p=const_i_percent_p, const_z_percent_q=const_z_percent_q,
            const_i_percent_q=const_i_percent_q, scaling=scaling,
            in_service=in_service, name=name, type=type, index=index
        )
        return {
            "status": "success",
            "message": "Asymmetric static generator created successfully",
            "index": int(sgen_idx)
        }
    except Exception as e:
        return {
            "status": "error",
            "message": f"Failed to create asymmetric static generator: {str(e)}"
        }


@tool
def create_ext_grid(bus: int, from_phase: Union[int, List[int]], to_phase: Union[int, List[int]],
                    vm_pu: Union[float, List[float]], va_degree: Union[float, List[float]], r_ohm: float, x_ohm: float,
                    name: Optional[str] = None, in_service: bool = True,
                    index: Optional[int] = None) -> Dict[str, Any]:
    """Create an external grid connection representing an upstream slack bus.

    Args:
        bus: Connected bus index
        from_phase: Phase identifier(s) at sending side (int or list of ints)
        to_phase: Phase identifier(s) at receiving side (int or list of ints)
        vm_pu: Voltage set point in per-unit
        va_degree: Voltage angle degree
        r_ohm: Internal grid resistance in Ohms
        x_ohm: Internal grid reactance in Ohms
        name: Name of external grid (optional)
        in_service: Whether in service (default True)
        index: Index of the external grid (optional)
    """
    logger.info(f"Creating external grid at bus: {bus}")
    try:
        net = _get_network()

        ext_idx = mc_create.create_ext_grid(
            net, bus=bus, from_phase=from_phase, to_phase=to_phase,
            vm_pu=vm_pu, va_degree=va_degree, r_ohm=r_ohm, x_ohm=x_ohm,
            name=name, in_service=in_service, index=index
        )
        return {
            "status": "success",
            "message": "External grid created successfully",
            "index": int(ext_idx)
        }
    except Exception as e:
        return {
            "status": "error",
            "message": f"Failed to create external grid: {str(e)}"
        }


# Explicit allowlist covers modeling, measurement/cost/device configuration,
# and native controllers without exposing eval, imports or arbitrary callables.
def _operations():
    from multiconductor import opf, protection
    from multiconductor.pycci.state_estimator import create_state_measurement
    from multiconductor.pycci.std_types import create_std_type
    from multiconductor.control.load_tap_changer_control import add_load_tap_changer_control
    return {
        **{n: getattr(mc_create, n) for n in (
            'create_bus', 'create_line', 'create_switch', 'create_transformer_3ph',
            'create_transformer3w', 'create_transformer1ph', 'create_transformer1ph_from_std_type',
            'create_asymmetric_load', 'create_asymmetric_sgen', 'create_asymmetric_gen',
            'create_ext_grid', 'create_ext_grid_sequence', 'create_asymmetric_shunt')},
        'create_std_type': create_std_type,
        'create_state_measurement': create_state_measurement,
        'create_poly_cost': opf.create_poly_cost,
        'create_pwl_cost': opf.create_pwl_cost,
        'create_fuse': protection.create_fuse,
        'create_dtoc': protection.create_dtoc,
        'create_idmt': protection.create_idmt,
        'create_idtoc': protection.create_idtoc,
        'add_load_tap_changer_control': add_load_tap_changer_control,
    }


PLUGIN_TOOLS = {
    'multiconductor': ['run_power_flow', 'get_network_info', 'run_contingency_analysis'],
    'multiconductor-modeling': ['create_native_element', 'get_native_api', 'update_network_rows'],
    'multiconductor-diagnostics': ['run_diagnostics'],
    'multiconductor-contingency-analysis': ['run_contingency_analysis'],
    'multiconductor-time-series': ['run_time_series'],
    'multiconductor-state-estimation': ['create_native_element', 'run_state_estimation'],
    'multiconductor-grid-equivalents': ['create_grid_equivalent', 'solve_grid_equivalent'],
    'multiconductor-optimal-power-flow': ['create_native_element', 'run_optimal_power_flow'],
    'multiconductor-short-circuit': ['run_short_circuit'],
    'multiconductor-protection-coordination': ['create_native_element', 'run_protection_coordination'],
    'convergence-failure-mitigation': ['run_diagnostics', 'compare_scenarios', 'run_power_flow'],
    'voltage-violation-mitigation': ['compare_scenarios', 'configure_volt_var', 'create_native_element'],
    'thermal-overload-mitigation': ['compare_scenarios', 'run_contingency_analysis', 'run_optimal_power_flow'],
    'der-hosting-capacity-mitigation': ['compare_scenarios', 'run_time_series', 'configure_volt_var', 'run_optimal_power_flow'],
}


@tool
def get_capabilities() -> Dict[str, Any]:
    """Discover all supported installed multiconductor plugin workflows and configuration operations."""
    return _ok(plugins=PLUGIN_TOOLS, native_operations=list(_operations()),
        source_root=str(ROOT), state_scope='explicit isolated NetworkSession; one default session for stdio',
        table_encoding='index_names, index arrays, columns, data; complex values use real/imag',
        limitations=[
            'Native OPF and contingency ratings differ from snapshot effective ratings; verify currents independently.',
            'A tool status of success means execution completed; inspect native convergence/status and missing coverage.',
            'Protection is steady-state timing/topology, not transient breaker simulation.',
            'Hosting capacity requires an explicit scenario set and tested capacity bracket.',
            'asymmetric_gen snapshot PV control is not implemented; validate PQ sgen replay.',
        ])


@tool
def get_native_api(operation: str) -> Dict[str, Any]:
    """Get exact native parameter names, defaults and documentation before configuring an element."""
    fn = _operations()[operation]
    from multiconductor import protection
    constructors = {'create_dtoc': protection.DTOC, 'create_idmt': protection.IDMT,
                    'create_idtoc': protection.IDTOC, 'create_fuse': protection.Fuse}
    contract = constructors.get(operation, fn)
    return _ok(operation=operation, signature=str(inspect.signature(contract)), documentation=inspect.getdoc(contract))


@tool
def create_native_element(operation: str, parameters: Dict[str, Any]) -> Dict[str, Any]:
    """Call an allowlisted native creation API on active network. Use get_native_api first.
    parameters excludes net; JSON arrays express phase-specific vectors.
    """
    fn = _operations()[operation]
    if 'net' in parameters or 'mc_net' in parameters:
        raise ValueError('The network is supplied by the server')
    result = fn(_get_network(), **parameters)
    if operation not in {'create_state_measurement', 'create_poly_cost', 'create_pwl_cost'}:
        _invalidate(_get_network())
    return _ok(operation=operation, result=result)


EDITABLE = {'bus', 'line', 'trafo1ph', 'switch', 'asymmetric_load', 'asymmetric_sgen',
            'asymmetric_gen', 'asymmetric_shunt', 'ext_grid', 'ext_grid_sequence'}


def _apply_updates(net, updates):
    for change in updates:
        name, selector, values = change['table'], change['selector'], change['values']
        if name not in EDITABLE or not selector or not values:
            raise ValueError('Use an editable input table, nonempty selector and values')
        table = net[name]
        mask = np.ones(len(table), dtype=bool)
        for level, value in selector.items():
            if level not in table.index.names:
                raise ValueError(f'{name} has no index level {level!r}')
            mask &= table.index.get_level_values(level) == value
        if not mask.any():
            raise ValueError(f'No rows match {name}: {selector}')
        for column, value in values.items():
            if column in {'object', 'index', 'circuit', 'phase'} or column.startswith('_'):
                raise ValueError(f'Cannot edit {column}')
            if isinstance(value, (list, dict)):
                raise ValueError('Set one scalar per selected row; use separate updates for per-phase values')
            table.loc[mask, column] = value
    _invalidate(net)


@tool
def update_network_rows(updates: List[Dict[str, Any]]) -> Dict[str, Any]:
    """Atomically edit selected native input rows. Each update is
    {table, selector: {index: physical_id, circuit: optional_id, bus: optional_id},
    values: {column: scalar}}. Bus selectors use phase. Omitted levels select
    all rows of that physical ID; nonexistent levels/empty matches are rejected.
    New columns permit OPF bounds and equipment ratings. Invalidates prior results.
    """
    candidate = deepcopy(_get_network())
    _apply_updates(candidate, updates)
    _state().net = candidate
    return _ok(updated=len(updates))


@tool
def run_diagnostics(categories: Union[str, List[str]] = 'all', strict: bool = True) -> Dict[str, Any]:
    """Run native structural diagnostics, preserving issues, recommendations and execution errors."""
    from multiconductor.tools.diagnostics import run_diagnostics as run, _ALL_CATEGORIES
    if isinstance(categories, str) and categories != 'all':
        categories = [categories]
    if categories != 'all' and (not categories or set(categories) - set(_ALL_CATEGORIES)):
        raise ValueError(f'Choose diagnostic categories from {list(_ALL_CATEGORIES)}')
    return _ok(results=run(deepcopy(_get_network()), categories=categories, strict=strict))


@tool
def compare_scenarios(scenarios: List[Dict[str, Any]], run_control: bool = False,
                      v_min: float = 0.95, v_max: float = 1.05,
                      loading_limit: float = 100.0) -> Dict[str, Any]:
    """Compare baseline and independent mitigation/DER candidates via native PF.
    Each scenario: {name, updates: [update_network_rows objects]}. Changes never
    accumulate. Retains failed cases and missing ratings/results; does not infer
    hosting capacity beyond the supplied scenarios. Scaling uses original baseline.
    """
    original = _get_network()
    results = []
    for scenario in [{'name': 'baseline', 'updates': []}] + scenarios:
        try:
            candidate = deepcopy(original)
            _apply_updates(candidate, scenario.get('updates', []))
            result = analysis.analyze_network(candidate, v_min, v_max, loading_limit, run_control=run_control)
            results.append({'name': scenario['name'], 'results': result})
        except Exception as exc:
            results.append({'name': scenario.get('name'), 'status': 'error', 'message': str(exc)})
    return _ok(scenarios=results)


@tool
def run_contingency_analysis(cases: Optional[List[Dict[str, Any]]] = None,
                             elements: Optional[List[str]] = None,
                             run_control: bool = False, v_min: float = 0.95,
                             v_max: float = 1.05, loading_limit: float = 100.0) -> Dict[str, Any]:
    """Native N-1 (active physical IDs only) or explicit {case_id, actions} cases.
    Actions use table,index,optional circuit/bus,column,value. Establishes base PF,
    preserves failed/islanded cases and supplied-load evidence. Native contingency
    ratings use standard types, not full PF row/df/parallel effective-rating policy.
    """
    from multiconductor.contingency import generate_nminus1_cases, run_contingency
    net = deepcopy(_get_network())
    base = analysis.analyze_network(net, v_min, v_max, loading_limit, run_control=run_control)
    if not base['converged']:
        return {'status': 'error', 'message': 'Base case failed', 'base': base}
    if cases is None:
        generated = generate_nminus1_cases(net, element_types=elements or ['line', 'trafo1ph'])
        cases = [case for case in generated if all(
            bool(net[a.table].loc[net[a.table].index.get_level_values(0) == a.index, 'in_service'].any())
            for a in case.actions)]
    else:
        for case in cases:
            for action in case['actions']:
                table = net[action['table']]
                for level in ('circuit', 'bus'):
                    if action.get(level) is not None and level not in table.index.names:
                        raise ValueError(f"{action['table']} has no {level} index level")
    if _state().max_cases is not None and len(cases) > _state().max_cases:
        raise ValueError(f'This session permits at most {_state().max_cases} contingency cases. Select explicit cases.')
    result = run_contingency(net, cases=cases, run_control=run_control,
        continue_on_failure=True, write_to_net=False, min_vm_pu=v_min,
        max_vm_pu=v_max, max_loading_percent=loading_limit)
    return _ok(base=base, results=result)


@tool
def run_time_series(profiles: List[Dict[str, Any]], bindings: List[Dict[str, Any]],
                    result_specs: Optional[List[Dict[str, Any]]] = None,
                    run_control: bool = False, failure_policy: str = 'record_and_continue',
                    output_path: Optional[str] = None) -> Dict[str, Any]:
    """Run quasi-static profiles on a copy. profiles are rows {TIME_STEP, profile:value}.
    Bindings: {table,variable,profile,element?,phase?,circuit?,mode:absolute|scale|delta}.
    Supply P and Q bindings to preserve intended relationships. Returns every step's
    status and indexed long-form results. Does not model storage energy or transients.
    """
    from multiconductor.timeseries import DFData, ProfileBinding, ResultSpec, run_timeseries
    specs = result_specs or [{'table': 'res_bus', 'column': 'vm_pu'},
        {'table': 'res_line', 'column': 'loading_percent'}, {'table': 'res_trafo', 'column': 'loading_percent'}]
    with TemporaryDirectory(prefix='mc-timeseries-') as temporary:
        destination = str(Path(output_path).expanduser().resolve()) if output_path else str(Path(temporary) / 'results.csv')
        writer = run_timeseries(deepcopy(_get_network()), DFData(pd.DataFrame(profiles)),
            bindings=[ProfileBinding(**b) for b in bindings],
            result_specs=[ResultSpec(**s) for s in specs], run_control=run_control,
            auto_fix=False, verbose=False, failure_policy=failure_policy, output_path=destination)
        return _ok(statuses=writer.status_frame, results=writer.result_frame,
                   output_path=destination if output_path else None)



@tool
def run_state_estimation(options: Optional[Dict[str, Any]] = None) -> Dict[str, Any]:
    """Estimate from native phase-aware measurement table on a copy. Configure with
    create_native_element/create_state_measurement. Retains observability/residuals;
    does not replace PF results or disable observability checks.
    """
    from multiconductor.pycci.state_estimator import estimate, extract_se_matrices
    net = deepcopy(_get_network())
    settings = dict(options or {})
    model = extract_se_matrices(net, rebuild=settings.pop('rebuild_model', False))
    if 'E' not in net.model:
        # Native result extraction expects a voltage slot even on a cold model.
        net.model.E = model.initial_voltage.reshape(-1, 1).copy()
    return _ok(results=estimate(net, **settings))


@tool
def run_optimal_power_flow(init: str = 'pf', solver_options: Optional[Dict[str, Any]] = None) -> Dict[str, Any]:
    """Continuous native AC OPF on a copy. Configure finite bounds and polynomial/PWL
    costs first. Returns dispatch, constraints and optimizer convergence. Replay
    selected PQ dispatch using an independent scenario and verify effective ratings.
    """
    from multiconductor.opf import run_opf
    return _ok(results=run_opf(deepcopy(_get_network()), init=init, solver_options=solver_options))


@tool
def run_short_circuit(fault_spec: Dict[str, Any], branch_results: bool = True) -> Dict[str, Any]:
    """Native phase-domain FaultSpec: fault LLL/LL/LG/LLG, bus OR line+location,
    phases, optional r_fault_ohm,x_fault_ohm,ip,ith,tk_s,case. Requires credible
    finite sequence/source strength. Runs on a copy and returns all SC tables.
    """
    from multiconductor.shortcircuit import FaultSpec, calc_sc
    net = deepcopy(_get_network())
    calc_sc(net, fault_spec=FaultSpec(**fault_spec), branch_results=branch_results)
    return _ok(results={k: v for k, v in net.items() if k.startswith('res_') and k.endswith('_sc')})


@tool
def run_protection_coordination(fault_spec: Dict[str, Any], minimum_margin_s: float = 0.2,
                                trip_switches: bool = False, max_operations: int = 10) -> Dict[str, Any]:
    """Calculate configured native fuse/DTOC/IDMT/IDTOC timing and grading on a copy.
    Optional ordered switch operations affect only that copy. Devices must already
    exist. This is a steady-state approximation, not directional/dynamic validation.
    """
    from multiconductor.shortcircuit import FaultSpec, calc_sc
    from multiconductor.protection import calculate_protection_times, protection_coordination_report, run_protection
    net = deepcopy(_get_network())
    spec = FaultSpec(**fault_spec)
    calc_sc(net, fault_spec=spec, branch_results=True)
    timing = calculate_protection_times(net, scenario='sc')
    grading = protection_coordination_report(net, timing, minimum_margin_s=minimum_margin_s)
    operations = run_protection(net, fault_spec=spec, trip_switches=True,
        ordered=True, max_operations=max_operations) if trip_switches else None
    return _ok(timing=timing, coordination=grading, operations=operations, switches=net.switch)


@tool
def create_grid_equivalent(boundary_buses: List[Any], eq_type: str = 'multiport',
                           internal_buses: Optional[List[int]] = None,
                           external_buses: Optional[List[int]] = None) -> Dict[str, Any]:
    """Create validated terminal equivalent and retain it separately from active net.
    boundary_buses accepts bus IDs or [bus,phase] pairs. Validation stays enabled.
    """
    from multiconductor.grid_equivalents import get_equivalent
    boundary = [tuple(b) if isinstance(b, list) else b for b in boundary_buses]
    result = get_equivalent(_get_network(), eq_type, boundary, internal_buses, external_buses, validate=True)
    _state().equivalent = result
    return _ok(model=result.model)


@tool
def solve_grid_equivalent(boundary_conditions: Optional[Dict[str, Any]] = None) -> Dict[str, Any]:
    """Solve retained equivalent with native boundary conditions (e.g. voltage array
    of complex values encoded as {real,imag}). Does not change the active network.
    """
    if _state().equivalent is None:
        raise ValueError('Create a grid equivalent first')
    result = _state().equivalent.solve(boundary_conditions)
    return _ok(boundary_table=result.boundary_table, residual_max=result.residual_max, model=result.model)


@tool
def configure_volt_var(element: int, vm_points_pu: List[float], q_points_pu: List[float],
                       damping_coef: float = 2.0) -> Dict[str, Any]:
    """Attach native gang Volt-VAR control to an asymmetric_sgen with finite sn_mva.
    Q-curve points are per-unit of sn_mva. Use run_control=True to exercise it.
    """
    from multiconductor.control.volt_var_control import QVCurve, add_volt_var_control
    net = _get_network()
    rows = net.asymmetric_sgen.loc[net.asymmetric_sgen.index.get_level_values(0) == element]
    if rows.empty or 'sn_mva' not in rows or not (np.isfinite(pd.to_numeric(rows.sn_mva)) & (pd.to_numeric(rows.sn_mva) > 0)).all():
        raise ValueError('Generator must exist and have finite positive sn_mva for every circuit')
    if len(vm_points_pu) != len(q_points_pu) or len(vm_points_pu) < 2 or not np.isfinite(vm_points_pu + q_points_pu).all() or not (np.diff(vm_points_pu) > 0).all():
        raise ValueError('Require equal finite curve arrays and increasing voltage points')
    add_volt_var_control(net, element, QVCurve(vm_points_pu, q_points_pu), mode='gang', damping_coef=damping_coef)
    _invalidate(net)
    return _ok(element=element)


def _platform_study(kind, parameters):
    from simulation import validate_parameters, run_study
    net = deepcopy(_get_network())
    params = validate_parameters(kind, parameters or {}, net)
    result = run_study(net, kind, params, lambda *args, **kwargs: None)
    # Never serialize the returned network (controllers can reference it).
    return _ok(analysis=result.analysis, study_status=result.status,
               parameters=params, summary=result.summary,
               tables={name: {'label': label, 'table': frame}
                       for name, label, frame in result.tables})


@tool
def run_hosting_capacity(parameters: Optional[Dict[str, Any]] = None) -> Dict[str, Any]:
    """Sample additional DER capacity using the platform's validated bounded study.
    Parameters and defaults are discoverable with get_study_settings. Returns
    the tested bracket, assumptions, failed evaluations, and monitoring coverage.
    """
    return _platform_study('hosting_capacity', parameters)


@tool
def run_load_allocation(parameters: Optional[Dict[str, Any]] = None) -> Dict[str, Any]:
    """Allocate loads to a signed MW meter target on a private copy, preserving
    locked loads. Discover inputs with get_study_settings; inspect solved residuals.
    """
    return _platform_study('load_allocation', parameters)


@tool
def get_study_settings() -> Dict[str, Any]:
    """Discover platform study fields, valid choices and bounded defaults."""
    from simulation import analysis_catalog
    return _ok(catalog=analysis_catalog(_state().net))

PLUGIN_TOOLS['der-hosting-capacity-mitigation'].append('run_hosting_capacity')
PLUGIN_TOOLS['multiconductor'].extend(['get_study_settings', 'run_load_allocation'])
