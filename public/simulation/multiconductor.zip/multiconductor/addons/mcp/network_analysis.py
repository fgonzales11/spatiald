#!/usr/bin/env python3
"""Bundled base-case checks and demo, adapted from the installed multiconductor skill.

Kept local so the MCP server does not depend on a versioned plugin-cache path.
"""
import json
from pathlib import Path

import numpy as np
import pandas as pd

import multiconductor as mc


def is_solved(net):
    """MC snapshot solves set model.solved, not necessarily net.converged."""
    return bool(net.get("model", {}).get("solved", False))


def _validate_network(net):
    if not isinstance(net.bus.index, pd.MultiIndex):
        raise ValueError("Expected a multiconductor network with bus/phase indices")
    for name in ("line", "trafo1ph", "asymmetric_load", "asymmetric_sgen"):
        if name not in net:
            raise ValueError(f"Missing multiconductor table: {name}")


def _extreme(values, operation):
    finite = values[np.isfinite(values)]
    return float(getattr(finite, operation)()) if len(finite) else None


def line_results(net):
    """Return native conductor-indexed line currents, loading and losses.

    run_pf populates res_line using active circuit IDs and effective ratings
    (row max_i_ka or standard-type rating, multiplied by df and parallel).
    Re-solve after editing inputs or ratings before reading this snapshot.
    """
    columns = ["i_ka", "loading_percent", "pl_mw", "ql_mvar"]
    return net.res_line.reindex(index=net.line.index, columns=columns).copy()


def check_violations(net, v_min=0.95, v_max=1.05, loading_limit=100.0,
                     phases=(1, 2, 3)):
    """Review active ungrounded phases; return full indices and missing results."""
    _validate_network(net)
    if (not np.isfinite([v_min, v_max, loading_limit]).all()
            or not v_min < v_max or loading_limit <= 0):
        raise ValueError("Require finite limits, v_min < v_max and a positive loading_limit")
    if not is_solved(net):
        return {"has_violations": True, "converged": False,
                "error": "Multiconductor power flow has not converged"}
    selected = (net.bus.in_service.astype(bool)
                & ~net.bus.grounded.astype(bool)
                & net.bus.index.get_level_values(1).isin(phases))
    expected = net.bus.index[selected]
    voltage = pd.to_numeric(net.res_bus.vm_pu.reindex(expected), errors="coerce")
    invalid = voltage.index[~np.isfinite(voltage)].tolist()
    under = voltage.index[voltage < v_min].tolist()
    over = voltage.index[voltage > v_max].tolist()
    loading = {}
    incomplete = {"bus_terminals": invalid}
    if not len(expected):
        incomplete["monitoring"] = ["No active ungrounded terminals selected"]
    for element, result, label in (("line", "res_line", "line"),
                                    ("trafo1ph", "res_trafo", "trafo")):
        table = net[element]
        active = table.index[table.in_service.astype(bool)]
        result_table = line_results(net) if element == "line" else net[result]
        values = pd.to_numeric(result_table.loading_percent.reindex(active),
                               errors="coerce")
        if element == "line":
            ratings = pd.to_numeric(net.res_line.reindex(
                index=active, columns=["rating_ka"])["rating_ka"], errors="coerce")
            # An infinite rating produces finite zero loading in the core, but
            # cannot establish monitoring coverage. Keep that result unknown.
            values = values.where(np.isfinite(ratings) & (ratings > 0))
        loading[f"overloaded_{'lines' if label == 'line' else 'trafos'}"] = (
            values.index[values > loading_limit].tolist())
        loading[f"max_{label}_loading"] = (
            _extreme(values, "max") if len(active) else 0.0)
        incomplete[element] = values.index[~np.isfinite(values)].tolist()
    return {
        "converged": True,
        "has_violations": bool(under or over or loading["overloaded_lines"]
                               or loading["overloaded_trafos"]),
        "complete": not any(incomplete.values()),
        "incomplete_results": incomplete,
        "limits": {"v_min": v_min, "v_max": v_max,
                   "loading_limit": loading_limit, "phases": list(phases)},
        "voltage": {"undervoltage_buses": under, "overvoltage_buses": over,
                    "min_voltage": _extreme(voltage, "min"),
                    "max_voltage": _extreme(voltage, "max")},
        "loading": loading,
    }


def calculate_losses(net):
    """Sum line and MC per-side transformer losses; exclude source/ground losses.

    Source results and res_asymmetric_sgen are not fully populated by this
    snapshot solver, so total generation and loss percentages remain unavailable.
    res_asymmetric_gen is populated but does not include all generation sources.
    """
    if not is_solved(net):
        return {"error": "Multiconductor power flow has not converged"}
    result = {}
    for element, table, label in (("line", "res_line", "line"),
                                   ("trafo1ph", "res_trafo", "trafo")):
        active = net[element].index[net[element].in_service.astype(bool)]
        result_table = line_results(net) if element == "line" else net[table]
        for column, unit in (("pl_mw", "mw"), ("ql_mvar", "mvar")):
            values = pd.to_numeric(result_table[column].reindex(active), errors="coerce")
            result[f"{label}_losses_{unit}"] = (
                float(values.sum()) if np.isfinite(values).all() else None)
    for unit in ("mw", "mvar"):
        parts = [result[f"{label}_losses_{unit}"] for label in ("line", "trafo")]
        result[f"total_losses_{unit}"] = (
            sum(parts) if all(value is not None for value in parts) else None)
    result.update(total_generation_mw=None, loss_percentage=None,
                  scope="Line and transformer losses only")
    return result


def summarize_network(net):
    """Count physical IDs separately from conductor/winding rows."""
    _validate_network(net)
    groups = {"buses": ("bus",), "lines": ("line",),
              "transformers": ("trafo1ph",), "loads": ("asymmetric_load",),
              "generators": ("asymmetric_sgen", "asymmetric_gen"),
              "ext_grids": ("ext_grid", "ext_grid_sequence"), "switches": ("switch",)}
    summary = {"name": net.get("name", ""), "elements": {}, "rows": {},
               "converged": is_solved(net)}
    for label, tables in groups.items():
        summary["elements"][label] = sum(
            net[t].index.get_level_values(0).nunique() for t in tables if t in net)
        summary["rows"][label] = sum(len(net[t]) for t in tables if t in net)
    return summary


def analyze_network(net, v_min=0.95, v_max=1.05, loading_limit=100.0,
                    run_control=False, phases=(1, 2, 3), **solver_options):
    """Solve current inputs afresh, then return structured review results."""
    _validate_network(net)
    if (not np.isfinite([v_min, v_max, loading_limit]).all()
            or not v_min < v_max or loading_limit <= 0):
        raise ValueError("Require finite limits, v_min < v_max and a positive loading_limit")
    if "model" in net:
        net.model["solved"] = False
    try:
        mc.run_pf(net, run_control=run_control, **solver_options)
    except Exception as exc:
        if "model" in net:
            net.model["solved"] = False
        return {"converged": False, "error": f"{type(exc).__name__}: {exc}"}
    if not is_solved(net):
        return {"converged": False, "error": "Multiconductor power flow did not converge"}
    return {"converged": True, "summary": summarize_network(net),
            "violations": check_violations(net, v_min, v_max, loading_limit, phases),
            "losses": calculate_losses(net)}


def print_analysis_report(analysis_results):
    print(json.dumps(analysis_results, indent=2, default=str, allow_nan=False))


def run_comprehensive_check(net, v_min=0.95, v_max=1.05,
                            loading_limit=100.0, verbose=True):
    results = analyze_network(net, v_min, v_max, loading_limit)
    if verbose:
        print_analysis_report(results)
    return results


calculate_system_losses = calculate_losses


def print_network_summary(net, include_results=True):
    print_analysis_report(analyze_network(net) if include_results else summarize_network(net))


def load_network(file_path):
    """Load an MC Excel workbook; no implicit balanced-network conversion."""
    path = Path(file_path)
    if path.suffix.lower() != ".xlsx":
        raise ValueError("Expected a multiconductor .xlsx workbook")
    net = mc.from_excel(str(path))
    _validate_network(net)
    return net


def create_demo_network():
    """Unbalanced feeder with a transformer and two parallel three-phase lines."""
    net = mc.create_empty_network(name="Multiconductor skill demo", f_hz=60)
    source = mc.create_bus(net, 20)
    secondary = mc.create_bus(net, 0.4)
    load_bus = mc.create_bus(net, 0.4)
    mc.create_ext_grid_sequence(
        net, source, from_phase=[1, 2, 3], to_phase=0, vm_pu=1,
        va_degree=0, sn_mva=1e9, rx=0.1, x0x=1, r0x0=0.1)
    mc.create_transformer_3ph(net, source, secondary, "0.63 MVA 20/0.4 kV")
    mc.create_std_type(net, {
        "r_ohm_per_km": 0.1, "x_ohm_per_km": 0.2,
        "r0_ohm_per_km": 0.3, "x0_ohm_per_km": 0.4,
        "c_nf_per_km": 0, "c0_nf_per_km": 0, "max_i_ka": 0.2,
    }, "demo_line", element="sequence", check_required=True)
    for name in ("Feeder A", "Feeder B"):
        mc.create_line(net, "demo_line", "sequence", secondary, [1, 2, 3],
                       load_bus, [1, 2, 3], 0.02, name=name)
    mc.create_asymmetric_load(net, load_bus, [1, 2, 3], 0,
                              [0.01, 0.02, 0.03], [0.002, 0.004, 0.006])
    return net

