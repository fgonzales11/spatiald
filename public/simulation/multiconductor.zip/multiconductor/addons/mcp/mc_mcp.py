"""Backward-compatible stdio transport for the isolated native MCP tool service."""
from pathlib import Path
from typing import Optional, Dict, Any
import sys
import os
import logging
from functools import wraps
from contextlib import redirect_stdout
sys.path.insert(0, str(Path(__file__).resolve().parents[3]))
from mcp.server.fastmcp import FastMCP
from multiconductor.addons.mcp import service

logger = logging.getLogger(__name__)
mcp = FastMCP('Multiconductor Analysis Server', instructions=(
    'Start with get_capabilities. Use explicit phase/circuit indices. '
    'Tool completion does not certify engineering feasibility; inspect convergence, '
    'coverage, ratings and supplied load. One private network per stdio process.'))
def stdio_tool(function):
    @wraps(function)
    def wrapped(*args, **kwargs):
        with redirect_stdout(sys.stderr):
            return function(*args, **kwargs)
    return wrapped

for name, function in service.TOOLS.items():
    globals()[name] = function
    mcp.tool()(stdio_tool(function))

def __getattr__(name):
    # Existing Python consumers can still inspect the standalone session.
    if name == '_current_net':
        return service.DEFAULT_SESSION.net
    if name == '_equivalent':
        return service.DEFAULT_SESSION.equivalent
    return getattr(service, name)

@mcp.tool()
async def run_diagnostic_agent(pkl_path: str, user_message: Optional[str] = None, trusted_pickle: bool = False) -> Dict[str, Any]:
    """Run the Multiconductor diagnostic sub-agent on a pickled network file.

    Spawns ``multiconductor.addons.agent.mc_diagnostic_agent.diagnostic_agent``
    (built on the OpenAI Agents SDK) to diagnose convergence and modeling
    issues on the network located at ``pkl_path``. Requires ``OPENAI_API_KEY``
    to be set in the environment and the ``openai-agents`` package installed.

    Args:
        pkl_path: Path to the pickled pandapower-multiconductor network (.pkl).
        trusted_pickle: Explicit acknowledgement of a controlled executable pickle.
            Prefer run_diagnostics for local deterministic diagnostics without an API key.
        user_message: Optional custom prompt for the agent. If omitted, a
            default diagnostic plan is used.

    Returns:
        Dict containing the agent's final output (typically JSON-formatted
        diagnostic report) and status.
    """
    if not trusted_pickle:
        return {"status": "error", "message": "Legacy agent requires trusted_pickle=True for a controlled file; use run_diagnostics for the active network."}
    logger.info(f"Launching diagnostic sub-agent for: {pkl_path}")
    try:
        if not os.path.exists(pkl_path):
            return {
                "status": "error",
                "message": f"File not found: {pkl_path}",
            }

        from multiconductor.addons.agent.mc_diagnostic_agent import (
            diagnostic_agent,
        )
        from agents import Runner

        if user_message is None:
            user_message = (
                f"Please diagnose the multiconductor network at: {pkl_path}\n\n"
                "1. Load the network\n"
                "2. Run validation checks\n"
                "3. Attempt power flow\n"
                "4. Check voltage profile\n"
                "5. Analyze topology\n"
                "6. Check phase consistency\n"
                "7. Examine ext_grid and transformer configuration\n"
                "8. Provide your full diagnostic report as JSON."
            )

        result = await Runner.run(diagnostic_agent, user_message)
        return {
            "status": "success",
            "message": "Diagnostic agent completed",
            "pkl_path": pkl_path,
            "final_output": result.final_output,
        }
    except ImportError as ie:
        return {
            "status": "error",
            "message": (
                "Missing dependency for diagnostic agent. "
                "Install with `pip install openai-agents`. "
                f"Details: {ie}"
            ),
        }
    except Exception as e:
        return {
            "status": "error",
            "message": f"Diagnostic agent failed: {str(e)}",
        }




if __name__ == '__main__':
    mcp.run(transport='stdio')
