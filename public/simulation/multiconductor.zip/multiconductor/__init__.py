"""multiconductor - three-phase (multi-conductor) power flow on pandapower nets.

This is the canonical, self-contained copy of the solver package used by the
Itron Power Flow Platform. Persisted network pickles reference
``multiconductor.*`` module paths, so the package name must stay unchanged.
"""
import os

mc_dir = os.path.dirname(os.path.realpath(__file__))

from multiconductor._version import __version__, __format_version__  # noqa: E402
from multiconductor.file_io import create_empty_network, from_excel  # noqa: E402
from multiconductor.create import *  # noqa: E402,F401,F403
from multiconductor.pycci import *  # noqa: E402,F401,F403
