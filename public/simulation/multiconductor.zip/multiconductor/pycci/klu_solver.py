"""
Sparse complex KLUSolver backed by standard SuiteSparse KLU.

This keeps the existing ``KLUSolver(A).solve(b)`` contract used by
``klu_powerflow.py`` while binding directly to the native CSC API instead of a
custom dense Windows DLL wrapper.
"""

from __future__ import annotations

import ctypes
import ctypes.util
import os

import numpy as np
from scipy.sparse import csc_matrix


_INT32_MAX = np.iinfo(np.int32).max
_RTLD_GLOBAL = getattr(ctypes, "RTLD_GLOBAL", 0)

_KLU_OK = 0
_KLU_SINGULAR = 1
_KLU_OUT_OF_MEMORY = -2
_KLU_INVALID = -3
_KLU_TOO_LARGE = -4

_KLU_STATUS_NAMES = {
    _KLU_OK: "KLU_OK",
    _KLU_SINGULAR: "KLU_SINGULAR",
    _KLU_OUT_OF_MEMORY: "KLU_OUT_OF_MEMORY",
    _KLU_INVALID: "KLU_INVALID",
    _KLU_TOO_LARGE: "KLU_TOO_LARGE",
}


def _platform_library_names(stem: str) -> tuple[str, ...]:
    if os.name == "nt":
        return (f"{stem}.dll", f"lib{stem}.dll")
    if os.uname().sysname == "Darwin":
        return (f"lib{stem}.dylib", f"{stem}.dylib")
    return (f"lib{stem}.so", f"{stem}.so")


def _iter_candidate_files(path_hint: str) -> list[str]:
    expanded = os.path.abspath(os.path.expanduser(path_hint))
    if os.path.isdir(expanded):
        candidates: list[str] = []
        for filename in _platform_library_names("klu"):
            candidates.append(os.path.join(expanded, filename))
        return candidates
    return [expanded]


class _KLUSymbolic(ctypes.Structure):
    pass


class _KLUNumeric(ctypes.Structure):
    pass


class _KLUCommon(ctypes.Structure):
    pass


_KLUUserOrderFn = ctypes.CFUNCTYPE(
    ctypes.c_int32,
    ctypes.c_int32,
    ctypes.POINTER(ctypes.c_int32),
    ctypes.POINTER(ctypes.c_int32),
    ctypes.POINTER(ctypes.c_int32),
    ctypes.POINTER(_KLUCommon),
)

_KLUCommon._fields_ = [
    ("tol", ctypes.c_double),
    ("memgrow", ctypes.c_double),
    ("initmem_amd", ctypes.c_double),
    ("initmem", ctypes.c_double),
    ("maxwork", ctypes.c_double),
    ("btf", ctypes.c_int),
    ("ordering", ctypes.c_int),
    ("scale", ctypes.c_int),
    ("user_order", _KLUUserOrderFn),
    ("user_data", ctypes.c_void_p),
    ("halt_if_singular", ctypes.c_int),
    ("status", ctypes.c_int),
    ("nrealloc", ctypes.c_int),
    ("structural_rank", ctypes.c_int32),
    ("numerical_rank", ctypes.c_int32),
    ("singular_col", ctypes.c_int32),
    ("noffdiag", ctypes.c_int32),
    ("flops", ctypes.c_double),
    ("rcond", ctypes.c_double),
    ("condest", ctypes.c_double),
    ("rgrowth", ctypes.c_double),
    ("work", ctypes.c_double),
    ("memusage", ctypes.c_size_t),
    ("mempeak", ctypes.c_size_t),
]


def _as_double_ptr(array: np.ndarray) -> ctypes.POINTER(ctypes.c_double):
    return array.ctypes.data_as(ctypes.POINTER(ctypes.c_double))


def _status_label(status: int) -> str:
    return _KLU_STATUS_NAMES.get(status, f"UNKNOWN_STATUS({status})")


def _build_error_message(prefix: str, common: _KLUCommon) -> str:
    parts = [f"{prefix}: {_status_label(common.status)}"]
    if common.status == _KLU_SINGULAR:
        parts.append(
            "singular_col="
            f"{common.singular_col}, numerical_rank={common.numerical_rank}"
        )
    elif common.status == _KLU_TOO_LARGE:
        parts.append("matrix exceeds int32 index limits")
    return "; ".join(parts)


class _NativeKLU:
    def __init__(self, library_path: str, library: ctypes.CDLL):
        self.library_path = library_path
        self.library = library
        self._bind()

    def _bind(self) -> None:
        lib = self.library

        lib.klu_defaults.argtypes = [ctypes.POINTER(_KLUCommon)]
        lib.klu_defaults.restype = ctypes.c_int

        lib.klu_analyze.argtypes = [
            ctypes.c_int32,
            ctypes.POINTER(ctypes.c_int32),
            ctypes.POINTER(ctypes.c_int32),
            ctypes.POINTER(_KLUCommon),
        ]
        lib.klu_analyze.restype = ctypes.POINTER(_KLUSymbolic)

        lib.klu_z_factor.argtypes = [
            ctypes.POINTER(ctypes.c_int32),
            ctypes.POINTER(ctypes.c_int32),
            ctypes.POINTER(ctypes.c_double),
            ctypes.POINTER(_KLUSymbolic),
            ctypes.POINTER(_KLUCommon),
        ]
        lib.klu_z_factor.restype = ctypes.POINTER(_KLUNumeric)

        lib.klu_z_solve.argtypes = [
            ctypes.POINTER(_KLUSymbolic),
            ctypes.POINTER(_KLUNumeric),
            ctypes.c_int32,
            ctypes.c_int32,
            ctypes.POINTER(ctypes.c_double),
            ctypes.POINTER(_KLUCommon),
        ]
        lib.klu_z_solve.restype = ctypes.c_int

        lib.klu_free_symbolic.argtypes = [
            ctypes.POINTER(ctypes.POINTER(_KLUSymbolic)),
            ctypes.POINTER(_KLUCommon),
        ]
        lib.klu_free_symbolic.restype = ctypes.c_int

        lib.klu_free_numeric.argtypes = [
            ctypes.POINTER(ctypes.POINTER(_KLUNumeric)),
            ctypes.POINTER(_KLUCommon),
        ]
        lib.klu_free_numeric.restype = ctypes.c_int

    def defaults(self, common: _KLUCommon) -> None:
        if not self.library.klu_defaults(ctypes.byref(common)):
            raise RuntimeError("klu_defaults failed to initialize KLU common")


_NATIVE_API: _NativeKLU | None = None
LOADED_KLU_LIBRARY_PATH: str | None = None


def _search_library_candidates() -> tuple[list[str], list[str], list[tuple[str, str]]]:
    attempts: list[str] = []
    dependency_dirs: list[str] = []
    candidates: list[tuple[str, str]] = []

    env_path = os.environ.get("MULTICONDUCTOR_KLU_LIBRARY")
    if env_path:
        env_candidates = _iter_candidate_files(env_path)
        attempts.extend(f"env:{path}" for path in env_candidates)
        for path in env_candidates:
            candidates.append(("env", path))
            dependency_dirs.append(os.path.dirname(path))

    bundled_root = os.path.join(os.path.dirname(__file__), ".native", "klu")
    bundled_dirs = [os.path.join(bundled_root, "lib")]
    if os.name == "nt":
        bundled_dirs.insert(0, os.path.join(bundled_root, "bin"))
    bundled_candidates = [
        os.path.join(directory, filename)
        for directory in bundled_dirs
        for filename in _platform_library_names("klu")
    ]
    attempts.extend(f"bundled:{path}" for path in bundled_candidates)
    candidates.extend(("bundled", path) for path in bundled_candidates)
    dependency_dirs.extend(bundled_dirs)

    for name in ("klu", "KLU", "libklu"):
        found = ctypes.util.find_library(name)
        attempts.append(f"find_library({name}) -> {found}")
        if found:
            candidates.append(("find_library", found))
            if os.path.dirname(found):
                dependency_dirs.append(os.path.dirname(found))

    dedup_dirs: list[str] = []
    seen_dirs: set[str] = set()
    for directory in dependency_dirs:
        directory = os.path.abspath(os.path.expanduser(directory))
        if directory not in seen_dirs:
            dedup_dirs.append(directory)
            seen_dirs.add(directory)

    dedup_candidates: list[tuple[str, str]] = []
    seen_candidates: set[str] = set()
    for source, candidate in candidates:
        if candidate not in seen_candidates:
            dedup_candidates.append((source, candidate))
            seen_candidates.add(candidate)

    return attempts, dedup_dirs, dedup_candidates


def _preload_dependencies(search_dirs: list[str]) -> None:
    dependency_stems = ("suitesparseconfig", "amd", "colamd", "btf")
    seen: set[str] = set()
    for directory in search_dirs:
        if not os.path.isdir(directory):
            continue
        for stem in dependency_stems:
            for filename in _platform_library_names(stem):
                candidate = os.path.join(directory, filename)
                if candidate in seen or not os.path.isfile(candidate):
                    continue
                seen.add(candidate)
                try:
                    ctypes.CDLL(candidate, mode=_RTLD_GLOBAL)
                except OSError:
                    continue


def _load_native_api() -> _NativeKLU:
    attempts, dependency_dirs, candidates = _search_library_candidates()
    if not candidates:
        raise FileNotFoundError(
            "Unable to locate SuiteSparse KLU library. Search attempts: "
            + "; ".join(attempts)
        )

    load_errors: list[str] = []
    _preload_dependencies(dependency_dirs)

    for source, candidate in candidates:
        try:
            library = ctypes.CDLL(candidate, mode=_RTLD_GLOBAL)
        except OSError as exc:
            load_errors.append(f"{source}:{candidate}: {exc}")
            continue
        return _NativeKLU(candidate, library)

    raise OSError(
        "Unable to load SuiteSparse KLU library. Search attempts: "
        + "; ".join(attempts + load_errors)
    )


def _get_native_api() -> _NativeKLU:
    global _NATIVE_API, LOADED_KLU_LIBRARY_PATH
    if _NATIVE_API is None:
        _NATIVE_API = _load_native_api()
        LOADED_KLU_LIBRARY_PATH = _NATIVE_API.library_path
    return _NATIVE_API


def _prepare_csc_matrix(A) -> tuple[int, np.ndarray, np.ndarray, np.ndarray]:
    matrix = csc_matrix(A, dtype=np.complex128, copy=True)
    if matrix.shape[0] != matrix.shape[1]:
        raise ValueError("KLUSolver requires a square matrix")

    n = int(matrix.shape[0])
    if n == 0:
        raise ValueError("KLUSolver requires a non-empty square matrix")
    if n > _INT32_MAX:
        raise OverflowError(f"matrix dimension {n} exceeds int32 limit")

    matrix.sum_duplicates()
    matrix.sort_indices()
    matrix.eliminate_zeros()

    nnz = int(matrix.nnz)
    if nnz > _INT32_MAX:
        raise OverflowError(f"matrix nnz {nnz} exceeds int32 limit")

    if matrix.indices.size and int(matrix.indices.max()) > _INT32_MAX:
        raise OverflowError("matrix row indices exceed int32 limit")
    if int(matrix.indptr[-1]) > _INT32_MAX:
        raise OverflowError("matrix column pointer exceeds int32 limit")

    ap = np.ascontiguousarray(matrix.indptr, dtype=np.int32)
    ai = np.ascontiguousarray(matrix.indices, dtype=np.int32)
    ax = np.ascontiguousarray(matrix.data, dtype=np.complex128)
    return n, ap, ai, ax


def _prepare_rhs(rhs, n: int) -> tuple[np.ndarray, int]:
    array = np.asarray(rhs, dtype=np.complex128)
    if array.ndim == 1:
        if array.shape[0] != n:
            raise ValueError(
                f"RHS size {array.shape[0]} does not match matrix size {n}"
            )
        work = np.array(
            array.reshape(n, 1),
            dtype=np.complex128,
            order="F",
            copy=True,
        )
        return work, 1

    if array.ndim == 2:
        if array.shape[0] != n:
            raise ValueError(
                f"RHS shape {array.shape} does not match matrix size {n}"
            )
        nrhs = int(array.shape[1])
        if nrhs == 0:
            raise ValueError("RHS must have at least one column")
        return np.array(array, dtype=np.complex128, order="F", copy=True), nrhs

    raise ValueError(
        "RHS must have shape (n,), (n, 1), or (n, nrhs)"
    )


class KLUSolver:
    """
    Sparse complex LU solve via SuiteSparse KLU.

    The native library is loaded lazily so module import succeeds even before
    the bundled library has been built.
    """

    def __init__(self, A):
        self._n, ap, ai, ax = _prepare_csc_matrix(A)
        api = _get_native_api()
        self._api = api
        self._common = _KLUCommon()
        self._symbolic = ctypes.POINTER(_KLUSymbolic)()
        self._numeric = ctypes.POINTER(_KLUNumeric)()
        self._closed = False
        self.native_library_path = api.library_path

        api.defaults(self._common)
        self._common.halt_if_singular = 1

        try:
            self._symbolic = api.library.klu_analyze(
                ctypes.c_int32(self._n),
                ap.ctypes.data_as(ctypes.POINTER(ctypes.c_int32)),
                ai.ctypes.data_as(ctypes.POINTER(ctypes.c_int32)),
                ctypes.byref(self._common),
            )
            if not self._symbolic:
                raise RuntimeError(
                    _build_error_message("klu_analyze failed", self._common)
                )

            self._numeric = api.library.klu_z_factor(
                ap.ctypes.data_as(ctypes.POINTER(ctypes.c_int32)),
                ai.ctypes.data_as(ctypes.POINTER(ctypes.c_int32)),
                _as_double_ptr(ax),
                self._symbolic,
                ctypes.byref(self._common),
            )
            if not self._numeric:
                raise RuntimeError(
                    _build_error_message("klu_z_factor failed", self._common)
                )
        except Exception:
            self.close()
            raise

    def solve(self, b):
        if self._closed:
            raise RuntimeError("KLUSolver has been closed")
        work, nrhs = _prepare_rhs(b, self._n)
        ok = self._api.library.klu_z_solve(
            self._symbolic,
            self._numeric,
            ctypes.c_int32(self._n),
            ctypes.c_int32(nrhs),
            _as_double_ptr(work),
            ctypes.byref(self._common),
        )
        if not ok:
            raise RuntimeError(_build_error_message("klu_z_solve failed", self._common))

        result = work.copy(order="F")
        if nrhs == 1:
            return result.reshape(self._n, 1, order="F")
        return result

    def close(self) -> None:
        if self._closed:
            return
        self._closed = True

        if hasattr(self, "_numeric"):
            if bool(self._numeric):
                self._api.library.klu_free_numeric(
                    ctypes.byref(self._numeric),
                    ctypes.byref(self._common),
                )
            self._numeric = ctypes.POINTER(_KLUNumeric)()

        if hasattr(self, "_symbolic"):
            if bool(self._symbolic):
                self._api.library.klu_free_symbolic(
                    ctypes.byref(self._symbolic),
                    ctypes.byref(self._common),
                )
            self._symbolic = ctypes.POINTER(_KLUSymbolic)()

    def __enter__(self):
        return self

    def __exit__(self, exc_type, exc, tb):
        self.close()
        return False

    def __del__(self):
        try:
            self.close()
        except Exception:
            pass
