"""Correction-current-injection power flow backed by SuiteSparse KLU.

The numerical and controller path is intentionally owned by
``cci_powerflow.run_pf``. This module only injects :class:`KLUSolver` as the
sparse factorization implementation, so the KLU and SciPy/SuperLU variants
share topology handling, controls, convergence checks, and result assembly.
"""

from multiconductor.pycci import cci_powerflow

from .klu_solver import KLUSolver


def run_klu_pf(
    net,
    tol_vmag_pu=1e-5,
    tol_vang_rad=1e-5,
    MaxIter=100,
    run_control=False,
    debug_level=0,
    **kwargs,
):
    """Run CCI power flow using SuiteSparse KLU for sparse linear solves.

    Parameters and controller flags match :func:`cci_powerflow.run_pf`.
    ``KLUSolver`` replaces both the initial-voltage and iterative CCI
    factorizations while all surrounding behavior remains shared.
    """

    return cci_powerflow.run_pf(
        net,
        tol_vmag_pu=tol_vmag_pu,
        tol_vang_rad=tol_vang_rad,
        MaxIter=MaxIter,
        run_control=run_control,
        debug_level=debug_level,
        _sparse_solver=KLUSolver,
        **kwargs,
    )


__all__ = ["run_klu_pf"]
