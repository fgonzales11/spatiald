"""Use native Numba when available; execute the same kernels on WebAssembly."""
import os
import sys
from types import SimpleNamespace

import numpy as np


def _python_njit(function=None, **kwargs):
    """Numba's decorator shape without compilation, for Python/NumPy kernels."""
    if function is not None:
        return function
    return lambda function: function


if sys.platform == "emscripten" or os.environ.get("MULTICONDUCTOR_DISABLE_NUMBA") == "1":
    numba = SimpleNamespace(njit=_python_njit, boolean=np.bool_, int32=np.int32)
else:
    import numba

njit = numba.njit
